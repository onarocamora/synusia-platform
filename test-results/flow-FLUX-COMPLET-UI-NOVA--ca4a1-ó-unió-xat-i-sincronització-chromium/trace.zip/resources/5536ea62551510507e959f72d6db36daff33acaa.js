(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/posthog-js/dist/module.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Compression",
    ()=>Mo,
    "DEFAULT_PRODUCT_TOUR_APPEARANCE",
    ()=>Jo,
    "DisplaySurveyType",
    ()=>Wo,
    "PostHog",
    ()=>Jl,
    "ProductTourEventName",
    ()=>Ko,
    "ProductTourEventProperties",
    ()=>Yo,
    "SurveyEventName",
    ()=>qo,
    "SurveyEventProperties",
    ()=>Vo,
    "SurveyEventType",
    ()=>Do,
    "SurveyPosition",
    ()=>Lo,
    "SurveyQuestionBranchingType",
    ()=>zo,
    "SurveyQuestionType",
    ()=>Bo,
    "SurveySchedule",
    ()=>Ho,
    "SurveyTabPosition",
    ()=>jo,
    "SurveyType",
    ()=>Uo,
    "SurveyWidgetType",
    ()=>No,
    "default",
    ()=>Su,
    "posthog",
    ()=>Su,
    "severityLevels",
    ()=>ia
]);
var t = "u" > typeof window ? window : void 0, i = "u" > typeof globalThis ? globalThis : t, e = null == i ? void 0 : i.navigator, r = null == i ? void 0 : i.document, s = null == i ? void 0 : i.location, n = null == i ? void 0 : i.fetch, o = null != i && i.XMLHttpRequest && "withCredentials" in new i.XMLHttpRequest ? i.XMLHttpRequest : void 0, a = null == i ? void 0 : i.AbortController, l = null == i ? void 0 : i.CompressionStream, h = null == e ? void 0 : e.userAgent;
function u() {
    return !(!t || !1 === t.navigator.onLine);
}
var d = "undefined" != typeof globalThis ? globalThis : t;
d && "undefined" == typeof self && (d.self = d), d && "undefined" == typeof File && (d.File = function() {});
var v = null != t ? t : {}, c = {
    DEBUG: !1,
    LIB_VERSION: "0.7.2",
    LIB_NAME: "browser-common"
};
function f(t, i, e, r, s, n, o) {
    try {
        var a = t[n](o), l = a.value;
    } catch (t) {
        return void e(t);
    }
    a.done ? i(l) : Promise.resolve(l).then(r, s);
}
function p(t) {
    return function() {
        var i = this, e = arguments;
        return new Promise(function(r, s) {
            var n = t.apply(i, e);
            function o(t) {
                f(n, r, s, o, a, "next", t);
            }
            function a(t) {
                f(n, r, s, o, a, "throw", t);
            }
            o(void 0);
        });
    };
}
function _() {
    return _ = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : "TURBOPACK unreachable", _.apply(null, arguments);
}
function g(t, i) {
    if (null == t) return {};
    var e = {};
    for(var r in t)if (({}).hasOwnProperty.call(t, r)) {
        if (-1 !== i.indexOf(r)) continue;
        e[r] = t[r];
    }
    return e;
}
var m = [
    "amazonbot",
    "amazonproductbot",
    "app.hypefactors.com",
    "applebot",
    "archive.org_bot",
    "awariobot",
    "backlinksextendedbot",
    "baiduspider",
    "bingbot",
    "bingpreview",
    "chrome-lighthouse",
    "dataforseobot",
    "deepscan",
    "duckduckbot",
    "facebookexternal",
    "facebookcatalog",
    "http://yandex.com/bots",
    "hubspot",
    "ia_archiver",
    "leikibot",
    "linkedinbot",
    "meta-externalagent",
    "mj12bot",
    "msnbot",
    "nessus",
    "petalbot",
    "pinterestbot",
    "prerender",
    "rogerbot",
    "screaming frog",
    "sebot-wa",
    "sitebulb",
    "slackbot",
    "slurp",
    "trendictionbot",
    "turnitin",
    "twitterbot",
    "vercel-screenshot",
    "vercelbot",
    "yahoo! slurp",
    "yandexbot",
    "zoombot",
    "bot.htm",
    "bot.php",
    "(bot;",
    "bot/",
    "crawler",
    "ahrefsbot",
    "ahrefssiteaudit",
    "semrushbot",
    "siteauditbot",
    "splitsignalbot",
    "gptbot",
    "oai-searchbot",
    "chatgpt-user",
    "perplexitybot",
    "better uptime bot",
    "sentryuptimebot",
    "uptimerobot",
    "headlesschrome",
    "cypress",
    "google-hoteladsverifier",
    "adsbot-google",
    "apis-google",
    "duplexweb-google",
    "feedfetcher-google",
    "google favicon",
    "google web preview",
    "google-read-aloud",
    "googlebot",
    "googleother",
    "google-cloudvertexbot",
    "googleweblight",
    "mediapartners-google",
    "storebot-google",
    "google-inspectiontool",
    "bytespider"
], b = function(t, i) {
    if (void 0 === i && (i = []), !t) return !1;
    var e = t.toLowerCase();
    return m.concat(i).some((t)=>{
        var i = t.toLowerCase();
        return -1 !== e.indexOf(i);
    });
};
function y(t, i) {
    return -1 !== t.indexOf(i);
}
var w = function(t) {
    return t.trim();
}, S = function(t) {
    return t.replace(/^\$/, "");
};
function x(t) {
    var i, e = [];
    return null !== (i = JSON.stringify(t, function(t, i) {
        if ("bigint" == typeof i) return i.toString();
        if ("function" != typeof i && "symbol" != typeof i) {
            if (i instanceof Error) return {
                name: i.name,
                message: i.message,
                stack: i.stack
            };
            if (i && "object" == typeof i) {
                for(; e.length > 0 && e[e.length - 1] !== this;)e.pop();
                if (e.includes(i)) return "[Circular]";
                e.push(i);
            }
            return i;
        }
    })) && void 0 !== i ? i : "null";
}
var E = function(t) {
    return t.AnonymousId = "anonymous_id", t.DistinctId = "distinct_id", t.Props = "props", t.EnablePersonProcessing = "enable_person_processing", t.PersonMode = "person_mode", t.FeatureFlagDetails = "feature_flag_details", t.FeatureFlags = "feature_flags", t.FeatureFlagPayloads = "feature_flag_payloads", t.BootstrapFeatureFlagDetails = "bootstrap_feature_flag_details", t.BootstrapFeatureFlags = "bootstrap_feature_flags", t.BootstrapFeatureFlagPayloads = "bootstrap_feature_flag_payloads", t.OverrideFeatureFlags = "override_feature_flags", t.Queue = "queue", t.AiQueue = "ai_queue", t.AiCaptureQueue = "ai_capture_queue", t.LogsQueue = "logs_queue", t.OptedOut = "opted_out", t.SessionId = "session_id", t.SessionStartTimestamp = "session_start_timestamp", t.SessionLastTimestamp = "session_timestamp", t.PersonProperties = "person_properties", t.GroupProperties = "group_properties", t.InstalledAppBuild = "installed_app_build", t.InstalledAppVersion = "installed_app_version", t.SessionReplay = "session_replay", t.PushRegistered = "push_registered", t.SessionReplayEventTriggerActivatedSession = "session_replay_event_trigger_activated_session", t.SurveyLastSeenDate = "survey_last_seen_date", t.SurveysSeen = "surveys_seen", t.Surveys = "surveys", t.RemoteConfig = "remote_config", t.FlagsEndpointWasHit = "flags_endpoint_was_hit", t.DeviceId = "device_id", t;
}({}), k = function(t) {
    return t.GZipJS = "gzip-js", t.Base64 = "base64", t;
}({}), T = [
    "$snapshot",
    "$pageview",
    "$pageleave",
    "$set",
    "survey dismissed",
    "survey sent",
    "survey shown",
    "$identify",
    "$groupidentify",
    "$create_alias",
    "$$client_ingestion_warning",
    "$web_experiment_applied",
    "$feature_enrollment_update",
    "$feature_flag_called"
], P = [
    "token"
], R = Object.prototype, C = R.hasOwnProperty, O = R.toString, I = Array.isArray || function(t) {
    return "[object Array]" === O.call(t);
}, F = (t)=>"function" == typeof t, A = (t)=>t === Object(t) && !I(t), M = (t)=>{
    if (A(t)) {
        for(var i in t)if (C.call(t, i)) return !1;
        return !0;
    }
    return !1;
}, D = (t)=>void 0 === t, N = (t)=>"[object String]" == O.call(t), L = (t)=>N(t) && 0 === t.trim().length, j = (t)=>null === t, U = (t)=>D(t) || j(t), B = (t)=>"[object Number]" == O.call(t) && t == t, z = (t)=>B(t) && t > 0, H = (t)=>"[object Boolean]" === O.call(t), q = (t)=>t instanceof FormData, V = (t)=>y(T, t), W = (t)=>y(P, t);
function G(t) {
    return null === t || "object" != typeof t;
}
function J(t, i) {
    return ({}).toString.call(t) === "[object " + i + "]";
}
function K(t) {
    switch(({}).toString.call(t)){
        case "[object Error]":
        case "[object Exception]":
        case "[object DOMException]":
        case "[object DOMError]":
        case "[object WebAssembly.Exception]":
            return !0;
        default:
            return Q(t, Error);
    }
}
function Y(t) {
    return "u" > typeof Event && Q(t, Event);
}
function Q(t, i) {
    try {
        return t instanceof i;
    } catch (t) {
        return !1;
    }
}
var X = [
    !0,
    "true",
    1,
    "1",
    "yes"
], Z = (t)=>y(X, t), tt = [
    !1,
    "false",
    0,
    "0",
    "no"
];
function it(t, i, e, r, s) {
    return i > e && (r.warn("min cannot be greater than max."), i = e), B(t) ? t > e ? (r.warn(" cannot be  greater than max: " + e + ". Using max value instead."), e) : i > t ? (r.warn(" cannot be less than min: " + i + ". Using min value instead."), i) : t : (r.warn(" must be a number. using max or fallback. max: " + e + ", fallback: " + s), it(null != s ? s : e, i, e, r));
}
class et {
    constructor(t){
        this.C = {}, this.I = t.I, this.R = it(t.bucketSize, 0, 100, t.A), this.O = it(t.refillRate, 0, this.R, t.A), this.N = it(t.refillInterval, 0, 864e5, t.A);
    }
    F(t, i) {
        var e = Math.floor((i - t.lastAccess) / this.N);
        e > 0 && (t.tokens = Math.min(t.tokens + e * this.O, this.R), t.lastAccess = t.lastAccess + e * this.N);
    }
    consumeRateLimit(t) {
        var i, e = Date.now(), r = String(t), s = this.C[r];
        return s ? this.F(s, e) : this.C[r] = s = {
            tokens: this.R,
            lastAccess: e
        }, 0 === s.tokens || (s.tokens--, 0 === s.tokens && (null == (i = this.I) || i.call(this, t)), 0 === s.tokens);
    }
    stop() {
        this.C = {};
    }
}
var rt = "Mobile", st = "iOS", nt = "Android", ot = "Tablet", at = nt + " " + ot, lt = "iPad", ht = "Apple", ut = ht + " Watch", dt = "Safari", vt = "BlackBerry", ct = "Samsung", ft = ct + "Browser", pt = ct + " Internet", _t = "Chrome", gt = _t + " OS", mt = _t + " " + st, bt = "Internet Explorer", yt = bt + " " + rt, wt = "Opera", St = wt + " Mini", xt = "Edge", Et = "Microsoft " + xt, kt = "Firefox", Tt = kt + " " + st, $t = "Nintendo", Pt = "PlayStation", Rt = "Xbox", Ct = nt + " " + rt, Ot = rt + " " + dt, It = "Windows", Ft = It + " Phone", At = "Nokia", Mt = "Ouya", Dt = "Generic", Nt = Dt + " " + rt.toLowerCase(), Lt = Dt + " " + ot.toLowerCase(), jt = "Konqueror", Ut = "Oculus Browser", Bt = "Vivaldi", zt = "Yandex", Ht = "Whale", qt = "DuckDuckGo", Vt = "Pale Moon", Wt = "Waterfox", Gt = "Brave", Jt = "Claude", Kt = "Codex", Yt = "ChatGPT", Qt = "Google Search App", Xt = "(\\d+(\\.\\d+)?)", Zt = new RegExp("Version/" + Xt), ti = new RegExp("(" + Jt + "|" + Kt + "|" + Yt + ")\\/" + Xt), ii = new RegExp(Rt, "i"), ei = new RegExp(Pt + " \\w+", "i"), ri = new RegExp($t + " \\w+", "i"), si = new RegExp(vt + "|PlayBook|BB10", "i"), ni = {
    "NT3.51": "NT 3.11",
    "NT4.0": "NT 4.0",
    "5.0": "2000",
    5.1: "XP",
    5.2: "XP",
    "6.0": "Vista",
    6.1: "7",
    6.2: "8",
    6.3: "8.1",
    6.4: "10",
    "10.0": "10"
}, oi = function(t, i, e, r) {
    i = i || "";
    var s = function(t) {
        return null != t && t.brave ? Gt : null;
    }(e);
    return s || (null != r && r.detectGoogleSearchApp && y(t, "GSA/") ? Qt : y(t, " OPR/") && y(t, "Mini") ? St : y(t, " OPR/") ? wt : si.test(t) ? vt : y(t, "IE" + rt) || y(t, "WPDesktop") ? yt : y(t, "OculusBrowser") ? Ut : y(t, ft) ? pt : y(t, xt) || y(t, "Edg/") ? Et : y(t, Bt + "/") ? Bt : y(t, "YaBrowser/") ? zt : y(t, Ht + "/") ? Ht : y(t, qt + "/") || y(t, "Ddg/") ? qt : y(t, Jt + "/") ? Jt : y(t, Kt + "/") ? Kt : y(t, Yt + "/") ? Yt : y(t, "FBIOS") ? "Facebook " + rt : y(t, "UCWEB") || y(t, "UCBrowser") ? "UC Browser" : y(t, "CriOS") ? mt : y(t, "CrMo") || y(t, _t) ? _t : y(t, nt) && y(t, dt) ? Ct : y(t, "FxiOS") ? Tt : y(t.toLowerCase(), jt.toLowerCase()) ? jt : y(t, Gt + "/") ? Gt : ((t, i)=>i && y(i, ht) || function(t) {
            return y(t, dt) && !y(t, _t) && !y(t, nt);
        }(t))(t, i) ? y(t, rt) ? Ot : dt : y(t, "PaleMoon/") ? Vt : y(t, Wt + "/") ? Wt : y(t, kt) ? kt : y(t, "MSIE") || y(t, "Trident/") ? bt : y(t, "Gecko") ? kt : "");
}, ai = {
    [yt]: [
        new RegExp("rv:" + Xt)
    ],
    [Et]: [
        new RegExp(xt + "?\\/" + Xt)
    ],
    [_t]: [
        new RegExp("(" + _t + "|CrMo)\\/" + Xt)
    ],
    [mt]: [
        new RegExp("CriOS\\/" + Xt)
    ],
    "UC Browser": [
        new RegExp("(UCBrowser|UCWEB)\\/" + Xt)
    ],
    [dt]: [
        Zt
    ],
    [Ot]: [
        Zt
    ],
    [wt]: [
        new RegExp("(Opera|OPR)\\/" + Xt)
    ],
    [kt]: [
        new RegExp(kt + "\\/" + Xt)
    ],
    [Tt]: [
        new RegExp("FxiOS\\/" + Xt)
    ],
    [jt]: [
        new RegExp("Konqueror[:/]?" + Xt, "i")
    ],
    [vt]: [
        new RegExp(vt + " " + Xt),
        Zt
    ],
    [Ct]: [
        new RegExp("android\\s" + Xt, "i")
    ],
    [pt]: [
        new RegExp(ft + "\\/" + Xt)
    ],
    [Ut]: [
        new RegExp("OculusBrowser\\/" + Xt)
    ],
    [Bt]: [
        new RegExp(Bt + "\\/" + Xt)
    ],
    [zt]: [
        new RegExp("YaBrowser\\/" + Xt)
    ],
    [Ht]: [
        new RegExp(Ht + "\\/" + Xt)
    ],
    [Gt]: [
        new RegExp(Gt + "\\/" + Xt)
    ],
    [Jt]: [
        ti
    ],
    [Kt]: [
        ti
    ],
    [Yt]: [
        ti
    ],
    [qt]: [
        new RegExp("(DuckDuckGo|Ddg)\\/" + Xt)
    ],
    [Vt]: [
        new RegExp("PaleMoon\\/" + Xt)
    ],
    [Wt]: [
        new RegExp(Wt + "\\/" + Xt)
    ],
    [Qt]: [
        new RegExp("GSA\\/" + Xt)
    ],
    [bt]: [
        new RegExp("(rv:|MSIE )" + Xt)
    ],
    Mozilla: [
        new RegExp("rv:" + Xt)
    ]
}, li = function(t, i, e, r) {
    var s = oi(t, i, e, r), n = ai[s];
    if (D(n)) return null;
    for(var o = 0; n.length > o; o++){
        var a = t.match(n[o]);
        if (a) return parseFloat(a[a.length - 2]);
    }
    return null;
}, hi = [
    [
        new RegExp(Rt + "; " + Rt + " (.*?)[);]", "i"),
        (t)=>[
                Rt,
                t && t[1] || ""
            ]
    ],
    [
        new RegExp($t, "i"),
        [
            $t,
            ""
        ]
    ],
    [
        new RegExp(Pt, "i"),
        [
            Pt,
            ""
        ]
    ],
    [
        si,
        [
            vt,
            ""
        ]
    ],
    [
        new RegExp(It, "i"),
        (t, i)=>{
            if (/Phone/.test(i) || /WPDesktop/.test(i)) return [
                Ft,
                ""
            ];
            if (new RegExp(rt).test(i) && !/IEMobile\b/.test(i)) return [
                It + " " + rt,
                ""
            ];
            var e = /Windows NT ([0-9.]+)/i.exec(i);
            if (e && e[1]) {
                var r = ni[e[1]] || "";
                return /arm/i.test(i) && (r = "RT"), [
                    It,
                    r
                ];
            }
            return [
                It,
                ""
            ];
        }
    ],
    [
        /((iPhone|iPad|iPod).*?OS (\d+)_(\d+)_?(\d+)?|iPhone)/,
        (t)=>t && t[3] ? [
                st,
                [
                    t[3],
                    t[4],
                    t[5] || "0"
                ].join(".")
            ] : [
                st,
                ""
            ]
    ],
    [
        /(watch.*\/(\d+\.\d+\.\d+)|watch os,(\d+\.\d+),)/i,
        (t)=>{
            var i = "";
            return t && t.length >= 3 && (i = D(t[2]) ? t[3] : t[2]), [
                "watchOS",
                i
            ];
        }
    ],
    [
        new RegExp("(" + nt + " (\\d+)\\.(\\d+)\\.?(\\d+)?|" + nt + ")", "i"),
        (t)=>t && t[2] ? [
                nt,
                [
                    t[2],
                    t[3],
                    t[4] || "0"
                ].join(".")
            ] : [
                nt,
                ""
            ]
    ],
    [
        /Mac OS X (\d+)[_.](\d+)[_.]?(\d+)?/i,
        (t)=>{
            var i = [
                "Mac OS X",
                ""
            ];
            return t && t[1] && (i[1] = [
                t[1],
                t[2],
                t[3] || "0"
            ].join(".")), i;
        }
    ],
    [
        /Mac/i,
        [
            "Mac OS X",
            ""
        ]
    ],
    [
        /CrOS/,
        [
            gt,
            ""
        ]
    ],
    [
        /Linux|debian/i,
        [
            "Linux",
            ""
        ]
    ]
], ui = function(t) {
    for(var i = 0; hi.length > i; i++){
        var e = hi[i], r = e[1], s = e[0].exec(t), n = s && (F(r) ? r(s, t) : r);
        if (n) return n;
    }
    return [
        "",
        ""
    ];
}, di = function(t) {
    return ri.test(t) ? $t : ei.test(t) ? Pt : ii.test(t) ? Rt : new RegExp(Mt, "i").test(t) ? Mt : new RegExp("(" + Ft + "|WPDesktop)", "i").test(t) ? Ft : /iPad/.test(t) ? lt : /iPod/.test(t) ? "iPod Touch" : /iPhone/.test(t) ? "iPhone" : /(watch)(?: ?os[,/]|\d,\d\/)[\d.]+/i.test(t) ? ut : si.test(t) ? vt : /(kobo)\s(ereader|touch)/i.test(t) ? "Kobo" : new RegExp(At, "i").test(t) ? At : /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i.test(t) || /(kf[a-z]+)( bui|\)).+silk\//i.test(t) ? "Kindle Fire" : /(Android|ZTE)/i.test(t) ? new RegExp(rt).test(t) && !/(9138B|TB782B|Nexus [97]|pixel c|HUAWEISHT|BTV|noble nook|smart ultra 6)/i.test(t) || /pixel[\daxl ]{1,6}/i.test(t) && !/pixel c/i.test(t) || /(huaweimed-al00|tah-|APA|SM-G92|i980|zte|U304AA)/i.test(t) || /lmy47v/i.test(t) && !/QTAQZ3/i.test(t) ? nt : at : new RegExp("(pda|" + rt + ")", "i").test(t) ? Nt : new RegExp(ot, "i").test(t) && !new RegExp(ot + " pc", "i").test(t) ? Lt : "";
}, vi = 20, ci = 1e3, fi = 1e4, pi = "[Circular]", _i = "[Truncated]", gi = "[Unserializable]", mi = "[Function]";
function bi(t) {
    for(var i = "", e = 0; t.length > e; e++){
        var r = t.charCodeAt(e);
        if (55296 > r || r > 56319) i += 56320 > r || r > 57343 ? t[e] : "�";
        else {
            var s = t.charCodeAt(e + 1);
            56320 > s || s > 57343 ? i += "�" : (i += t[e] + t[e + 1], e++);
        }
    }
    return i;
}
var yi, wi, Si, xi = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function Ei(t, i) {
    return "string" == typeof (e = t) && xi.test(e) ? t : i();
    //TURBOPACK unreachable
    ;
    var e;
}
function ki(t, i) {
    var e = new Error(i);
    try {
        Object.defineProperty(e, "name", {
            value: t,
            writable: !0,
            enumerable: !0,
            configurable: !0
        });
    } catch (t) {}
    return e;
}
function Ti(t) {
    return t ? t.split("#")[0] : t;
}
function $i(t, i) {
    var e = setTimeout(t, i);
    return (null == e ? void 0 : e.unref) && (null == e || e.unref()), e;
}
function Pi(t, i, e) {
    return Ri.apply(this, arguments);
}
function Ri() {
    return (Ri = p(function*(t, i, e) {
        var r;
        try {
            return yield Promise.race([
                t,
                new Promise((t, s)=>{
                    r = $i(()=>{
                        try {
                            null == e || e(), t();
                        } catch (t) {
                            s(t);
                        }
                    }, i);
                })
            ]);
        } finally{
            clearTimeout(r);
        }
    })).apply(this, arguments);
}
function Ci(t) {
    var i = globalThis._posthogChunkIds;
    if (i) {
        var e = Object.keys(i);
        return Si && e.length === wi || (wi = e.length, Si = e.reduce((e, r)=>{
            yi || (yi = {});
            var s = yi[r];
            if (s) e[s[0]] = s[1];
            else for(var n = t(r), o = n.length - 1; o >= 0; o--){
                var a = n[o], l = null == a ? void 0 : a.filename, h = i[r];
                if (l && h) {
                    e[l] = h, yi[r] = [
                        l,
                        h
                    ];
                    break;
                }
            }
            return e;
        }, {})), Si;
    }
}
class Oi {
    constructor(t, i, e){
        void 0 === e && (e = []), this.coercers = t, this.stackParser = i, this.modifiers = e;
    }
    buildFromUnknown(t, i) {
        void 0 === i && (i = {});
        var e = i && i.mechanism || {
            handled: !0,
            type: "generic"
        }, r = this.buildCoercingContext(e, i, 0).apply(t), s = this.buildParsingContext(i), n = this.parseStacktrace(r, s);
        return {
            $exception_list: this.convertToExceptionList(n, e),
            $exception_level: "error"
        };
    }
    modifyFrames(t) {
        var i = this;
        return p(function*() {
            for (var e of t)e.stacktrace && e.stacktrace.frames && I(e.stacktrace.frames) && (e.stacktrace.frames = yield i.applyModifiers(e.stacktrace.frames));
            return t;
        })();
    }
    coerceFallback(t) {
        var i;
        return {
            type: "Error",
            value: "Unknown error",
            stack: null == (i = t.syntheticException) ? void 0 : i.stack,
            synthetic: !0
        };
    }
    parseStacktrace(t, i) {
        var e, r;
        return null != t.cause && (e = this.parseStacktrace(t.cause, i)), "" != t.stack && null != t.stack && (r = this.applyChunkIds(this.stackParser(t.stack, t.synthetic ? i.skipFirstLines : 0), i.chunkIdMap)), _({}, t, {
            cause: e,
            stack: r
        });
    }
    applyChunkIds(t, i) {
        return t.map((t)=>(t.filename && i && (t.chunk_id = i[t.filename]), t));
    }
    applyCoercers(t, i) {
        for (var e of this.coercers)if (e.match(t)) return e.coerce(t, i);
        return this.coerceFallback(i);
    }
    applyModifiers(t) {
        var i = this;
        return p(function*() {
            var e = t;
            for (var r of i.modifiers)e = yield r(e);
            return e;
        })();
    }
    convertToExceptionList(t, i) {
        var e, r, s, n = {
            type: t.type,
            value: t.value,
            mechanism: {
                type: null !== (e = i.type) && void 0 !== e ? e : "generic",
                handled: null === (r = i.handled) || void 0 === r || r,
                synthetic: null !== (s = t.synthetic) && void 0 !== s && s
            }
        };
        t.stack && (n.stacktrace = {
            type: "raw",
            frames: t.stack
        });
        var o = [
            n
        ];
        return null != t.cause && o.push(...this.convertToExceptionList(t.cause, _({}, i, {
            handled: !0
        }))), o;
    }
    buildParsingContext(t) {
        var i;
        return {
            chunkIdMap: Ci(this.stackParser),
            skipFirstLines: null !== (i = t.skipFirstLines) && void 0 !== i ? i : 1
        };
    }
    buildCoercingContext(t, i, e) {
        void 0 === e && (e = 0);
        var r = (e, r)=>{
            if (4 >= r) {
                var s = this.buildCoercingContext(t, i, r);
                return this.applyCoercers(e, s);
            }
        };
        return _({}, i, {
            syntheticException: 0 == e ? i.syntheticException : void 0,
            mechanism: t,
            apply: (t)=>r(t, e),
            next: (t)=>r(t, e + 1)
        });
    }
}
var Ii = "?";
function Fi(t, i, e, r, s) {
    var n = {
        platform: t,
        filename: i,
        function: "<anonymous>" === e ? Ii : e,
        in_app: !(null != i && i.startsWith("webkit-masked-url://")) && "<anonymous>" !== i
    };
    return D(r) || (n.lineno = r), D(s) || (n.colno = s), n;
}
var Ai = (t, i)=>{
    var e = -1 !== t.indexOf("safari-extension"), r = -1 !== t.indexOf("safari-web-extension");
    return e || r ? [
        -1 !== t.indexOf("@") ? t.split("@")[0] : Ii,
        e ? "safari-extension:" + i : "safari-web-extension:" + i
    ] : [
        t,
        i
    ];
}, Mi = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i, Di = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i, Ni = /\((\S*)(?::(\d+))(?::(\d+))\)/, Li = (t, i)=>{
    var e = Mi.exec(t);
    if (e) return Fi(i, e[1], Ii, +e[2], +e[3]);
    var r = Di.exec(t);
    if (r) {
        if (r[2] && 0 === r[2].indexOf("eval")) {
            var s = Ni.exec(r[2]);
            s && (r[2] = s[1], r[3] = s[2], r[4] = s[3]);
        }
        var n = Ai(r[1] || Ii, r[2]);
        return Fi(i, n[1], n[0], r[3] ? +r[3] : void 0, r[4] ? +r[4] : void 0);
    }
}, ji = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i, Ui = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i, Bi = (t, i)=>{
    var e = ji.exec(t);
    if (e) {
        if (e[3] && e[3].indexOf(" > eval") > -1) {
            var r = Ui.exec(e[3]);
            r && (e[1] = e[1] || "eval", e[3] = r[1], e[4] = r[2], e[5] = "");
        }
        var s = e[3], n = e[1] || Ii, o = Ai(n, s);
        return Fi(i, s = o[1], n = o[0], e[4] ? +e[4] : void 0, e[5] ? +e[5] : void 0);
    }
}, zi = /\(error: (.*)\)/;
class Hi {
    match(t) {
        return this.isDOMException(t) || this.isDOMError(t);
    }
    coerce(t, i) {
        var e = N(t.stack);
        return {
            type: this.getType(t),
            value: this.getValue(t),
            stack: e ? t.stack : void 0,
            cause: t.cause ? i.next(t.cause) : void 0,
            synthetic: !1
        };
    }
    getType(t) {
        return this.isDOMError(t) ? "DOMError" : "DOMException";
    }
    getValue(t) {
        var i = t.name || (this.isDOMError(t) ? "DOMError" : "DOMException");
        return t.message ? i + ": " + t.message : i;
    }
    isDOMException(t) {
        return J(t, "DOMException");
    }
    isDOMError(t) {
        return J(t, "DOMError");
    }
}
class qi {
    match(t) {
        return K(t);
    }
    coerce(t, i) {
        var e, r = this.getStack(t), s = void 0 === r;
        return {
            type: this.getType(t),
            value: this.getMessage(t, i),
            stack: null != r ? r : null == (e = i.syntheticException) ? void 0 : e.stack,
            cause: t.cause ? i.next(t.cause) : void 0,
            synthetic: s
        };
    }
    getType(t) {
        return t.name || t.constructor.name;
    }
    getMessage(t, i) {
        var e = t.message;
        return String(e.error && "string" == typeof e.error.message ? e.error.message : e);
    }
    getStack(t) {
        return t.stacktrace || t.stack || void 0;
    }
}
class Vi {
    match(t) {
        return !!J(t, "ErrorEvent") && (null != t.error || this.Vi(t));
    }
    coerce(t, i) {
        var e;
        if (null != t.error) return i.apply(t.error);
        var r = i.apply(t.message);
        return _({}, r, {
            stack: null !== (e = this.Zi(t)) && void 0 !== e ? e : r.stack,
            synthetic: !0
        });
    }
    Vi(t) {
        return N(t.message) && t.message.length > 0;
    }
    Zi(t) {
        var i, e, r = t, s = null !== (i = r.lineno) && void 0 !== i ? i : 0, n = null !== (e = r.colno) && void 0 !== e ? e : 0;
        if (N(r.filename) && 0 !== r.filename.length && 0 !== s) return "Error\n    at " + r.filename + ":" + s + ":" + n;
    }
}
var Wi = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/i;
class Gi {
    match(t) {
        return "string" == typeof t;
    }
    coerce(t, i) {
        var e, r = this.getInfos(t), s = r[0], n = r[1];
        return {
            type: null != s ? s : "Error",
            value: null != n ? n : t,
            stack: null == (e = i.syntheticException) ? void 0 : e.stack,
            synthetic: !0
        };
    }
    getInfos(t) {
        var i = "Error", e = t, r = t.match(Wi);
        return r && (i = r[1], e = r[2]), [
            i,
            e
        ];
    }
}
var Ji = [
    "fatal",
    "error",
    "warning",
    "log",
    "info",
    "debug"
];
function Ki(t, i) {
    void 0 === i && (i = 40);
    var e = Object.keys(t);
    if (e.sort(), !e.length) return "[object has no keys]";
    for(var r = e.length; r > 0; r--){
        var s = e.slice(0, r).join(", ");
        if (i >= s.length) return r === e.length ? s : s.length > i ? s.slice(0, i) + "..." : s;
    }
    return "";
}
class Yi {
    match(t) {
        return "object" == typeof t && null !== t;
    }
    coerce(t, i) {
        var e, r, s = this.getErrorPropertyFromObject(t);
        return s ? i.apply(s) : {
            type: this.getType(t),
            value: this.getValue(t),
            stack: null !== (e = this.getStack(t)) && void 0 !== e ? e : null == (r = i.syntheticException) ? void 0 : r.stack,
            level: this.isSeverityLevel(t.level) ? t.level : "error",
            synthetic: !0
        };
    }
    getType(t) {
        if (Y(t)) return t.constructor.name;
        var i = "name" in t ? t.name : void 0;
        return N(i) && !L(i) ? i : "Error";
    }
    getValue(t) {
        if ("name" in t && "string" == typeof t.name) {
            var i = "'" + t.name + "' captured as exception";
            return "message" in t && "string" == typeof t.message && (i += " with message: '" + t.message + "'"), i;
        }
        if ("message" in t && "string" == typeof t.message) return t.message;
        var e = this.getObjectClassName(t);
        return (e && "Object" !== e ? "'" + e + "'" : "Object") + " captured as exception with keys: " + Ki(t);
    }
    isSeverityLevel(t) {
        return N(t) && !L(t) && Ji.indexOf(t) >= 0;
    }
    getStack(t) {
        try {
            return N(t.stacktrace) && t.stacktrace.length > 0 ? t.stacktrace : N(t.stack) && t.stack.length > 0 ? t.stack : void 0;
        } catch (t) {
            return;
        }
    }
    getErrorPropertyFromObject(t) {
        for(var i in t)if (({}).hasOwnProperty.call(t, i)) {
            var e = t[i];
            if (K(e)) return e;
        }
    }
    getObjectClassName(t) {
        try {
            var i = Object.getPrototypeOf(t);
            return i ? i.constructor.name : void 0;
        } catch (t) {
            return;
        }
    }
}
class Qi {
    match(t) {
        return Y(t);
    }
    coerce(t, i) {
        var e, r = t.constructor.name;
        return {
            type: r,
            value: r + " captured as exception with keys: " + Ki(t),
            stack: null == (e = i.syntheticException) ? void 0 : e.stack,
            synthetic: !0
        };
    }
}
class Xi {
    match(t) {
        return G(t);
    }
    coerce(t, i) {
        var e;
        return {
            type: "Error",
            value: "Primitive value captured as exception: " + String(t),
            stack: null == (e = i.syntheticException) ? void 0 : e.stack,
            synthetic: !0
        };
    }
}
class Zi {
    match(t) {
        return J(t, "PromiseRejectionEvent") || this.isCustomEventWrappingRejection(t);
    }
    isCustomEventWrappingRejection(t) {
        if (!Y(t)) return !1;
        try {
            var i = t.detail;
            return null != i && "object" == typeof i && "reason" in i;
        } catch (t) {
            return !1;
        }
    }
    coerce(t, i) {
        var e, r = this.getUnhandledRejectionReason(t);
        return G(r) ? {
            type: "UnhandledRejection",
            value: "Non-Error promise rejection captured with value: " + String(r),
            stack: null == (e = i.syntheticException) ? void 0 : e.stack,
            synthetic: !0
        } : i.apply(r);
    }
    getUnhandledRejectionReason(t) {
        try {
            if ("reason" in t) return t.reason;
            if ("detail" in t && null != t.detail && "object" == typeof t.detail && "reason" in t.detail) return t.detail.reason;
        } catch (t) {}
        return t;
    }
}
var te = "$message", ie = "$timestamp", ee = new Set([
    te,
    ie
]), re = {
    enabled: !0,
    max_bytes: 32768
};
function se(t) {
    var i;
    return t ? {
        enabled: null !== (i = t.enabled) && void 0 !== i ? i : re.enabled,
        max_bytes: oe(t.max_bytes, re.max_bytes)
    } : _({}, re);
}
class ne {
    constructor(t){
        this.Pn = [], this.Fn = 0, this.mn = se(t);
    }
    setConfig(t) {
        this.mn = se(t), this.$n();
    }
    add(t) {
        var i = function(t) {
            var i;
            try {
                i = x(t);
            } catch (t) {
                return;
            }
            try {
                var e = JSON.parse(i);
                if (!A(e)) return;
                var r = e, s = r[te], n = r[ie];
                if (!N(s) || 0 === s.trim().length) return;
                if (!N(n) && !B(n)) return;
                return {
                    step: r,
                    json: i
                };
            } catch (t) {
                return;
            }
        }(t);
        if (i) {
            var e = function(t) {
                if ("u" > typeof TextEncoder) return (new TextEncoder).encode(t).length;
                for(var i = encodeURIComponent(t), e = 0, r = 0; i.length > r; r++)"%" === i[r] ? (e += 1, r += 2) : e += 1;
                return e;
            }(i.json);
            e > this.mn.max_bytes || (this.Pn.push({
                step: i.step,
                bytes: e
            }), this.Fn += e, this.$n());
        }
    }
    getAttachable() {
        return this.Pn.map((t)=>t.step);
    }
    clear() {
        this.Pn = [], this.Fn = 0;
    }
    size() {
        return this.Pn.length;
    }
    $n() {
        for(; this.Fn > this.mn.max_bytes && this.Pn.length > 0;){
            var t = this.Pn.shift();
            t && (this.Fn -= t.bytes);
        }
    }
}
function oe(t, i) {
    if (!B(t) || 1 / 0 === t || -1 / 0 === t) return i;
    var e = Math.floor(t);
    return 0 > e ? i : e;
}
var ae = (t)=>{
    if ("string" != typeof t) return t;
    try {
        return JSON.parse(t);
    } catch (i) {
        return t;
    }
};
function le(t) {
    return "string" == typeof t || t;
}
function he(t) {
    return "string" == typeof t ? t : void 0;
}
var ue, de = [
    "$feature_flag",
    "$feature_flag_response",
    "$feature_flag_has_experiment",
    "$feature_flag_id",
    "$feature_flag_version",
    "$feature_flag_reason",
    "$feature_flag_request_id",
    "$feature_flag_evaluated_at",
    "$feature_flag_error",
    "locally_evaluated",
    "$groups",
    "$process_person_profile",
    "$geoip_disable",
    "$current_url",
    "$pathname",
    "$referring_domain",
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_content",
    "utm_term",
    "gad_source",
    "mc_cid",
    "gclid",
    "gclsrc",
    "dclid",
    "gbraid",
    "wbraid",
    "fbclid",
    "msclkid",
    "twclid",
    "li_fat_id",
    "igshid",
    "ttclid",
    "rdt_cid",
    "epik",
    "qclid",
    "sccid",
    "irclid",
    "_kx",
    "$session_id",
    "$window_id",
    "$lib",
    "$lib_version",
    "$device_id",
    "$is_server"
], ve = "NativeGzipValidationError", ce = (t)=>t.length >= 2 && 31 === t[0] && 139 === t[1], fe = (t, i)=>t === k.GZipJS || i === k.GZipJS || "gzip" === i, pe = (t)=>!(!t || "object" != typeof t) && "NotReadableError" === ("name" in t ? String(t.name) : ""), _e = (t)=>{
    throw ki(ve, "Native gzip produced invalid output: " + t);
}, ge = function() {
    var t = p(function*(t, i) {
        18 > t.size && _e("too-short");
        var e = new Uint8Array((yield t.slice(0, 10).arrayBuffer()));
        ce(e) && 8 === e[2] || _e("invalid-header");
        var r = new DataView((yield t.slice(t.size - 8).arrayBuffer()));
        r.getUint32(0, !0) !== ((t)=>{
            for(var i = (()=>{
                if (ue) return ue;
                ue = [];
                for(var t = 0; 256 > t; t++){
                    for(var i = t, e = 0; 8 > e; e++)i = 1 & i ? 3988292384 ^ i >>> 1 : i >>> 1;
                    ue[t] = i >>> 0;
                }
                return ue;
            })(), e = 4294967295, r = 0; t.length > r; r++)e = i[255 & (e ^ t[r])] ^ e >>> 8;
            return (4294967295 ^ e) >>> 0;
        })(i) && _e("invalid-crc");
        var s = i.length >>> 0;
        r.getUint32(4, !0) !== s && _e("invalid-size");
    });
    return function(i, e) {
        return t.apply(this, arguments);
    };
}();
function me() {
    return me = p(function*(t, i, e) {
        void 0 === i && (i = !0);
        try {
            var r = (new TextEncoder).encode(t), s = new globalThis.CompressionStream("gzip"), n = s.writable.getWriter(), o = n.write(r).then(()=>n.close()).catch(function() {
                var t = p(function*(t) {
                    try {
                        yield n.abort(t);
                    } catch (t) {}
                    throw t;
                });
                return function(i) {
                    return t.apply(this, arguments);
                };
            }()), a = new Response(s.readable).blob(), l = (yield Promise.all([
                a,
                o
            ]))[0];
            return yield ge(l, r), l;
        } catch (t) {
            if (null != e && e.rethrow) throw t;
            return i && console.error("Failed to gzip compress data", t), null;
        }
    }), me.apply(this, arguments);
}
var be = 0x8000000000000000, ye = "9223372036854775808", we = {}.propertyIsEnumerable;
function Se(t, i) {
    try {
        return ke(t, i, {
            ancestors: new WeakSet,
            remainingNodes: fi
        }, 0);
    } catch (t) {
        return [];
    }
}
function xe(t, i, e, r) {
    if (0 >= e.remainingNodes) return {
        stringValue: _i
    };
    if (e.remainingNodes--, H(t)) return {
        boolValue: t
    };
    if ("bigint" == typeof t) return function(t, i) {
        var e = t.toString(), r = BigInt(ye);
        return t >= r || -r > t ? (null == i || i.debug("Attribute " + e + " is outside the int64 range; encoding it as a string"), {
            stringValue: e
        }) : {
            intValue: e
        };
    }(t, i);
    if ("number" == typeof t) {
        if (!Number.isFinite(t)) return {
            stringValue: String(t)
        };
        if (Number.isInteger(t)) {
            if (Number.isSafeInteger(t)) return {
                intValue: String(t)
            };
            if (typeof BigInt > "u") return {
                stringValue: String(t)
            };
            var s = BigInt(t).toString();
            return t >= be || -be > t ? (null == i || i.debug("Attribute " + s + " is outside the int64 range; encoding it as a string"), {
                stringValue: s
            }) : {
                intValue: s
            };
        }
        return {
            doubleValue: t
        };
    }
    if ("string" == typeof t) return {
        stringValue: bi(t)
    };
    if ("function" == typeof t) return {
        stringValue: mi
    };
    if ("symbol" == typeof t) return {
        stringValue: String(t)
    };
    if ("object" == typeof t && null !== t) {
        if (e.ancestors.has(t)) return {
            stringValue: pi
        };
        if (r >= vi) return {
            stringValue: _i
        };
        if (t instanceof Date) {
            var n = t.getTime(), o = Number.isFinite(n) ? t.toISOString() : String(t);
            return {
                stringValue: "string" == typeof o ? bi(o) : String(o)
            };
        }
        e.ancestors.add(t);
        try {
            try {
                var a = t.toJSON;
                if ("function" == typeof a) return xe(a.call(t), i, e, r + 1);
            } catch (t) {}
            return I(t) ? {
                arrayValue: {
                    values: Ee(t, i, e, r + 1)
                }
            } : {
                kvlistValue: {
                    values: ke(t, i, e, r + 1)
                }
            };
        } finally{
            e.ancestors.delete(t);
        }
    }
    return {
        stringValue: bi(String(t))
    };
}
function Ee(t, i, e, r) {
    for(var s = [], n = Math.min(t.length, ci), o = 0; n > o && e.remainingNodes > 0; o++)try {
        var a = o in t ? t[o] : void 0;
        if (U(a)) continue;
        s.push(xe(a, i, e, r));
    } catch (t) {
        s.push({
            stringValue: gi
        });
    }
    return t.length > o && s.push({
        stringValue: _i
    }), s;
}
function ke(t, i, e, r) {
    var s = [];
    for(var n in t)if (we.call(t, n)) {
        if (!n) {
            null == i || i.debug("Dropping an attribute with an empty key");
            continue;
        }
        if (s.length >= ci || 0 >= e.remainingNodes) {
            null == i || i.debug("Attributes truncated: the value exceeds the OTLP encoder budget");
            break;
        }
        try {
            var o = t[n];
            if (j(o) || D(o)) continue;
            s.push({
                key: bi(n),
                value: xe(o, i, e, r)
            });
        } catch (t) {
            s.push({
                key: bi(n),
                value: {
                    stringValue: gi
                }
            });
        }
    }
    return s;
}
function Te(t, i, e) {
    return _({}, t.resourceAttributes, {
        "service.name": t.serviceName || "unknown_service"
    }, t.environment && {
        "deployment.environment": t.environment
    }, t.serviceVersion && {
        "service.version": t.serviceVersion
    }, {
        "telemetry.sdk.name": i,
        "telemetry.sdk.version": e
    });
}
var $e = {
    darwin: "macOS",
    win32: "Windows",
    linux: "Linux",
    android: "Android",
    freebsd: "FreeBSD",
    openbsd: "OpenBSD",
    sunos: "SunOS",
    aix: "AIX",
    "Mac OS X": "macOS"
};
var Pe = {
    trace: {
        text: "TRACE",
        number: 1
    },
    debug: {
        text: "DEBUG",
        number: 5
    },
    info: {
        text: "INFO",
        number: 9
    },
    warn: {
        text: "WARN",
        number: 13
    },
    error: {
        text: "ERROR",
        number: 17
    },
    fatal: {
        text: "FATAL",
        number: 21
    }
}, Re = Pe.info;
function Ce(t) {
    try {
        return bi(String(t));
    } catch (t) {
        return gi;
    }
}
function Oe(t, i, e, r) {
    var s, n = Pe[t.level || "info"] || Re, o = n.text, a = n.number, l = (void 0 === (s = B(r) ? r : void 0) && (s = Date.now()), String(s) + "000000"), h = {};
    i.distinctId && (h.posthogDistinctId = i.distinctId), i.sessionId && (h.sessionId = i.sessionId), i.windowId && (h["window.id"] = i.windowId), U(i.sessionStartTimestamp) || (h.sessionStartTimestamp = String(i.sessionStartTimestamp)), U(i.lastActivityTimestamp) || (h.lastActivityTimestamp = String(i.lastActivityTimestamp)), i.currentUrl && (h["url.full"] = i.currentUrl), i.screenName && (h["screen.name"] = i.screenName), i.appState && (h["app.state"] = i.appState), i.activeFeatureFlags && i.activeFeatureFlags.length > 0 && (h.feature_flags = i.activeFeatureFlags);
    var u = _({}, h), d = t.attributes;
    if (d) {
        var v = [];
        try {
            v = Object.keys(d);
        } catch (t) {
            v = [];
        }
        for (var c of v){
            var f = void 0;
            try {
                f = d[c];
            } catch (t) {
                f = gi;
            }
            Object.defineProperty(u, c, {
                value: f,
                enumerable: !0,
                writable: !0,
                configurable: !0
            });
        }
    }
    var p = {
        timeUnixNano: l,
        observedTimeUnixNano: l,
        severityNumber: a,
        severityText: o,
        body: {
            stringValue: Ce(t.body)
        },
        attributes: Se(u, e)
    };
    return t.trace_id && (p.traceId = t.trace_id), t.span_id && (p.spanId = t.span_id), D(t.trace_flags) || (p.flags = t.trace_flags), p;
}
function Ie(t, i, e) {
    return Te(t, i, e);
}
function Fe(t, i, e, r) {
    return {
        resourceLogs: [
            {
                resource: {
                    attributes: Se(i)
                },
                scopeLogs: [
                    {
                        scope: {
                            name: e,
                            version: r
                        },
                        logRecords: t
                    }
                ]
            }
        ]
    };
}
let Ae = class {
    constructor(t, i, e, r, s, n, o){
        var a;
        void 0 === n && (n = ()=>Promise.resolve()), this._instance = t, this.mn = i, this.A = e, this.Nn = r, this.qn = s, this.jn = n, this.Bn = o, this.Hn = null, this.zn = 0, this.Un = 0, this.Wn = 0, this.Vn = 0, this.Gn = 0, this.Zn = !1, this.Qn = i.maxBufferSize, this.Jn = Math.max(null !== (a = i.maxQueueSize) && void 0 !== a ? a : i.maxBufferSize, i.maxBufferSize), this.Kn = i.flushIntervalMs, this.Yn = i.maxBatchRecordsPerPost, this.Xn = i.rateCapWindowMs, this.ts = i.maxLogsPerInterval;
    }
    clearQueue() {
        this.Un++, this._instance.setPersistedProperty(E.LogsQueue, []);
    }
    reset() {
        this.es(), this.Vn = 0, this.Gn = 0, this.Zn = !1, this.Wn = 0, this.Yn = this.mn.maxBatchRecordsPerPost;
    }
    onReconnect() {
        this.Wn = 0, this.rs();
    }
    captureLog(t, i) {
        var e;
        if (!this._instance.isDisabled && !this._instance.optedOut && null != t && t.body) {
            var r = this.ns(t);
            if (null !== r) if (r.body) {
                if (this.ss()) {
                    var s = {
                        record: Oe(r, null !== (e = null == i ? void 0 : i.context) && void 0 !== e ? e : this.Nn(), this.A, null == i ? void 0 : i.occurredAtMs)
                    };
                    this.qn(()=>this.os(s));
                }
            } else this.A.info("Log was rejected in beforeSend function");
        }
    }
    ns(t) {
        var i = this.mn.beforeSend;
        if (!i) return t;
        var e = I(i) ? i : [
            i
        ], r = t;
        for (var s of e)try {
            var n = s(r);
            if (!n) return this.A.info("Log was rejected in beforeSend function"), null;
            r = n;
        } catch (t) {
            return this.A.error("Error in beforeSend function for log:", t), null;
        }
        return r;
    }
    ss() {
        if (void 0 === this.ts) return !0;
        var t = Date.now(), i = t - this.Vn;
        return this.Xn > i && i >= 0 || (this.Vn = t, this.Gn = 0, this.Zn = !1), this.ts > this.Gn ? (this.Gn++, !0) : (this.Zn || (this.A.warn("captureLog dropping logs: exceeded " + this.ts + " logs per " + this.Xn + "ms"), this.Zn = !0), !1);
    }
    flush() {
        var t = this;
        return p(function*() {
            if (!t._instance.isDisabled) return t.Hn || (t.Hn = t.ls().finally(()=>{
                t.Hn = null;
            })), t.Hn;
        })();
    }
    ls() {
        var t = this;
        return p(function*() {
            var i;
            t.es();
            var e = null !== (i = t._instance.getPersistedProperty(E.LogsQueue)) && void 0 !== i ? i : [];
            if (0 !== e.length) for(var r = e.length, s = 0; e.length > 0 && r > s;){
                var n, o, a = t.Un;
                t.zn = 0;
                var l = Math.min(e.length, t.Yn), h = e.slice(0, l), u = Fe(h.map((t)=>t.record), t.us(), null !== (n = t.Bn) && void 0 !== n ? n : t._instance.getLibraryId(), t._instance.getLibraryVersion()), d = yield t._instance.hs(u);
                if (t.Un !== a) return;
                if ("too-large" === d.kind && h.length > 1) t.Yn = Math.max(1, Math.floor(h.length / 2)), t.A.warn("Received 413 when sending logs batch of size " + h.length + ", reducing batch size to " + t.Yn);
                else {
                    if ("retry-later" === d.kind) throw d.error;
                    if ("too-large" === d.kind ? t.A.warn("Dropping a single log record after 413 with batch size 1 — the record is larger than the server cap and cannot be split further.") : "ok" === d.kind && t.mn.maxBatchRecordsPerPost > t.Yn && (t.Yn = Math.min(t.mn.maxBatchRecordsPerPost, t.Yn + 1)), yield t.ds(h.length), e = null !== (o = t._instance.getPersistedProperty(E.LogsQueue)) && void 0 !== o ? o : [], s += h.length, "fatal" === d.kind) throw d.error;
                }
            }
        })();
    }
    ds(t) {
        var i = this;
        return p(function*() {
            var e, r = Math.max(0, t - i.zn), s = null !== (e = i._instance.getPersistedProperty(E.LogsQueue)) && void 0 !== e ? e : [];
            i._instance.setPersistedProperty(E.LogsQueue, s.slice(r)), yield i.jn();
        })();
    }
    us() {
        return Ie(this.mn, this._instance.getLibraryId(), this._instance.getLibraryVersion());
    }
    os(t) {
        var i;
        if (!this._instance.optedOut) {
            var e = null !== (i = this._instance.getPersistedProperty(E.LogsQueue)) && void 0 !== i ? i : [];
            this.Jn > e.length || (e.shift(), this.zn++, this.A.info("Logs queue is full, dropping oldest record.")), e.push(t), this._instance.setPersistedProperty(E.LogsQueue, e), this.Qn > e.length ? this.vs() : this.rs();
        }
    }
    vs(t) {
        void 0 === t && (t = this.Kn), this.cs || (this.cs = $i(()=>{
            this.cs = void 0, this.rs();
        }, t));
    }
    fs() {
        var t = Math.min(Math.max(0, this.Wn - 1), 6);
        return this.Kn * Math.pow(2, t);
    }
    ps() {
        var t = this._instance.getPersistedProperty(E.LogsQueue);
        return !!t && t.length > 0;
    }
    shutdown(t) {
        var i = this;
        return p(function*() {
            i.es();
            var e = i.flush().catch(()=>{});
            void 0 !== t ? yield Pi(e, t) : yield e;
        })();
    }
    flushWithTimeout(t) {
        var i = this;
        return p(function*() {
            var e = i.flush();
            yield Pi(e, t, ()=>{
                e.catch(()=>{});
            });
        })();
    }
    rs() {
        this.flush().then(()=>{
            this.Wn = 0;
        }, (t)=>{
            this.Wn++, this.A.error("PostHog logs flush failed:", t);
        }).finally(()=>{
            !this._instance.isDisabled && this.ps() && this.vs(this.fs());
        });
    }
    es() {
        this.cs && (clearTimeout(this.cs), this.cs = void 0);
    }
};
var Me = [
    0,
    5,
    10,
    25,
    50,
    75,
    100,
    250,
    500,
    750,
    1e3,
    2500,
    5e3,
    7500,
    1e4
];
function De(t) {
    return String(t) + "000000";
}
function Ne(t, i, e, r) {
    var s = "";
    return r && (s = Object.keys(r).sort().map((t)=>JSON.stringify(t) + ":" + JSON.stringify(r[t])).join(",")), t + "\0" + i + "\0" + (null != e ? e : "") + "\0" + s;
}
let Le = class {
    constructor(t, i, e){
        this._instance = t, this.mn = i, this.A = e, this.gs = new Map, this.Hn = null, this.ys = !1, this.bs = new Map, this._s = new Set, this.ws = 0;
    }
    count(t, i, e) {
        void 0 === i && (i = 1), this.ks({
            name: t,
            type: "count",
            value: i,
            unit: null == e ? void 0 : e.unit,
            attributes: null == e ? void 0 : e.attributes
        });
    }
    gauge(t, i, e) {
        this.ks({
            name: t,
            type: "gauge",
            value: i,
            unit: null == e ? void 0 : e.unit,
            attributes: null == e ? void 0 : e.attributes
        });
    }
    histogram(t, i, e) {
        this.ks({
            name: t,
            type: "histogram",
            value: i,
            unit: null == e ? void 0 : e.unit,
            attributes: null == e ? void 0 : e.attributes
        });
    }
    flush() {
        var t = this, i = this.Hn, e = function() {
            var e = p(function*() {
                i && (yield i.catch(()=>{})), yield t.Ss();
            });
            return function() {
                return e.apply(this, arguments);
            };
        }(), r = e().finally(()=>{
            this.Hn === r && (this.Hn = null);
        });
        return this.Hn = r, r;
    }
    drainWindow() {
        if (0 === this.gs.size) return null;
        var t = this.gs;
        return this.gs = new Map, this.ys = !1, this.bs = new Map, this._s = new Set, this.xs(t);
    }
    reset() {
        this.ws++, this.es(), this.gs = new Map, this.Hn = null, this.ys = !1, this.bs = new Map, this._s = new Set;
    }
    ks(t) {
        if (!this._instance.isDisabled && !this._instance.optedOut) {
            var i = this.ns(t);
            if (null !== i) if (i.name && "string" == typeof i.name) if ("number" == typeof i.value && Number.isFinite(i.value)) if ("count" === i.type && 0 > i.value) this.A.warn("Dropping count '" + i.name + "': counters are monotonic, value must be >= 0");
            else {
                var e, r;
                try {
                    e = i.attributes ? _({}, i.attributes) : void 0, r = Ne(i.type, i.name, i.unit, e);
                } catch (t) {
                    return void this.A.warn("Dropping metric '" + i.name + "': attributes could not be serialized", t);
                }
                var s = this.gs.get(r);
                if (!s) {
                    if (!this.Cs()) return;
                    s = {
                        name: i.name,
                        type: i.type,
                        unit: i.unit,
                        attributes: e,
                        windowStartMs: Date.now()
                    }, this.gs.set(r, s);
                }
                var n = this.bs.get(i.name);
                void 0 === n ? this.bs.set(i.name, i.type) : n === i.type || this._s.has(i.name) || (this._s.add(i.name), this.A.warn("Metric name '" + i.name + "' is already used as a " + n + "; recording it as a " + i.type + " too will blend both series in charts. Use a distinct name.")), this.Ts(s, i.value), this.vs();
            }
            else this.A.warn("Dropping metric '" + i.name + "': value must be a finite number");
            else this.A.warn("Dropping metric with empty name");
        }
    }
    Cs() {
        return this.mn.maxSeriesPerFlush > this.gs.size || (this.ys || (this.ys = !0, this.A.warn("Metric series cap reached (" + this.mn.maxSeriesPerFlush + " per flush window); dropping new series until the next flush. Reduce attribute cardinality.")), !1);
    }
    Ts(t, i) {
        var e;
        switch(t.type){
            case "count":
                t.total = (null !== (e = t.total) && void 0 !== e ? e : 0) + i;
                break;
            case "gauge":
                t.last = i;
                break;
            case "histogram":
                t.hist || (t.hist = {
                    count: 0,
                    sum: 0,
                    min: i,
                    max: i,
                    bucketCounts: new Array(Me.length + 1).fill(0)
                });
                var r = t.hist;
                r.count += 1, r.sum += i, r.min = Math.min(r.min, i), r.max = Math.max(r.max, i), r.bucketCounts[function(t, i) {
                    for(var e = 0; i.length > e; e++)if (i[e] >= t) return e;
                    return i.length;
                }(i, Me)] += 1;
        }
    }
    ns(t) {
        var i = this.mn.beforeSend;
        if (!i) return t;
        var e = I(i) ? i : [
            i
        ], r = t;
        for (var s of e)try {
            var n = s(r);
            if (!n) return this.A.info("Metric was rejected in beforeSend function"), null;
            r = n;
        } catch (t) {
            return this.A.error("Error in beforeSend function for metric:", t), null;
        }
        return r;
    }
    vs() {
        this.cs || (this.cs = $i(()=>{
            this.cs = void 0, this.flush().catch((t)=>{
                this.A.error("Metrics flush failed:", t);
            });
        }, this.mn.flushIntervalMs));
    }
    es() {
        this.cs && (clearTimeout(this.cs), this.cs = void 0);
    }
    Ss() {
        var t = this;
        return p(function*() {
            if (0 !== t.gs.size) {
                var i = t.gs;
                t.gs = new Map, t.ys = !1, t.bs = new Map, t._s = new Set;
                var e = t.ws, r = yield t._instance.Ms(t.xs(i));
                if (e === t.ws) switch(r.kind){
                    case "ok":
                        return;
                    case "retry-later":
                        return t.Is(i), void t.vs();
                    case "too-large":
                        return void t.A.warn("Metrics batch exceeded the server size limit and was dropped");
                    case "fatal":
                        return void t.A.error("Failed to send metrics batch:", r.error);
                }
            }
        })();
    }
    xs(t) {
        return i = this.Es(t), e = function(t, i, e) {
            return Te(t, i, e);
        }(this.mn, this._instance.getLibraryId(), this._instance.getLibraryVersion()), r = this._instance.getLibraryId(), s = this._instance.getLibraryVersion(), {
            resourceMetrics: [
                {
                    resource: {
                        attributes: Se(e)
                    },
                    scopeMetrics: [
                        {
                            scope: {
                                name: r,
                                version: s
                            },
                            metrics: i
                        }
                    ]
                }
            ]
        };
        //TURBOPACK unreachable
        ;
        var i, e, r, s;
    }
    Es(t) {
        var i = De(Date.now()), e = new Map;
        for (var r of t.values()){
            var s, n = Ne(r.type, r.name, r.unit, void 0), o = e.get(n);
            o || (o = _({
                name: r.name
            }, r.unit && {
                unit: r.unit
            }), "count" === r.type ? o.sum = {
                aggregationTemporality: 1,
                isMonotonic: !0,
                dataPoints: []
            } : "gauge" === r.type ? o.gauge = {
                dataPoints: []
            } : o.histogram = {
                aggregationTemporality: 1,
                dataPoints: []
            }, e.set(n, o));
            var a = Se(null !== (s = r.attributes) && void 0 !== s ? s : {}, this.A), l = De(r.windowStartMs);
            if ("count" === r.type) {
                var h, u = {
                    attributes: a,
                    startTimeUnixNano: l,
                    timeUnixNano: i,
                    asDouble: null !== (h = r.total) && void 0 !== h ? h : 0
                };
                o.sum.dataPoints.push(u);
            } else if ("gauge" === r.type) {
                var d, v = {
                    attributes: a,
                    timeUnixNano: i,
                    asDouble: null !== (d = r.last) && void 0 !== d ? d : 0
                };
                o.gauge.dataPoints.push(v);
            } else r.hist && o.histogram.dataPoints.push({
                attributes: a,
                startTimeUnixNano: l,
                timeUnixNano: i,
                count: r.hist.count,
                sum: r.hist.sum,
                min: r.hist.min,
                max: r.hist.max,
                bucketCounts: r.hist.bucketCounts,
                explicitBounds: Me
            });
        }
        return Array.from(e.values());
    }
    Is(t) {
        var i, e;
        for (var r of t){
            var s = r[0], n = r[1], o = this.gs.get(s);
            if (o) switch(o.windowStartMs = Math.min(o.windowStartMs, n.windowStartMs), o.type){
                case "count":
                    o.total = (null !== (i = o.total) && void 0 !== i ? i : 0) + (null !== (e = n.total) && void 0 !== e ? e : 0);
                    break;
                case "gauge":
                    break;
                case "histogram":
                    if (n.hist) if (o.hist) {
                        o.hist.count += n.hist.count, o.hist.sum += n.hist.sum, o.hist.min = Math.min(o.hist.min, n.hist.min), o.hist.max = Math.max(o.hist.max, n.hist.max);
                        for(var a = 0; o.hist.bucketCounts.length > a; a++)o.hist.bucketCounts[a] += n.hist.bucketCounts[a];
                    } else o.hist = n.hist;
            }
            else this.Cs() && this.gs.set(s, n);
        }
    }
};
var je = function(i, e) {
    var r = (void 0 === e ? {} : e).debugEnabled, s = {
        q (e) {
            if (t && (c.DEBUG || t.POSTHOG_DEBUG || r) && !D(t.console) && t.console) {
                for(var s = ("__rrweb_original__" in t.console[e]) ? t.console[e].__rrweb_original__ : t.console[e], n = arguments.length, o = new Array(n > 1 ? n - 1 : 0), a = 1; n > a; a++)o[a - 1] = arguments[a];
                s(i, ...o);
            }
        },
        debug () {
            for(var t = arguments.length, i = new Array(t), e = 0; t > e; e++)i[e] = arguments[e];
            s.q("debug", ...i);
        },
        info () {
            for(var t = arguments.length, i = new Array(t), e = 0; t > e; e++)i[e] = arguments[e];
            s.q("log", ...i);
        },
        warn () {
            for(var t = arguments.length, i = new Array(t), e = 0; t > e; e++)i[e] = arguments[e];
            s.q("warn", ...i);
        },
        error () {
            for(var t = arguments.length, i = new Array(t), e = 0; t > e; e++)i[e] = arguments[e];
            s.q("error", ...i);
        },
        critical () {
            for(var t = arguments.length, e = new Array(t), r = 0; t > r; r++)e[r] = arguments[r];
            console.error(i, ...e);
        },
        uninitializedWarning (t) {
            s.error("You must initialize PostHog before calling " + t);
        },
        createLogger: (t, e)=>je(i + " " + t, e)
    };
    return s;
}, Ue = je("[PostHog.js]"), Be = Ue.createLogger, ze = Be("[ExternalScriptsLoader]"), He = (t)=>{
    var i = null == r ? void 0 : r.querySelectorAll("script");
    if (i) {
        for(var e = 0; i.length > e; e++)if (i[e].src === t || i[e].getAttribute("src") === t) return i[e];
    }
}, qe = (t, i, e)=>{
    if (t.config.disable_external_dependency_loading) return ze.warn(i + " was requested but loading of external scripts is disabled."), e("Loading of external scripts is disabled");
    var s = He(i);
    if (s) {
        if (s.__posthog_loading_callback_fired) return e();
        var n = s.__posthog_loading_error;
        return n ? e(n) : (s.addEventListener("load", (t)=>{
            s.__posthog_loading_callback_fired = !0, e(void 0, t);
        }), void s.addEventListener("error", (t)=>{
            s.__posthog_loading_error = t, e(t);
        }));
    }
    var o = ()=>{
        if (!r) return e("document not found");
        if (He(i)) return qe(t, i, e);
        var s = r.createElement("script");
        if (s.type = "text/javascript", s.crossOrigin = "anonymous", s.src = i, s.onload = (t)=>{
            s.__posthog_loading_callback_fired = !0, e(void 0, t);
        }, s.onerror = (t)=>{
            s.__posthog_loading_error = t, e(t);
        }, t.config.prepare_external_dependency_script && (s = t.config.prepare_external_dependency_script(s)), !s) return e("prepare_external_dependency_script returned null");
        if ("head" === t.config.external_scripts_inject_target) r.head.appendChild(s);
        else {
            var n, o = r.querySelectorAll("body > script");
            o.length > 0 ? null == (n = o[0].parentNode) || n.insertBefore(s, o[0]) : r.body.appendChild(s);
        }
    };
    null != r && r.body ? o() : null == r || r.addEventListener("DOMContentLoaded", o);
}, Ve = {}, We = (t, i)=>{
    var e = "/static/" + i + ".js?v=" + t.version;
    if ("toolbar" === i) {
        var r = 3e5;
        e = e + "&t=" + Math.floor(Date.now() / r) * r;
    }
    return t.requestRouter.endpointFor("assets", e);
};
v.__PosthogExtensions__ = v.__PosthogExtensions__ || {}, v.__PosthogExtensions__.loadExternalDependency = (t, i, e)=>{
    if ("remote-config" !== i) {
        var r = t.config.strict_script_versioning;
        if (r) {
            var s = t.requestRouter.endpointFor("assets", "/static/" + t.version + "/" + i + ".js"), n = Ve[s];
            if ("fallback" === r && n) {
                if (He(n)) return void qe(t, n, e);
                delete Ve[s];
            }
            qe(t, s, "fallback" === r ? (r, n)=>{
                if (r) if ("string" == typeof r) e(r);
                else {
                    var o, a = We(t, i);
                    Ve[s] = a;
                    var l = He(s);
                    null == l || null == (o = l.parentNode) || o.removeChild(l), qe(t, a, e);
                }
                else e(void 0, n);
            } : e);
        } else qe(t, We(t, i), e);
    } else {
        var o = t.requestRouter.endpointFor("assets", "/array/" + t.config.token + "/config.js");
        qe(t, o, e);
    }
}, v.__PosthogExtensions__.loadSiteApp = (t, i, e)=>{
    var r = t.requestRouter.endpointFor("api", i);
    qe(t, r, e);
};
c.DEBUG = !1, c.LIB_VERSION = "1.426.3", c.LIB_NAME = "web";
var Ge = "$people_distinct_id", Je = "distinct_id", Ke = "$device_id", Ye = "$device_model", Qe = "__alias", Xe = "$fbc", Ze = "$fbc_persistence", tr = "__timers", ir = "$autocapture_disabled_server_side", er = "$heatmaps_enabled_server_side", rr = "$exception_capture_enabled_server_side", sr = "$error_tracking_suppression_rules", nr = "$error_tracking_capture_extension_exceptions", or = "$web_vitals_enabled_server_side", ar = "$dead_clicks_enabled_server_side", lr = "$product_tours_enabled_server_side", hr = "$logs_capture_enabled_server_side", ur = "$web_vitals_allowed_metrics", dr = "$session_recording_remote_config", vr = "$replay_sample_rate", cr = "$replay_override_sampling", fr = "$replay_override_linked_flag", pr = "$replay_override_url_trigger", _r = "$replay_override_event_trigger", gr = "$sesid", mr = "$session_is_sampled", br = "$enabled_feature_flags", yr = "$active_feature_flags", wr = "$early_access_features", Sr = "$feature_flag_details", xr = "$feature_flag_payloads", Er = "$feature_flag_request_id", kr = "$minimal_flag_called_events", Tr = "$override_feature_flags", $r = "$override_feature_flag_payloads", Pr = "$stored_person_properties", Rr = "$stored_group_properties", Cr = "$groups", Or = "$surveys", Ir = "$surveys_loaded_at", Fr = "$surveys_activated", Ar = "$surveys_activated_session", Mr = "$surveys_activated_timestamps", Dr = "ph_product_tours", Nr = "$flag_call_reported", Lr = "$flag_call_reported_session_id", jr = "$feature_flag_errors", Ur = "$feature_flag_evaluated_at", Br = "$user_state", zr = "$client_session_props", Hr = "$capture_rate_limit", qr = "$initial_campaign_params", Vr = "$initial_referrer_info", Wr = "$initial_person_info", Gr = "$epp", Jr = "$posthog_cookieless", Kr = "$cookieless_mode", Yr = "$sdk_debug_extensions_init_method", Qr = "$sdk_debug_extensions_init_time_ms", Xr = "$sdk_debug_recording_script_not_loaded", Zr = "PostHog loadExternalDependency extension not found.", ts = "on_reject", is = "always", es = "anonymous", rs = "identified", ss = "identified_only", ns = "visibilitychange", os = "beforeunload", as = "$pageview", ls = "$pageleave", hs = "$identify", us = "$groupidentify";
function ds(t, i) {
    I(t) && t.forEach(i);
}
function vs(t, i) {
    if (!U(t)) if (I(t)) t.forEach(i);
    else if (q(t)) t.forEach((t, e)=>i(t, e));
    else for(var e in t)C.call(t, e) && i(t[e], e);
}
var cs = function(t) {
    for(var i = arguments.length, e = new Array(i > 1 ? i - 1 : 0), r = 1; i > r; r++)e[r - 1] = arguments[r];
    for (var s of e)for(var n in s)void 0 !== s[n] && (t[n] = s[n]);
    return t;
};
function fs(t) {
    for(var i = Object.keys(t), e = i.length, r = new Array(e); e--;)r[e] = [
        i[e],
        t[i[e]]
    ];
    return r;
}
var ps = function(t) {
    try {
        return t();
    } catch (t) {
        return;
    }
}, _s = function(t) {
    return function() {
        try {
            for(var i = arguments.length, e = new Array(i), r = 0; i > r; r++)e[r] = arguments[r];
            return t.apply(this, e);
        } catch (t) {
            Ue.critical("Implementation error. Please turn on debug mode and open a ticket on https://app.posthog.com/home#panel=support%3Asupport%3A."), Ue.critical(t);
        }
    };
}, gs = function(t) {
    var i = {};
    return vs(t, function(t, e) {
        (N(t) && t.length > 0 || B(t)) && (i[e] = t);
    }), i;
};
var ms = [
    "herokuapp.com",
    "vercel.app",
    "netlify.app"
];
function bs(t) {
    var i = null == t ? void 0 : t.hostname;
    if (!N(i)) return !1;
    var e = i.split(".").slice(-2).join(".");
    for (var r of ms)if (e === r) return !1;
    return !0;
}
function ys(t, i, e, r) {
    var s = null != r ? r : {}, n = s.capture, o = s.passive;
    null == t || t.addEventListener(i, e, {
        capture: void 0 !== n && n,
        passive: void 0 === o || o
    });
}
function ws(t) {
    return "ph_toolbar_internal" === t.name;
}
var Ss = (t)=>{
    if (r) {
        try {
            for(var i = t + "=", e = r.cookie.split(";").filter((t)=>t.length), s = 0; e.length > s; s++){
                for(var n = e[s]; " " == n.charAt(0);)n = n.substring(1, n.length);
                if (0 === n.indexOf(i)) return decodeURIComponent(n.substring(i.length, n.length));
            }
        } catch (t) {}
        return null;
    }
};
Math.trunc || (Math.trunc = function(t) {
    return 0 > t ? Math.ceil(t) : Math.floor(t);
}), Number.isInteger || (Number.isInteger = function(t) {
    return B(t) && isFinite(t) && Math.floor(t) === t;
});
class xs {
    constructor(t){
        if (this.bytes = t, 16 !== t.length) throw new TypeError("not 128-bit length");
    }
    static fromFieldsV7(t, i, e, r) {
        if (!Number.isInteger(t) || !Number.isInteger(i) || !Number.isInteger(e) || !Number.isInteger(r) || 0 > t || 0 > i || 0 > e || 0 > r || t > 0xffffffffffff || i > 4095 || e > 1073741823 || r > 4294967295) throw new RangeError("invalid field value");
        var s = new Uint8Array(16);
        return s[0] = t / Math.pow(2, 40), s[1] = t / Math.pow(2, 32), s[2] = t / Math.pow(2, 24), s[3] = t / Math.pow(2, 16), s[4] = t / 256, s[5] = t, s[6] = 112 | i >>> 8, s[7] = i, s[8] = 128 | e >>> 24, s[9] = e >>> 16, s[10] = e >>> 8, s[11] = e, s[12] = r >>> 24, s[13] = r >>> 16, s[14] = r >>> 8, s[15] = r, new xs(s);
    }
    toString() {
        for(var t = "", i = 0; this.bytes.length > i; i++)t = t + (this.bytes[i] >>> 4).toString(16) + (15 & this.bytes[i]).toString(16), 3 !== i && 5 !== i && 7 !== i && 9 !== i || (t += "-");
        if (36 !== t.length) throw new Error("Invalid UUIDv7 was generated");
        return t;
    }
    clone() {
        return new xs(this.bytes.slice(0));
    }
    equals(t) {
        return 0 === this.compareTo(t);
    }
    compareTo(t) {
        for(var i = 0; 16 > i; i++){
            var e = this.bytes[i] - t.bytes[i];
            if (0 !== e) return Math.sign(e);
        }
        return 0;
    }
}
class Es {
    generate() {
        var t = this.generateOrAbort();
        if (!D(t)) return t;
        this.Kr = 0;
        var i = this.generateOrAbort();
        if (D(i)) throw new Error("Could not generate UUID after timestamp reset");
        return i;
    }
    generateOrAbort() {
        var t = Date.now();
        if (t > this.Kr) this.Kr = t, this.Xr();
        else {
            if (this.Kr >= t + 1e4) return;
            this.ei++, this.ei > 4398046511103 && (this.Kr++, this.Xr());
        }
        return xs.fromFieldsV7(this.Kr, Math.trunc(this.ei / Math.pow(2, 30)), this.ei & Math.pow(2, 30) - 1, this.ti.nextUint32());
    }
    Xr() {
        this.ei = 1024 * this.ti.nextUint32() + (1023 & this.ti.nextUint32());
    }
    constructor(){
        this.Kr = 0, this.ei = 0, this.ti = new $s;
    }
}
var ks, Ts = (t)=>{
    if ("u" > typeof UUIDV7_DENY_WEAK_RNG && UUIDV7_DENY_WEAK_RNG) throw new Error("no cryptographically strong RNG available");
    for(var i = 0; t.length > i; i++)t[i] = 65536 * Math.trunc(65536 * Math.random()) + Math.trunc(65536 * Math.random());
    return t;
};
t && !D(t.crypto) && crypto.getRandomValues && (Ts = (t)=>crypto.getRandomValues(t));
class $s {
    nextUint32() {
        return this.Pt.length > this.ri || (Ts(this.Pt), this.ri = 0), this.Pt[this.ri++];
    }
    constructor(){
        this.Pt = new Uint32Array(8), this.ri = 1 / 0;
    }
}
var Ps = ()=>Rs().toString(), Rs = ()=>(ks || (ks = new Es)).generate(), Cs = "", Os = /[a-z0-9][a-z0-9-]+\.[a-z]{2,}$/i;
var Is = null, Fs = {
    ii () {
        if (!j(Is)) return Is;
        if (Is = !1, r) try {
            var t = "__ph_cookie_support_" + Ps();
            Fs.ni(t, "xyz"), Is = '"xyz"' === Ss(t), Fs.oi(t);
        } catch (t) {
            Is = !1;
        }
        return Is;
    },
    si (t) {
        Ue.error("cookieStore error: " + t);
    },
    ai: Ss,
    ui (t) {
        var i;
        try {
            i = JSON.parse(Fs.ai(t)) || {};
        } catch (t) {}
        return i;
    },
    ni (t, i, e, s, n) {
        if (!r) return !1;
        try {
            var o = "", a = "", l = function(t, i) {
                if (i) {
                    var e = function(t, i) {
                        if (void 0 === i && (i = r), Cs) return Cs;
                        if (!i) return "";
                        if ([
                            "localhost",
                            "127.0.0.1"
                        ].includes(t)) return "";
                        for(var e = t.split("."), s = Math.min(e.length, 8), n = "dmn_chk_" + Ps(); !Cs && s--;){
                            var o = e.slice(s).join("."), a = n + "=1;domain=." + o + ";path=/";
                            i.cookie = a + ";max-age=3", i.cookie.includes(n) && (i.cookie = a + ";max-age=0", Cs = o);
                        }
                        return Cs;
                    }(t);
                    if (!e) {
                        var s = ((t)=>{
                            var i = t.match(Os);
                            return i ? i[0] : "";
                        })(t);
                        s !== e && Ue.info("Warning: cookie subdomain discovery mismatch", s, e), e = s;
                    }
                    return e ? "; domain=." + e : "";
                }
                return "";
            }(r.location.hostname, s);
            if (e) {
                var h = new Date;
                h.setTime(h.getTime() + 864e5 * e), o = "; expires=" + h.toUTCString();
            }
            n && (a = "; secure");
            var u = t + "=" + encodeURIComponent(JSON.stringify(i)) + o + "; SameSite=Lax; path=/" + l + a;
            return u.length > 3686.4 && Ue.warn("cookieStore warning: large cookie, len=" + u.length), r.cookie = u, !0;
        } catch (t) {
            return !1;
        }
    },
    oi (t, i) {
        if (null != r && r.cookie) try {
            Fs.ni(t, "", -1, i);
        } catch (t) {
            return;
        }
    }
}, As = null, Ms = {
    ii () {
        if (!j(As)) return As;
        var i = !0;
        if (D(t)) i = !1;
        else try {
            var e = "__mplssupport__";
            Ms.ni(e, "xyz"), '"xyz"' !== Ms.ai(e) && (i = !1), Ms.oi(e);
        } catch (t) {
            i = !1;
        }
        return i || Ue.error("localStorage unsupported; falling back to cookie store"), As = i, i;
    },
    si (t) {
        Ue.error("localStorage error: " + t);
    },
    ai (i) {
        try {
            return null == t ? void 0 : t.localStorage.getItem(i);
        } catch (t) {
            Ms.si(t);
        }
        return null;
    },
    ui (t) {
        try {
            return JSON.parse(Ms.ai(t)) || {};
        } catch (t) {}
        return null;
    },
    ni (i, e) {
        try {
            return null == t || t.localStorage.setItem(i, JSON.stringify(e)), !0;
        } catch (t) {
            Ms.si(t);
        }
        return !1;
    },
    oi (i) {
        try {
            null == t || t.localStorage.removeItem(i);
        } catch (t) {
            Ms.si(t);
        }
    }
}, Ds = [
    Pr,
    yr,
    br,
    Sr,
    xr,
    Er,
    Ur,
    jr,
    Nr
], Ns = [
    Ke,
    Je,
    gr,
    mr,
    Gr,
    Wr,
    Ze,
    Br
], Ls = (t)=>t + "_cpm", js = [
    "__proto__",
    "constructor",
    "prototype"
], Us = (t)=>{
    if (!A(t)) return {};
    var i = {};
    return Object.keys(t).forEach((e)=>{
        -1 === js.indexOf(e) && (i[e] = t[e]);
    }), i;
}, Bs = function(t, i) {
    void 0 === i && (i = []);
    var e = {};
    return [
        ...Ns,
        ...i
    ].forEach((i)=>{
        var r = t[i];
        D(r) || j(r) || "" === r || (e[i] = r);
    }), e;
}, zs = (t)=>{
    for(var i = 5381, e = 2166136261, r = 0; t.length > r; r++){
        var s = t.charCodeAt(r);
        i = 33 * i ^ s, e = Math.imul(e ^ s, 16777619);
    }
    return t.length.toString(36) + "." + (i >>> 0).toString(36) + "." + (e >>> 0).toString(36);
}, Hs = (t, i)=>({
        p: i,
        f: zs(JSON.stringify(t))
    }), qs = (t, i)=>{
    if (!i) return {
        properties: [],
        isValid: !1
    };
    try {
        var e = Fs.ui(Ls(t)), r = (null == e ? void 0 : e.f) === zs(i) && I(e.p);
        return {
            properties: r ? e.p : [],
            isValid: r
        };
    } catch (t) {
        return {
            properties: [],
            isValid: !1
        };
    }
}, Vs = (t, i)=>i + "|" + (Fs.ai(Ls(t)) || ""), Ws = {}, Gs = {
    ii: ()=>!0,
    si (t) {
        Ue.error("memoryStorage error: " + t);
    },
    ai: (t)=>t in Ws ? Ws[t] : null,
    ui: (t)=>t in Ws ? Ws[t] : null,
    ni: (t, i)=>(Ws[t] = i, !0),
    oi (t) {
        delete Ws[t];
    }
}, Js = null, Ks = {
    ii () {
        if (!j(Js)) return Js;
        if (Js = !0, D(t)) Js = !1;
        else try {
            var i = "__support__";
            Ks.ni(i, "xyz"), '"xyz"' !== Ks.ai(i) && (Js = !1), Ks.oi(i);
        } catch (t) {
            Js = !1;
        }
        return Js;
    },
    si (t) {
        Ue.error("sessionStorage error: ", t);
    },
    ai (i) {
        try {
            return null == t ? void 0 : t.sessionStorage.getItem(i);
        } catch (t) {
            Ks.si(t);
        }
        return null;
    },
    ui (t) {
        try {
            return JSON.parse(Ks.ai(t)) || null;
        } catch (t) {}
        return null;
    },
    ni (i, e) {
        try {
            return null == t || t.sessionStorage.setItem(i, JSON.stringify(e)), !0;
        } catch (t) {
            Ks.si(t);
        }
        return !1;
    },
    oi (i) {
        try {
            null == t || t.sessionStorage.removeItem(i);
        } catch (t) {
            Ks.si(t);
        }
    }
};
class Ys {
    constructor(t){
        this._instance = t;
    }
    get mn() {
        return this._instance.config;
    }
    get consent() {
        return this.Vs() ? 0 : this.Gs;
    }
    isOptedOut() {
        return this.mn.cookieless_mode === is || this.isRejected() || -1 === this.consent && this.mn.cookieless_mode === ts;
    }
    isOptedIn() {
        return !this.isOptedOut();
    }
    isExplicitlyOptedOut() {
        return 0 === this.consent;
    }
    isRejected() {
        return 0 === this.consent || -1 === this.consent && this.mn.opt_out_capturing_by_default;
    }
    optInOut(t) {
        this.Zs.ni(this.Qs, t ? 1 : 0, this.mn.cookie_expiration, this.mn.cross_subdomain_cookie, this.mn.secure_cookie);
    }
    reset() {
        this.Zs.oi(this.Qs, this.mn.cross_subdomain_cookie);
    }
    get Qs() {
        var t = this._instance.config, i = t.token, e = t.opt_out_capturing_cookie_prefix;
        return t.consent_persistence_name || (e ? e + i : "__ph_opt_in_out_" + i);
    }
    get Gs() {
        var t = this.Zs.ai(this.Qs);
        return Z(t) ? 1 : y(tt, t) ? 0 : -1;
    }
    get Zs() {
        var t = this.mn.opt_out_capturing_persistence_type, i = "localStorage" === t ? Ms : Fs, e = i.ii() ? i : Gs;
        if (!this.Js || this.Js !== e) {
            this.Js = e;
            var r = "localStorage" === t ? Fs : Ms;
            r.ai(this.Qs) && (this.Js.ai(this.Qs) || this.optInOut(Z(r.ai(this.Qs))), r.oi(this.Qs, this.mn.cross_subdomain_cookie));
        }
        return this.Js;
    }
    Vs() {
        return !!this.mn.respect_dnt && [
            null == e ? void 0 : e.doNotTrack,
            null == e ? void 0 : e.msDoNotTrack,
            v.doNotTrack,
            null == e ? void 0 : e.globalPrivacyControl
        ].some((t)=>Z(t));
    }
}
function Qs(t, i) {
    var e, r = null == t || null == (e = t.config) ? void 0 : e.get_current_url;
    if (!F(r)) return i;
    try {
        var s = r(i);
        return N(s) && s ? s : i;
    } catch (t) {
        return Ue.error("Error in get_current_url, falling back to window.location.href", t), i;
    }
}
var Xs = "__POSTHOG_TOOLBAR__", Zs = 1, tn = 3, en = 11;
function rn(t) {
    return t instanceof Element && (t.id === Xs || !(null == t.closest || !t.closest(".toolbar-global-fade-container")));
}
function sn(t) {
    return !!t && t.nodeType === Zs;
}
function nn(t, i) {
    return !!t && !!t.tagName && t.tagName.toLowerCase() === i.toLowerCase();
}
function on(t) {
    return !!t && t.nodeType === tn;
}
function an(t) {
    return !!t && t.nodeType === en && sn(t.host);
}
var ln = 1e3;
function hn(t) {
    return t ? w(t).split(/\s+/) : [];
}
function un(i, e) {
    var r = function(i) {
        var e, r = null == t || null == (e = t.location) ? void 0 : e.href;
        return D(r) ? void 0 : Qs(i, r);
    }(e);
    return !!(r && i && i.some((t)=>r.match(t)));
}
function dn(t) {
    var i = "";
    switch(typeof t.className){
        case "string":
            i = t.className;
            break;
        case "object":
            i = (t.className && "baseVal" in t.className ? t.className.baseVal : null) || t.getAttribute("class") || "";
            break;
        default:
            i = "";
    }
    return hn(i);
}
function vn(t) {
    return U(t) ? null : w(t).split(/(\s+)/).filter((t)=>Dn(t)).join("").replace(/[\r\n]/g, " ").replace(/[ ]+/g, " ").substring(0, 255);
}
function cn(t) {
    var i = "";
    return $n(t) && !Pn(t) && t.childNodes && t.childNodes.length && vs(t.childNodes, function(t) {
        var e;
        on(t) && t.textContent && (i += null !== (e = vn(t.textContent)) && void 0 !== e ? e : "");
    }), w(i);
}
function fn(t) {
    var i;
    return D(t.target) ? t.srcElement || null : null != (i = t.target) && i.shadowRoot ? t.composedPath()[0] || null : t.target || null;
}
var pn = [
    "a",
    "button",
    "form",
    "input",
    "select",
    "textarea",
    "label"
];
function _n(t, i) {
    if (D(i)) return !0;
    var e, r = function(t) {
        if (i.some((i)=>(function(t, i) {
                var e = t.matches || t.matchesSelector || t.msMatchesSelector || t.mozMatchesSelector || t.webkitMatchesSelector || t.oMatchesSelector;
                try {
                    return !!e && e.call(t, i);
                } catch (t) {
                    return !1;
                }
            })(t, i))) return {
            v: !0
        };
    };
    for (var s of t)if (e = r(s)) return e.v;
    return !1;
}
function gn(t) {
    var i = t.parentNode;
    return !(!i || !sn(i)) && i;
}
var mn = [
    ".ph-no-autocapture",
    "[data-ph-no-autocapture]"
], bn = [
    "next",
    "previous",
    "prev",
    ">",
    "<"
], yn = [
    ...bn,
    "+",
    "-",
    "−",
    "–"
], wn = (t, i)=>/[a-z0-9]/i.test(i) ? t.includes(i) : t === i, Sn = [
    ".ph-no-rageclick",
    ".ph-no-capture"
], xn = [
    "",
    "text",
    "search",
    "email",
    "password",
    "url",
    "tel",
    "number"
];
function En(i, e) {
    if (!t || kn(i)) return !1;
    var r, s, n, o, a;
    if (H(e) ? (r = !!e && Sn, s = void 0, n = !1) : (r = null !== (o = null == e ? void 0 : e.css_selector_ignorelist) && void 0 !== o ? o : Sn, s = null == e ? void 0 : e.content_ignorelist, n = null !== (a = null == e ? void 0 : e.ignore_text_selection) && void 0 !== a && a), !1 === r) return !1;
    if (n && function(t) {
        return !(!t || !sn(t)) && (!!nn(t, "textarea") || (nn(t, "input") ? y(xn, (t.getAttribute("type") || "").toLowerCase()) : function(t) {
            if (t.isContentEditable) return !0;
            var i = null == t.getAttribute ? void 0 : t.getAttribute("contenteditable");
            return "true" === i || "" === i;
        }(t)));
    }(i)) return !1;
    var l = Tn(i, !1).targetElementList;
    return !function(t, i) {
        if (!1 === t || D(t)) return !1;
        var e;
        if (!0 === t) e = bn;
        else {
            if (!I(t)) return !1;
            if (t.length > 10) return Ue.error("[PostHog] content_ignorelist array cannot exceed 10 items. Use css_selector_ignorelist for more complex matching."), !1;
            e = t.map((t)=>t.toLowerCase());
        }
        return i.some((t)=>{
            var i = t.safeText, r = t.ariaLabel;
            return e.some((t)=>wn(i, t) || wn(r, t));
        });
    }(s, l.map((t)=>{
        var i;
        return {
            safeText: cn(t).toLowerCase(),
            ariaLabel: (null == (i = t.getAttribute("aria-label")) ? void 0 : i.toLowerCase().trim()) || ""
        };
    })) && !_n(l, r);
}
var kn = (t)=>!t || nn(t, "html") || !sn(t), Tn = (i, e)=>{
    if (!t || kn(i)) return {
        parentIsUsefulElement: !1,
        targetElementList: []
    };
    for(var r = !1, s = [
        i
    ], n = i; n.parentNode && !nn(n, "body");)if (an(n.parentNode)) s.push(n.parentNode.host), n = n.parentNode.host;
    else {
        var o = gn(n);
        if (!o) break;
        if (e || pn.indexOf(o.tagName.toLowerCase()) > -1) r = !0;
        else try {
            var a = t.getComputedStyle(o);
            a && "pointer" === a.getPropertyValue("cursor") && (r = !0);
        } catch (t) {}
        s.push(o), n = o;
    }
    return {
        parentIsUsefulElement: r,
        targetElementList: s
    };
};
function $n(t) {
    for(var i = new Set, e = 0, r = t; r.parentNode && !nn(r, "body"); r = r.parentNode){
        if (e++ >= ln || i.has(r)) return !1;
        i.add(r);
        var s = dn(r);
        if (y(s, "ph-sensitive") || y(s, "ph-no-capture")) return !1;
    }
    if (y(dn(t), "ph-include")) return !0;
    var n = t.type || "";
    if (N(n)) switch(n.toLowerCase()){
        case "hidden":
        case "password":
            return !1;
    }
    var o = t.name || t.id || "";
    return !N(o) || !/^cc|cardnum|ccnum|creditcard|csc|cvc|cvv|exp|pass|pwd|routing|seccode|securitycode|securitynum|socialsec|socsec|ssn/i.test(o.replace(/[^a-zA-Z0-9]/g, ""));
}
function Pn(t) {
    return !!(nn(t, "input") && ![
        "button",
        "checkbox",
        "submit",
        "reset"
    ].includes(t.type) || nn(t, "select") || nn(t, "textarea") || "true" === t.getAttribute("contenteditable"));
}
var Rn = new RegExp("^(?:(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(6(?:011|5[0-9]{2})[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|((?:2131|1800|35[0-9]{3})[0-9]{11}))$"), Cn = /(^|[^0-9A-Za-z_])([0-9][0-9 -]*[0-9])(?=$|[^0-9A-Za-z_])/g, On = [
    16,
    15,
    14,
    13
], In = new RegExp("^(\\d{3}-?\\d{2}-?\\d{4})$"), Fn = new RegExp("(^|[^0-9])((?!000|666)[0-9]{3}-?(?!00)[0-9]{2}-?(?!0000)[0-9]{4})(?=$|([^0-9]))", "g"), An = /[0-9A-Za-z_]/;
function Mn(t) {
    for(var i = 0, e = !1, r = t.length - 1; r >= 0; r--){
        var s = t.charCodeAt(r) - 48;
        e && (s *= 2) > 9 && (s -= 9), i += s, e = !e;
    }
    return i % 10 == 0;
}
function Dn(t, i) {
    if (void 0 === i && (i = !0), U(t)) return !1;
    if (N(t)) {
        t = w(t);
        var e = i ? Rn.test((t || "").replace(/[- ]/g, "")) : function(t) {
            var i;
            for(Cn.lastIndex = 0; i = Cn.exec(t);){
                var e = i[2];
                if (e) for(var r = e.replace(/[- ]/g, ""), s = 0; r.length > s; s++)for (var n of On){
                    var o = s + n;
                    if (r.length >= o) {
                        var a = r.slice(s, o);
                        if (Rn.test(a) && Mn(a)) return !0;
                    }
                }
            }
            return !1;
        }(t);
        if (e) return !1;
        var r = i ? In.test(t) : function(t) {
            var i;
            for(Fn.lastIndex = 0; i = Fn.exec(t);){
                var e = i[1], r = i[3];
                if (!(e && r && An.test(e) && An.test(r))) return !0;
            }
            return !1;
        }(t);
        if (r) return !1;
    }
    return !0;
}
function Nn(t) {
    var i = cn(t);
    return Dn(i = (i + " " + Ln(t)).trim()) ? i : "";
}
function Ln(t) {
    var i = "";
    return t && t.childNodes && t.childNodes.length && vs(t.childNodes, function(t) {
        var e;
        if (t && "span" === (null == (e = t.tagName) ? void 0 : e.toLowerCase())) try {
            var r = cn(t);
            i = (i + " " + r).trim(), t.childNodes && t.childNodes.length && (i = (i + " " + Ln(t)).trim());
        } catch (t) {
            Ue.error("[AutoCapture]", t);
        }
    }), i;
}
function jn(t) {
    return t.replace(/"|\\"/g, '\\"');
}
function Un(t) {
    var i = t.attr__class;
    if (i) return I(i) ? i : hn(i);
}
var Bn = Be("[Dead Clicks]"), zn = ()=>!0, Hn = (t)=>{
    var i, e = !(null == (i = t.instance.persistence) || !i.get_property(ar)), r = t.instance.config.capture_dead_clicks;
    return H(r) ? r : !!A(r) || e;
};
class qn {
    get lazyLoadedDeadClicksAutocapture() {
        return this.Ks;
    }
    constructor(t, i, e){
        this.instance = t, this.isEnabled = i, this.onCapture = e, this.startIfEnabledOrStop();
    }
    onRemoteConfig(t) {
        if (t.ok) {
            var i = t.config;
            "captureDeadClicks" in i && (this.instance.persistence && this.instance.persistence.register({
                [ar]: i.captureDeadClicks
            }), this.startIfEnabledOrStop());
        }
    }
    startIfEnabledOrStop() {
        this.isEnabled(this) ? this.Ys(()=>{
            this.Xs();
        }) : this.stop();
    }
    Ys(t) {
        var i, e;
        null != (i = v.__PosthogExtensions__) && i.initDeadClicksAutocapture ? t() : null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this.instance, "dead-clicks-autocapture", (i)=>{
            i ? Bn.error("failed to load script", i) : t();
        });
    }
    Xs() {
        var t;
        if (r) {
            if (!this.Ks && null != (t = v.__PosthogExtensions__) && t.initDeadClicksAutocapture) {
                var i = A(this.instance.config.capture_dead_clicks) ? _({}, this.instance.config.capture_dead_clicks) : {};
                i.__onCapture = this.onCapture, this.onCapture && (i.capture_dead_swipes = !1), this.Ks = v.__PosthogExtensions__.initDeadClicksAutocapture(this.instance, i), this.Ks.start(r), Bn.info("starting...");
            }
        } else Bn.error("`document` not found. Cannot start.");
    }
    stop() {
        this.Ks && (this.Ks.stop(), this.Ks = void 0, Bn.info("stopping..."));
    }
}
var Vn = Be("[SegmentIntegration]");
function Wn(t, i, e) {
    void 0 === e && (e = !0);
    var r = t.config.segment;
    if (!r) return i();
    !function(t, i, e) {
        var r = t.config.segment;
        if (!r) return i();
        var s = (r)=>{
            var s = ()=>r.anonymousId() || Ps();
            t.config.get_device_id = s, e && r.id() && (t.register({
                distinct_id: r.id(),
                $device_id: s()
            }), t.persistence.set_property(Br, rs)), i(e ? void 0 : r.anonymousId() || void 0);
        }, n = r.user();
        "then" in n && F(n.then) ? n.then(s) : s(n);
    }(t, (e)=>{
        r.register(((t, i)=>{
            "undefined" != typeof Promise && Promise.resolve || Vn.warn("This browser does not have Promise support, and can not use the segment integration");
            var e = (e, r)=>{
                if (!r) return e;
                var s = !!i && e.event.anonymousId === i && !e.event.userId;
                s || e.event.userId || e.event.anonymousId === t.get_distinct_id() || (Vn.info("No userId set, resetting PostHog"), t.reset()), s || (i = void 0), e.event.userId && e.event.userId !== t.get_distinct_id() && (Vn.info("UserId set, identifying with PostHog"), t.identify(e.event.userId));
                var n = t.calculateEventProperties(r, e.event.properties);
                return e.event.properties = Object.assign({}, n, e.event.properties), e;
            };
            return {
                name: "PostHog JS",
                type: "enrichment",
                version: "1.0.0",
                isLoaded () {
                    return !0;
                },
                load () {
                    return Promise.resolve();
                },
                track (t) {
                    return e(t, t.event.event);
                },
                page (t) {
                    return e(t, as);
                },
                identify (t) {
                    return e(t, hs);
                },
                screen (t) {
                    return e(t, "$screen");
                }
            };
        })(t, e)).then(()=>{
            i();
        }, (t)=>{
            Vn.error("Failed to register the Segment integration", t), i();
        });
    }, e);
}
var Gn = "posthog-js";
function Jn(t, i) {
    var e = void 0 === i ? {} : i, r = e.organization, s = e.projectId, n = e.prefix, o = e.severityAllowList, a = void 0 === o ? [
        "error"
    ] : o, l = e.sendExceptionsToPostHog, h = void 0 === l || l;
    return (i)=>{
        var e, o, l, u, d;
        if ("*" !== a && !a.includes(i.level) || !t.__loaded) return i;
        i.tags || (i.tags = {});
        var v = t.requestRouter.endpointFor("ui", "/project/" + t.config.token + "/person/" + t.get_distinct_id());
        i.tags["PostHog Person URL"] = v, t.sessionRecordingStarted() && (i.tags["PostHog Recording URL"] = t.get_session_replay_url({
            withTimestamp: !0
        }));
        var c, f = (null == (e = i.exception) ? void 0 : e.values) || [], p = f.map((t)=>_({}, t, {
                stacktrace: t.stacktrace ? _({}, t.stacktrace, {
                    type: "raw",
                    frames: (t.stacktrace.frames || []).map((t)=>_({}, t, {
                            platform: "web:javascript"
                        }))
                }) : void 0
            })), g = {
            $exception_message: (null == (o = f[0]) ? void 0 : o.value) || i.message,
            $exception_type: null == (l = f[0]) ? void 0 : l.type,
            $exception_level: i.level,
            $exception_list: p,
            $sentry_event_id: i.event_id,
            $sentry_exception: i.exception,
            $sentry_exception_message: (null == (u = f[0]) ? void 0 : u.value) || i.message,
            $sentry_exception_type: null == (d = f[0]) ? void 0 : d.type,
            $sentry_tags: i.tags
        };
        return r && s && (g.$sentry_url = (n || "https://sentry.io/organizations/") + r + "/issues/?project=" + s + "&query=" + i.event_id), h && (null == (c = t.exceptions) || c.sendExceptionEvent(g)), i;
    };
}
class Kn {
    constructor(t, i, e, r, s, n){
        this.name = Gn, this.setupOnce = function(o) {
            o(Jn(t, {
                organization: i,
                projectId: e,
                prefix: r,
                severityAllowList: s,
                sendExceptionsToPostHog: null == n || n
            }));
        };
    }
}
class Yn {
    constructor(t){
        this.ta = (t, i, e)=>{
            e && (e.noSessionId || e.activityTimeout || e.sessionPastMaximumLength || e.crossTabAdoption) && (Ue.info("[PageViewManager] Session rotated, clearing pageview state", {
                sessionId: t,
                changeReason: e
            }), this.ea = void 0, this._instance.scrollManager.resetContext());
        }, this._instance = t, this.ia();
    }
    ia() {
        var t;
        this.ra = null == (t = this._instance.sessionManager) ? void 0 : t.onSessionId(this.ta);
    }
    destroy() {
        var t;
        null == (t = this.ra) || t.call(this), this.ra = void 0;
    }
    doPageView(i, e) {
        var r, s = this.na(i, e);
        return this.ea = {
            pathname: null !== (r = null == t ? void 0 : t.location.pathname) && void 0 !== r ? r : "",
            pageViewId: e,
            timestamp: i
        }, this._instance.scrollManager.resetContext(), s;
    }
    doPageLeave(t) {
        var i;
        return this.na(t, null == (i = this.ea) ? void 0 : i.pageViewId);
    }
    doEvent() {
        var t;
        return {
            $pageview_id: null == (t = this.ea) ? void 0 : t.pageViewId
        };
    }
    na(t, i) {
        var e = this.ea;
        if (!e) return {
            $pageview_id: i
        };
        var r = {
            $pageview_id: i,
            $prev_pageview_id: e.pageViewId
        }, s = this._instance.scrollManager.getContext();
        if (s && !this._instance.config.disable_scroll_properties) {
            var n = s.maxScrollHeight, o = s.lastScrollY, a = s.maxScrollY, l = s.maxContentHeight, h = s.lastContentY, u = s.maxContentY;
            if (!(D(n) || D(o) || D(a) || D(l) || D(h) || D(u))) {
                n = Math.ceil(n), o = Math.ceil(o), a = Math.ceil(a), l = Math.ceil(l), h = Math.ceil(h), u = Math.ceil(u);
                var d = n > 1 ? it(o / n, 0, 1, Ue) : 1, v = n > 1 ? it(a / n, 0, 1, Ue) : 1, c = l > 1 ? it(h / l, 0, 1, Ue) : 1, f = l > 1 ? it(u / l, 0, 1, Ue) : 1;
                r = cs(r, {
                    $prev_pageview_last_scroll: o,
                    $prev_pageview_last_scroll_percentage: d,
                    $prev_pageview_max_scroll: a,
                    $prev_pageview_max_scroll_percentage: v,
                    $prev_pageview_last_content: h,
                    $prev_pageview_last_content_percentage: c,
                    $prev_pageview_max_content: u,
                    $prev_pageview_max_content_percentage: f
                });
            }
        }
        return e.pathname && (r.$prev_pageview_pathname = e.pathname), e.timestamp && (r.$prev_pageview_duration = (t.getTime() - e.timestamp.getTime()) / 1e3), r;
    }
}
var Qn = [
    "flags",
    "surveys"
], Xn = {
    [Ge]: {
        exposure: "hidden"
    },
    [Qe]: {
        exposure: "hidden"
    },
    __cmpns: {
        exposure: "hidden"
    },
    [tr]: {
        exposure: "hidden"
    },
    [Ze]: {
        exposure: "hidden"
    },
    [ir]: {
        exposure: "event"
    },
    [er]: {
        exposure: "hidden"
    },
    [hr]: {
        exposure: "hidden"
    },
    [rr]: {
        exposure: "event"
    },
    [sr]: {
        exposure: "hidden"
    },
    [nr]: {
        exposure: "event"
    },
    [or]: {
        exposure: "event"
    },
    [ar]: {
        exposure: "event"
    },
    [lr]: {
        exposure: "hidden"
    },
    [ur]: {
        exposure: "event"
    },
    [dr]: {
        exposure: "hidden"
    },
    $session_recording_enabled_server_side: {
        exposure: "hidden"
    },
    [gr]: {
        exposure: "hidden"
    },
    [mr]: {
        exposure: "event"
    },
    [vr]: {
        exposure: "event",
        shouldSkipFromEventProperties: (t)=>j(t)
    },
    $session_past_minimum_duration: {
        exposure: "event"
    },
    $session_recording_url_trigger_activated_session: {
        exposure: "event"
    },
    $session_recording_event_trigger_activated_session: {
        exposure: "event"
    },
    $debug_first_full_snapshot_timestamp: {
        exposure: "event"
    },
    $sess_rec_flush_size: {
        exposure: "hidden"
    },
    [br]: {
        exposure: "hidden",
        storageGroup: "flags"
    },
    [yr]: {
        exposure: "hidden",
        storageGroup: "flags"
    },
    [wr]: {
        exposure: "hidden"
    },
    [Sr]: {
        exposure: "hidden",
        storageGroup: "flags"
    },
    [xr]: {
        exposure: "hidden",
        storageGroup: "flags"
    },
    [Er]: {
        exposure: "hidden",
        storageGroup: "flags",
        volatile: !0
    },
    [kr]: {
        exposure: "hidden",
        storageGroup: "flags"
    },
    [Tr]: {
        exposure: "hidden"
    },
    [$r]: {
        exposure: "hidden"
    },
    [Pr]: {
        exposure: "hidden"
    },
    [Rr]: {
        exposure: "hidden"
    },
    [Or]: {
        exposure: "hidden",
        storageGroup: "surveys"
    },
    [Ir]: {
        exposure: "hidden",
        storageGroup: "surveys",
        volatile: !0
    },
    [Fr]: {
        exposure: "event"
    },
    [Ar]: {
        exposure: "hidden"
    },
    [Mr]: {
        exposure: "hidden"
    },
    [Dr]: {
        exposure: "hidden"
    },
    $product_tours_activated: {
        exposure: "hidden"
    },
    $product_tours_activated_session: {
        exposure: "hidden"
    },
    $conversations_widget_session_id: {
        exposure: "event"
    },
    $conversations_ticket_id: {
        exposure: "event"
    },
    $conversations_widget_state: {
        exposure: "event"
    },
    $conversations_user_traits: {
        exposure: "event"
    },
    [Nr]: {
        exposure: "hidden"
    },
    [Lr]: {
        exposure: "hidden"
    },
    [Cr]: {
        exposure: "event"
    },
    [jr]: {
        exposure: "hidden"
    },
    [Ur]: {
        exposure: "hidden",
        storageGroup: "flags",
        volatile: !0
    },
    [Br]: {
        exposure: "hidden"
    },
    [zr]: {
        exposure: "hidden"
    },
    [Hr]: {
        exposure: "hidden"
    },
    [qr]: {
        exposure: "hidden"
    },
    [Vr]: {
        exposure: "hidden"
    },
    [Wr]: {
        exposure: "hidden"
    },
    [Gr]: {
        exposure: "hidden"
    },
    [cr]: {
        exposure: "event"
    },
    [fr]: {
        exposure: "event"
    },
    [pr]: {
        exposure: "event"
    },
    [_r]: {
        exposure: "event"
    },
    [Yr]: {
        exposure: "event"
    },
    [Qr]: {
        exposure: "event"
    },
    [Xr]: {
        exposure: "event"
    },
    $sdk_debug_replay_event_trigger_status: {
        exposure: "event"
    },
    $sdk_debug_replay_linked_flag_trigger_status: {
        exposure: "event"
    },
    $sdk_debug_replay_matched_recording_trigger_groups: {
        exposure: "event"
    },
    $sdk_debug_replay_pending_trigger_conditions: {
        exposure: "event"
    },
    $sdk_debug_replay_remote_trigger_matching_config: {
        exposure: "event"
    },
    $sdk_debug_replay_trigger_groups_count: {
        exposure: "event"
    },
    $sdk_debug_replay_url_trigger_status: {
        exposure: "event"
    },
    $session_recording_start_reason: {
        exposure: "event"
    }
}, Zn = [
    [
        "$posthog_sr_group_event_trigger_",
        {
            exposure: "hidden"
        }
    ],
    [
        "$posthog_sr_group_url_trigger_",
        {
            exposure: "hidden"
        }
    ],
    [
        "$posthog_sr_group_sampling_",
        {
            exposure: "hidden"
        }
    ]
], to = (t)=>{
    var i = Xn[t];
    if (i) return i;
    for (var e of Zn){
        var r = e[1];
        if (0 === t.indexOf(e[0])) return r;
    }
}, io = (t, i)=>{
    try {
        return JSON.stringify(t, (t, i)=>"bigint" == typeof i ? i.toString() : i, i);
    } catch (i) {
        return x(t);
    }
}, eo = (t)=>{
    var i = null == r ? void 0 : r.createElement("a");
    return D(i) ? null : (i.href = t, i);
}, ro = function(t, i) {
    for(var e, r = ((t.split("#")[0] || "").split(/\?(.*)/)[1] || "").replace(/^\?+/g, "").split("&"), s = 0; r.length > s; s++){
        var n = r[s].split("=");
        if (n[0] === i) {
            e = n;
            break;
        }
    }
    if (!I(e) || 2 > e.length) return "";
    var o = e[1];
    try {
        o = decodeURIComponent(o);
    } catch (t) {
        Ue.error("Skipping decoding for malformed query param: " + o);
    }
    return o.replace(/\+/g, " ");
}, so = function(t, i, e) {
    if (!t || !i || !i.length) return t;
    for(var r = t.split("#"), s = r[1], n = (r[0] || "").split("?"), o = n[1], a = n[0], l = (o || "").split("&"), h = [], u = 0; l.length > u; u++){
        var d = l[u].split("=");
        I(d) && (i.includes(d[0]) ? h.push(d[0] + "=" + e) : h.push(l[u]));
    }
    var v = a;
    return null != o && (v += "?" + h.join("&")), null != s && (v += "#" + s), v;
}, no = function(t, i) {
    var e = t.match(new RegExp(i + "=([^&]*)"));
    return e ? e[1] : null;
}, oo = (t, i)=>t >= i && u(), ao = (t, i, e, r)=>{
    if (0 === t) {
        if (u()) {
            var s = i + 1;
            return s === e && r(), s;
        }
        return i;
    }
    return 0;
}, lo = "https?://(.*)", ho = [
    "gclid",
    "gclsrc",
    "dclid",
    "gbraid",
    "wbraid",
    "fbclid",
    "msclkid",
    "twclid",
    "li_fat_id",
    "igshid",
    "ttclid",
    "rdt_cid",
    "epik",
    "qclid",
    "sccid",
    "irclid",
    "_kx"
], uo = [
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_content",
    "utm_term",
    "gad_source",
    "mc_cid",
    ...ho
], vo = "<masked>", co = [
    "li_fat_id"
];
function fo(t, i, e) {
    if (!r) return {};
    var s, n = i ? [
        ...ho,
        ...e || []
    ] : [], o = po(so(r.URL, n, vo), t), a = (s = {}, vs(co, function(t) {
        var i = Ss(t);
        s[t] = i || null;
    }), s);
    return cs(a, o);
}
function po(t, i) {
    var e = uo.concat(i || []), r = {};
    return vs(e, function(i) {
        var e = ro(t, i);
        r[i] = e || null;
    }), r;
}
function _o(t) {
    var i = function(t) {
        return t ? 0 === t.search(lo + "google.([^/?]*)") ? "google" : 0 === t.search(lo + "bing.com") ? "bing" : 0 === t.search(lo + "yahoo.com") ? "yahoo" : 0 === t.search(lo + "duckduckgo.com") ? "duckduckgo" : null : null;
    }(t), e = "yahoo" != i ? "q" : "p", s = {};
    if (!j(i)) {
        s.$search_engine = i;
        var n = r ? ro(r.referrer, e) : "";
        n.length && (s.ph_keyword = n);
    }
    return s;
}
function go() {
    return navigator.language || navigator.userLanguage;
}
var mo = "$direct";
function bo() {
    return (null == r ? void 0 : r.referrer) || mo;
}
function yo(t, i, e) {
    void 0 === e && (e = !1);
    var r = t ? [
        ...ho,
        ...i || []
    ] : [], n = e ? Ti(null == s ? void 0 : s.href) : null == s ? void 0 : s.href, o = null == n ? void 0 : n.substring(0, 1e3);
    return {
        r: bo().substring(0, 1e3),
        u: o ? so(o, r, vo) : void 0
    };
}
function wo(t, i) {
    var e;
    void 0 === i && (i = !1);
    var r = t.r, s = t.u, n = i ? Ti(s) : s, o = {
        $referrer: r,
        $referring_domain: null == r ? void 0 : r == mo ? mo : null == (e = eo(r)) ? void 0 : e.host
    };
    if (n) {
        o.$current_url = n;
        var a = eo(n);
        o.$host = null == a ? void 0 : a.host, o.$pathname = null == a ? void 0 : a.pathname;
        var l = po(n);
        cs(o, l);
    }
    if (r) {
        var h = _o(r);
        cs(o, h);
    }
    return o;
}
function So() {
    try {
        return Intl.DateTimeFormat().resolvedOptions().timeZone;
    } catch (t) {
        return;
    }
}
function xo() {
    try {
        return (new Date).getTimezoneOffset();
    } catch (t) {
        return;
    }
}
var Eo = {
    flags: Ur,
    surveys: Ir
}, ko = [
    "cookie",
    "localstorage",
    "localstorage+cookie",
    "sessionstorage",
    "memory"
], To = (t)=>t + "_cookie_identity_change_pending", $o = (t)=>{
    var i = "", e = 0;
    for (var r of t){
        var s = encodeURIComponent(JSON.stringify(r).slice(1, -1)).length;
        if (e + s > 1e3) break;
        i += r, e += s;
    }
    return i;
}, Po = "main", Ro = [
    br,
    yr,
    Sr,
    xr,
    Er,
    Ur,
    kr,
    Pr
], Co = (t)=>-1 !== Ro.indexOf(t), Oo = (t, i)=>{
    try {
        return JSON.stringify(t) === JSON.stringify(i);
    } catch (e) {
        return t === i;
    }
}, Io = (t)=>{
    if (!t) return {};
    var i = JSON.parse(t);
    return A(i) ? i : {};
}, Fo = (t, i)=>{
    vs(t, (e, r)=>{
        var s = to(r);
        s && "event" !== s.exposure || ({}).hasOwnProperty.call(i, r) || delete t[r];
    });
};
class Ao {
    constructor(i, e, r){
        if (void 0 === r && (r = !0), this.sa = {}, this.aa = !1, this.oa = !1, this.la = !1, this.ua = !1, this.ha = !1, this.da = new Map, this.va = !1, this.ca = !1, this.fa = !1, this.pa = !1, this.ga = new Set, this.mn = i, this.ma = r, this.props = {}, this.ya = void 0, this.ba = ((t)=>{
            var i = "";
            return t.token && (i = t.token.replace(/\+/g, "PL").replace(/\//g, "SL").replace(/=/g, "EQ")), t.persistence_name ? "ph_" + t.persistence_name : "ph_" + i + "_posthog";
        })(i), this.Zs = this._a(i), this.la = this.wa(i), this.load(), this.ka(), i.debug && Ue.info("Persistence loaded", i.persistence, _({}, this.props)), this.update_config(i, i, e), this.save(), t) {
            var s = ()=>this.flush();
            ys(t, "beforeunload", s, {
                capture: !1
            }), ys(t, "pagehide", s, {
                capture: !1
            }), this.Sa = (i)=>{
                if (this.aa && (!i.storageArea || i.storageArea === (null == t ? void 0 : t.localStorage)) && i.key) if (i.key !== this.ba) {
                    if (this.la) {
                        var e = Qn.find((t)=>i.key === this.xa(t));
                        e && this.Ca(i.key, e);
                    }
                } else this.Ca(i.key, Po);
            }, ys(t, "storage", this.Sa);
        }
    }
    markCrossTabFeatureFlagChanges(t) {
        Object.entries(t).forEach((t)=>{
            var i = t[0], e = t[1], r = this.da.get(i);
            if (Co(i) && !0 !== r) if (!0 !== e) {
                var s = new Set(r || []);
                e.forEach((t)=>s.add(t)), s.size && this.Ta(i, s);
            } else this.Ta(i, !0);
        });
    }
    onCrossTabFeatureFlagChange(t) {
        return this.ga.add(t), ()=>this.ga.delete(t);
    }
    destroy() {
        this.Sa && t && (t.removeEventListener("storage", this.Sa), this.Sa = void 0), this.ga.clear();
    }
    Ca(t, i, e) {
        if (void 0 === e && (e = !0), this.Ma) return !1;
        var r, s;
        try {
            if (s = Ms.ai(t), j(s)) {
                var n = this.Ia(i);
                return n.storageValue = null, i !== Po && (n.persisted = !1), !1;
            }
            r = Io(s);
        } catch (t) {
            return !1;
        }
        var o = i === Po ? r : Ms.ui(this.ba);
        if (o && this.Ea(o)) return !1;
        var a = this.Ra(r, i, e);
        return i === Po && this.la && !Oo(this.Pa().main, r) || this.Aa(r, i, !0, s), a;
    }
    Ea(t) {
        var i = this.props[Je], e = t[Je];
        return !D(i) && !D(e) && i !== e;
    }
    Aa(t, i, e, r) {
        var s = this.Ia(i);
        s.storageValue = r, i !== Po && (s.persisted = e);
        try {
            s.fingerprint = this.Fa(t, i);
        } catch (t) {
            s.fingerprint = void 0;
        }
    }
    Ra(t, i, e) {
        var r = !1;
        return Ro.forEach((e)=>{
            var s, n = null == (s = to(e)) ? void 0 : s.storageGroup;
            if (!(i === Po && this.la && n || i !== Po && n !== i)) {
                var o = e in t, a = this.Oa(e, o ? t[e] : void 0), l = this.da.has(e) ? e in this.props : o;
                l === e in this.props && Oo(a, this.props[e]) || (l ? this.La(e, a, !1) : this.Da(e, !1), r = !0);
            }
        }), r && e && this.ga.forEach((t)=>t()), r;
    }
    $a() {
        if (!this.aa) return !1;
        try {
            this.fa = !1;
            var t, i = Ms.ai(this.ba), e = this.Ia(Po), r = !1, s = !1;
            if (i !== e.storageValue) if (j(i)) e.storageValue = null;
            else {
                if (t = Io(i), this.fa = !this.ca && this.Ea(t), this.fa) return !1;
                s = this.Ra(t, Po, !1), !this.la || Oo(this.Pa().main, t) ? this.Aa(t, Po, !0, i) : e.storageValue = i, r = !0;
            }
            return this.la && Qn.forEach((i)=>{
                var e = Ms.ai(this.xa(i)), n = this.Ia(i), o = t || {}, a = r && Ro.some((t)=>{
                    var e;
                    return (null == (e = to(t)) ? void 0 : e.storageGroup) === i && t in o;
                });
                if (e !== n.storageValue || a) {
                    if (j(e)) return n.storageValue = null, n.persisted = !1, void (a && (s = this.Ra(o, i, !1) || s));
                    var l = Io(e);
                    s = this.Ra(l, i, !1) || s, this.Aa(l, i, !0, e);
                }
            }), s;
        } catch (t) {
            return !1;
        }
    }
    Ta(t, i) {
        this.da.set(t, i);
        var e = to(t);
        null != e && e.volatile || (this.Ia((this.la ? null == e ? void 0 : e.storageGroup : void 0) || Po).fingerprint = void 0, this.Na(t));
    }
    qa() {
        Ro.forEach((t)=>this.da.set(t, !0));
    }
    ka() {
        if (this.aa) try {
            var t = Ms.ai(this.ba), i = Io(t);
            this.Ia(Po).storageValue = t, Ro.forEach((t)=>{
                var e, r = this.la ? null == (e = to(t)) ? void 0 : e.storageGroup : void 0, s = r ? Ms.ai(this.xa(r)) : null;
                if (r) {
                    var n = this.Ia(r);
                    n.storageValue = s, n.persisted = !j(s);
                }
                var o = r && !j(s) ? Io(s) : i;
                t in this.props ? this.ja(t, o[t], this.props[t]) : t in o && this.Ta(t, !0);
            });
        } catch (t) {}
    }
    Oa(t, i) {
        var e = this.da.get(t);
        if (!e) return i;
        if (!0 === e) return this.props[t];
        if (t === yr) {
            var r = new Set(I(i) ? i : []), s = new Set(I(this.props[t]) ? this.props[t] : []);
            return e.forEach((t)=>s.has(t) ? r.add(t) : r.delete(t)), Array.from(r);
        }
        var n = A(i) ? _({}, i) : {}, o = A(this.props[t]) ? this.props[t] : {};
        return e.forEach((t)=>{
            t in o ? n[t] = o[t] : delete n[t];
        }), n;
    }
    ja(t, i, e) {
        if (Co(t)) {
            var r = this.da.get(t);
            if (!0 !== r) {
                var s = i;
                if (this.aa) try {
                    var n, o = this.la ? null == (n = to(t)) ? void 0 : n.storageGroup : void 0, a = o ? this.xa(o) : this.ba;
                    s = Io(Ms.ai(a))[t];
                } catch (t) {}
                var l = new Set(r || []);
                if (t === yr) {
                    if (!D(i) && !I(i) || !D(s) && !I(s) || !I(e)) return void this.Ta(t, !0);
                    var h = new Set(i || []), u = new Set(s || []), d = new Set(e);
                    new Set([
                        ...h,
                        ...d
                    ]).forEach((t)=>{
                        h.has(t) !== d.has(t) && l.add(t);
                    }), l.forEach((t)=>{
                        u.has(t) === d.has(t) && l.delete(t);
                    });
                } else {
                    if (!A(e)) return void (Oo(s, e) ? this.da.delete(t) : this.Ta(t, !0));
                    if (!D(i) && !A(i) || D(i) && M(e) && D(s)) return void this.Ta(t, !0);
                    var v = A(i) ? i : {}, c = A(s) ? s : {};
                    new Set([
                        ...Object.keys(v),
                        ...Object.keys(e)
                    ]).forEach((t)=>{
                        t in v == t in e && Oo(v[t], e[t]) || l.add(t);
                    }), l.forEach((t)=>{
                        t in c == t in e && Oo(c[t], e[t]) && l.delete(t);
                    });
                }
                l.size ? this.Ta(t, l) : this.da.delete(t);
            }
        }
    }
    Ba() {
        var t, i = null == (t = this.mn) ? void 0 : t.persistence_save_debounce_ms;
        return B(i) && i > 0 ? i : 0;
    }
    Ha(t) {
        if (this.mn.cookieWinsOnConflict && "localstorage+cookie" === this.mn.persistence.toLowerCase()) if (t) try {
            var i = Bs(t, this.mn.cookie_persisted_properties || []), e = Hs(i, this.mn.cookie_persisted_properties || []), r = JSON.stringify(i) + "|" + JSON.stringify(e), s = Fs.ai(this.ba) || void 0;
            s && Vs(this.ba, s) === r && (this.za = r, this.Ua = s);
        } catch (t) {}
        else try {
            var n = Fs.ai(this.ba) || void 0;
            this.za = n ? Vs(this.ba, n) : void 0, this.Ua = n;
        } catch (t) {}
    }
    syncCookieProperties() {
        return this.Wa(this.mn);
    }
    Wa(t, i) {
        if (void 0 === i && (i = !1), this.Ma && !i || this.ha || !t.cookieWinsOnConflict || "localstorage+cookie" !== t.persistence.toLowerCase()) return !1;
        var e;
        try {
            e = Fs.ai(this.ba) || void 0;
        } catch (t) {}
        if (!e || e === this.Ua) return !1;
        var r, s = Vs(this.ba, e);
        try {
            r = Us(JSON.parse(e));
        } catch (t) {
            return !1;
        }
        if ((Fs.ai(this.ba) || void 0) !== e) return !1;
        this.za = s, this.Ua = e;
        var n = qs(this.ba, e), o = [
            ...Ns,
            ...n.properties
        ], a = {};
        if (Object.keys(r).forEach((t)=>{
            var i = r[t];
            (D(i) || j(i) || "" === i || t === Br && i !== es && i !== rs) && (a[t] = !0, delete r[t]);
        }), M(r)) return !1;
        var l = Je in r || r[Br] === es || r[Br] === rs, h = this.props, u = h[Je], d = h[Br], v = cs({}, h);
        [
            ...Ns,
            ...t.cookie_persisted_properties || []
        ].forEach((t)=>{
            if (-1 !== o.indexOf(t) && !(t in r) && !a[t] && (l || t !== Je && t !== Br)) {
                var i = v[t];
                !n.isValid && -1 !== Ns.indexOf(t) && (!1 === i || 0 === i) || delete v[t];
            }
        }), this.props = cs(v, r), Ro.forEach((t)=>{
            var i = t in this.props;
            t in h === i && Oo(h[t], this.props[t]) || (i ? this.ja(t, h[t], this.props[t]) : this.Ta(t, !0));
        }), !l || Br in r || Br in this.props || this.La(Br, es);
        var c = this.props[Je], f = this.props[Br];
        return !l || c === u && f === d || (this.ca = !0, this.ua = !0, Ks.ni(To(this.ba), !0), this.Da(Pr), this.Da(yr), this.Da(br), this.Da(Sr), this.Da(xr), this.Da(Er), this.Da(Ur), this.Da(jr), this.Da(Nr), f === es && (d === rs || r[Br] === es || !D(u) && c !== u) && (Fo(this.props, r), this.Da(Rr)), f === rs ? this.props.$user_id = c : delete this.props.$user_id, this.Da(Qe)), !0;
    }
    consumeCookieIdentityChange() {
        var t = To(this.ba), i = this.ua || !!Ks.ai(t);
        return this.ua = !1, i && Ks.oi(t), i;
    }
    Va(t) {
        return void 0 === t && (t = !1), !(this.ha || this.Ma && !t || !this.mn.cookieWinsOnConflict || "localstorage+cookie" !== this.mn.persistence.toLowerCase() || (this.ha = !0, 0));
    }
    Ga() {
        this.ha && (D(this.Za) || (clearTimeout(this.Za), this.Za = void 0), delete this.sa[Po], this.Qa(!0));
    }
    Ja(t) {
        if (void 0 === t && (t = !0), this.ha) try {
            t ? this.Ga() : D(this.Za) || (clearTimeout(this.Za), this.Za = void 0);
        } finally{
            this.ha = !1;
        }
    }
    isDisabled() {
        return !!this.Ma;
    }
    _a(i) {
        -1 === ko.indexOf(i.persistence.toLowerCase()) && (Ue.critical("Unknown persistence type " + i.persistence + "; falling back to localStorage+cookie"), i.persistence = "localStorage+cookie");
        var e, r = function(i, e) {
            void 0 === i && (i = []), void 0 === e && (e = !1);
            var r = [
                ...Ns,
                ...i
            ];
            return _({}, Ms, {
                ui (t) {
                    try {
                        var i, s = {};
                        try {
                            i = Fs.ai(t) || void 0, s = i ? Us(JSON.parse(i)) : {};
                        } catch (t) {}
                        var n, o = JSON.parse(Ms.ai(t) || "{}");
                        if (e) {
                            var a = qs(t, i), l = [
                                ...Ns,
                                ...a.properties
                            ], h = {};
                            Object.keys(s).forEach((t)=>{
                                var i = s[t];
                                j(i) || "" === i || t === Br && i !== es && i !== rs || (h[t] = i);
                            });
                            var u = Je in h || h[Br] === es || h[Br] === rs;
                            if (Object.keys(h).length > 0) {
                                var d, v = o[Je], c = null !== (d = o[Br]) && void 0 !== d ? d : es;
                                r.forEach((t)=>{
                                    if (-1 !== l.indexOf(t) && !(t in s) && (u || t !== Je && t !== Br)) {
                                        var i = o[t];
                                        !a.isValid && -1 !== Ns.indexOf(t) && (!1 === i || 0 === i) || delete o[t];
                                    }
                                }), !u || Br in s || Br in o || (o[Br] = es), !u || (Je in h ? h[Je] : o[Je]) === v && (Br in h ? h[Br] : o[Br]) === c || (Ds.forEach((t)=>delete o[t]), h[Br] === rs && Je in h ? o.$user_id = h[Je] : delete o.$user_id, h[Br] !== rs && (delete o[Cr], delete o[Rr]), delete o.__alias);
                            }
                            n = cs(o, h);
                        } else n = cs(s, o);
                        return Ms.ni(t, n), n;
                    } catch (t) {}
                    return null;
                },
                ni (t, r, s, n, o, a) {
                    var l = Ms.ni(t, r, void 0, void 0, a);
                    try {
                        var h = Bs(r, i);
                        if (Object.keys(h).length) {
                            if (e) {
                                var u = Ls(t), d = Hs(h, i);
                                if (Fs.ni(u, d, s, n, o, a), Fs.ai(u) !== JSON.stringify(d)) {
                                    Fs.oi(u, n);
                                    var v = Bs(r);
                                    return Fs.ni(t, v, s, n, o, a), l;
                                }
                            }
                            Fs.ni(t, h, s, n, o, a);
                        }
                    } catch (t) {
                        Ms.si(t);
                    }
                    return l;
                },
                oi (i, e) {
                    try {
                        null == t || t.localStorage.removeItem(i), Fs.oi(i, e), Fs.oi(Ls(i), e);
                    } catch (t) {
                        Ms.si(t);
                    }
                }
            });
        }(i.cookie_persisted_properties || [], i.cookieWinsOnConflict), s = !1, n = !1, o = i.persistence.toLowerCase();
        return "localstorage" === o && Ms.ii() ? (e = Ms, n = !0) : "localstorage+cookie" === o && r.ii() ? (e = r, n = !0, s = !0) : "sessionstorage" === o && Ks.ii() ? e = Ks : "memory" === o ? e = Gs : "cookie" === o && Fs.ii() ? (e = Fs, s = !0) : r.ii() ? (e = r, n = !0, s = !0) : Fs.ii() ? (e = Fs, s = !0) : e = Gs, this.aa = n, this.oa = s, e;
    }
    xa(t) {
        return this.ba + "__" + t;
    }
    wa(t) {
        return this.aa && !!t.split_storage;
    }
    properties() {
        var t = {};
        return vs(this.props, (i, e)=>{
            var r = to(e);
            if (!r || "event" === r.exposure) {
                if (null != r && null != r.shouldSkipFromEventProperties && r.shouldSkipFromEventProperties(i)) return;
                t[e] = i;
            }
        }), t;
    }
    load(t) {
        if (void 0 === t && (t = !1), !this.Ma || t) {
            var i = this.mn.cookieWinsOnConflict && "localstorage+cookie" === this.mn.persistence.toLowerCase(), e = i ? Ms.ui(this.ba) : null, r = {};
            if (i) try {
                vs(r = Us(Fs.ui(this.ba)), (t, i)=>{
                    (D(t) || j(t) || "" === t) && delete r[i];
                });
            } catch (t) {}
            var s = this.Zs.ui(this.ba);
            if (s && (this.props = cs({}, s)), this.la && this.Ka(), i && s) {
                var n, o, a = null == e ? void 0 : e[Je], l = null !== (n = null == e ? void 0 : e[Br]) && void 0 !== n ? n : es, h = s[Je], u = null !== (o = s[Br]) && void 0 !== o ? o : es;
                if (h !== a || u !== l) {
                    this.ua = !0, Ks.ni(To(this.ba), !0);
                    var d = cs({}, this.props);
                    Ds.forEach((t)=>delete d[t]), u === es && (l === rs || r[Br] === es || !D(a) && h !== a) && (Fo(d, r), delete d[Rr]), this.props = d;
                    var v = new Set;
                    Ds.forEach((t)=>{
                        var i, e = null == (i = to(t)) ? void 0 : i.storageGroup;
                        e && v.add(e);
                    }), v.forEach((t)=>{
                        var i = {};
                        vs(this.props, (e, r)=>{
                            var s;
                            (null == (s = to(r)) ? void 0 : s.storageGroup) === t && (i[r] = e);
                        }), M(i) ? (Ms.oi(this.xa(t)), this.sa[t] = {}) : Ms.ni(this.xa(t), i) && (this.sa[t] = {
                            persisted: !0,
                            fingerprint: this.Fa(i, t)
                        });
                    });
                }
            }
            Ks.ai(To(this.ba)) && (this.ua = !0);
        }
    }
    Ka() {
        for (var t of Qn){
            var i = Ms.ui(this.xa(t));
            if (i && !M(i)) {
                var e = this.Ia(t);
                e.persisted = !0, this.Ya(t) || (e.fingerprint = this.Fa(i, t)), this.Xa(t, i) || cs(this.props, i);
            }
        }
    }
    Ya(t) {
        return Object.keys(this.props).some((i)=>{
            var e;
            return (null == (e = to(i)) ? void 0 : e.storageGroup) === t;
        });
    }
    Xa(t, i) {
        var e = Eo[t];
        if (!e) return !1;
        var r = i[e], s = this.props[e];
        return B(r) && B(s) && s > r;
    }
    refreshKey(t) {
        var i;
        if (!(this.Ma || t === Ze && this.pa)) {
            var e = this.la ? null == (i = to(t)) ? void 0 : i.storageGroup : void 0, r = e ? Ms.ui(this.xa(e)) : this.Zs.ui(this.ba);
            if (r && t in r) this.La(t, r[t], !1);
            else {
                if (e) {
                    var s = this.Zs.ui(this.ba);
                    if (s && t in s) return void this.La(t, s[t], !1);
                }
                this.Da(t, !1);
            }
        }
    }
    save() {
        if (!this.Ma) {
            var t = this.Ba();
            t > 0 ? D(this.Za) && (this.Za = setTimeout(()=>{
                this.Za = void 0, this.Qa();
            }, t)) : this.Qa();
        }
    }
    flush() {
        D(this.Za) || (clearTimeout(this.Za), this.Za = void 0, this.Qa());
    }
    Qa(t) {
        if (void 0 === t && (t = !1), !(this.Ma || this.ha && !t)) {
            t || (this.syncCookieProperties(), this.pa || this.mn.cookieWinsOnConflict && "localstorage+cookie" === this.mn.persistence.toLowerCase() || this.refreshKey(Ze));
            var i = !t && !this.va;
            i || (this.fa = !1);
            var e = !!i && this.$a();
            if (this.fa) this.mn.debug && Ue.warn("skipping persistence write because storage belongs to a different distinct ID");
            else {
                if (this.la) return this.eo(), void (e && this.ga.forEach((t)=>t()));
                var r = this.io(this.Zs, this.ba, this.props, Po);
                "written" === r && this.Ha(this.props), "failed" !== r && (this.da.clear(), this.ca = !1, this.pa = !1), e && this.ga.forEach((t)=>t());
            }
        }
    }
    eo() {
        var t = this, i = this.Pa(), e = i.main, r = i.groups, s = this.io(this.Zs, this.ba, e, Po);
        "written" === s && this.Ha(e), "failed" !== s && (this.ca = !1, this.pa = !1, Ro.forEach((t)=>{
            var i;
            null != (i = to(t)) && i.storageGroup || this.da.delete(t);
        }));
        var n = function(i) {
            var e, s = r[i];
            if (M(s) && (null == (e = t.sa[i]) || !e.persisted)) return Ro.forEach((e)=>{
                var r;
                (null == (r = to(e)) ? void 0 : r.storageGroup) === i && t.da.delete(e);
            }), 1;
            var n = t.io(Ms, t.xa(i), s, i);
            "failed" !== n && Ro.forEach((e)=>{
                var r = to(e);
                (null == r ? void 0 : r.storageGroup) !== i || "written" !== n && r.volatile || t.da.delete(e);
            });
        };
        for (var o of Qn)n(o);
    }
    Pa() {
        var t = {}, i = {
            flags: {},
            surveys: {}
        };
        return vs(this.props, (e, r)=>{
            var s, n = null == (s = to(r)) ? void 0 : s.storageGroup;
            n ? i[n][r] = e : t[r] = e;
        }), {
            main: t,
            groups: i
        };
    }
    Fa(t, i) {
        if (i === Po) return JSON.stringify(t) + "|" + this.ro + "|" + this.no + "|" + this.so;
        var e = {};
        return vs(t, (t, i)=>{
            var r;
            e[i] = null != (r = to(i)) && r.volatile ? "__volatile__" : t;
        }), JSON.stringify(e);
    }
    io(t, i, e, r) {
        var s, n = this.Ia(r);
        if (r !== Po && !n.dirty && !D(n.fingerprint)) return "skipped";
        try {
            if ((s = this.Fa(e, r)) === n.fingerprint) return n.dirty = !1, "skipped";
        } catch (t) {
            s = void 0;
        }
        return t.ni(i, e, this.ro, this.no, this.so, this.mn.debug) ? (n.dirty = !1, r !== Po && (n.persisted = !0), D(s) || (n.fingerprint = s), this.aa && (n.storageValue = Ms.ai(i)), "written") : (this.mn.debug && Ue.warn('failed to persist storage entry "' + i + '"; will retry on next save'), "failed");
    }
    remove(t) {
        var i = (void 0 === t ? {} : t).keepGroupEntries, e = void 0 !== i && i;
        if (this.qa(), D(this.Za) || (clearTimeout(this.Za), this.Za = void 0), this.Zs.oi(this.ba, !1), this.Zs.oi(this.ba, !0), !e && this.ma) for (var r of Qn)Ms.oi(this.xa(r));
        e ? delete this.sa[Po] : this.sa = {}, this.za = void 0, this.Ua = void 0;
    }
    clear() {
        this.remove(), this.props = {};
    }
    register_once(t, i, e) {
        if (A(t)) {
            this.syncCookieProperties(), D(i) && (i = "None"), this.ro = D(e) ? this.ao : e;
            var r = !1;
            if (vs(t, (t, e)=>{
                this.props.hasOwnProperty(e) && this.props[e] !== i || (this.La(e, t), r = !0);
            }), r) return this.save(), !0;
        }
        return !1;
    }
    register(t, i) {
        if (A(t)) {
            this.syncCookieProperties(), this.ro = D(i) ? this.ao : i;
            var e = !1;
            if (vs(t, (i, r)=>{
                t.hasOwnProperty(r) && (this.props[r] !== i || A(i) || I(i)) && (this.La(r, i), e = !0);
            }), e) return this.save(), !0;
        }
        return !1;
    }
    unregister(t) {
        this.syncCookieProperties();
        var i = "string" == typeof t ? [
            t
        ] : t, e = !1;
        for (var r of i)r in this.props && (this.Da(r), e = !0);
        e && this.save();
    }
    update_campaign_params() {
        var t = null == r ? void 0 : r.URL;
        if (t !== this.ya) {
            var i = fo(this.mn.custom_campaign_params, this.mn.mask_personal_data_properties, this.mn.custom_personal_data_properties), e = !M(gs(i));
            return e && this.register(i), this.ya = t, e ? i : void 0;
        }
    }
    update_search_keyword() {
        var t;
        this.register((t = null == r ? void 0 : r.referrer) ? _o(t) : {});
    }
    update_referrer_info() {
        var t;
        this.register_once({
            $referrer: bo(),
            $referring_domain: null != r && r.referrer && (null == (t = eo(r.referrer)) ? void 0 : t.host) || mo
        }, void 0);
    }
    set_initial_person_info() {
        if (!this.props[qr] && !this.props[Vr]) {
            var t = yo(this.mn.mask_personal_data_properties, this.mn.custom_personal_data_properties, this.mn.disable_capture_url_hashes);
            this.register_once({
                [Wr]: this.oa ? {
                    r: $o(t.r),
                    u: t.u ? $o(t.u) : void 0
                } : t
            }, void 0);
        }
    }
    get_initial_props() {
        var t = {};
        vs([
            Vr,
            qr
        ], (i)=>{
            var e = this.props[i];
            e && vs(e, function(i, e) {
                t["$initial_" + S(e)] = i;
            });
        });
        var i = this.props[Wr];
        if (i) {
            var e = function(t, i) {
                void 0 === i && (i = !1);
                var e = wo(t, i), r = {};
                return vs(e, function(t, i) {
                    r["$initial_" + S(i)] = t;
                }), r;
            }(i, this.mn.disable_capture_url_hashes);
            cs(t, e);
        }
        return t;
    }
    safe_merge(t) {
        return vs(this.props, function(i, e) {
            e in t || (t[e] = i);
        }), t;
    }
    update_config(t, i, e) {
        var r = t.persistence !== i.persistence, s = !((t, i)=>{
            if (t.length !== i.length) return !1;
            var e = [
                ...t
            ].sort(), r = [
                ...i
            ].sort();
            return e.every((t, i)=>t === r[i]);
        })(t.cookie_persisted_properties || [], i.cookie_persisted_properties || []), n = r || s, o = t.cookieWinsOnConflict !== i.cookieWinsOnConflict, a = t.disable_persistence || !!e, l = !!this.Ma && !a;
        a || this.Wa(i, l), this.mn = t, !a && (r || s || o) && (this.za = void 0, this.Ua = void 0, this.Wa(_({}, t, {
            cookie_persisted_properties: i.cookie_persisted_properties
        }), l));
        var h = n || o ? this._a(t) : this.Zs;
        this.oo();
        var u = this.wa(t), d = n || u !== this.la, v = !a && (d || t.cross_subdomain_cookie !== this.no || t.secure_cookie !== this.so) && this.Va(l);
        this.va = d;
        try {
            if (this.ao = this.ro = t.cookie_expiration, this.set_disabled(a), this.set_cross_subdomain(t.cross_subdomain_cookie), this.set_secure(t.secure_cookie), d) {
                var c = this.props;
                this.clear(), this.Zs = h, this.la = u, this.props = c, this.save();
            } else o && (this.Zs = h, a || (delete this.sa[Po], this.Qa()));
        } finally{
            this.va = !1, v && this.Ja();
        }
    }
    oo() {
        var t = this.props[Wr];
        if (this.oa && A(t) && "string" == typeof t.r) {
            var i = $o(t.r), e = "string" == typeof t.u ? $o(t.u) : t.u;
            i === t.r && e === t.u || this.La(Wr, _({}, t, {
                r: i,
                u: e
            }));
        }
    }
    set_disabled(t) {
        this.Ma = t, this.Ma ? this.remove() : this.save();
    }
    set_cross_subdomain(t) {
        t !== this.no && (this.no = t, this.remove({
            keepGroupEntries: !0
        }), this.save());
    }
    set_secure(t) {
        t !== this.so && (this.so = t, this.remove({
            keepGroupEntries: !0
        }), this.save());
    }
    set_event_timer(t, i) {
        var e = this.props[tr] || {};
        e[t] = i, this.La(tr, e), this.save();
    }
    remove_event_timer(t) {
        var i = this.props[tr] || {}, e = i[t];
        return D(e) || (delete i[t], this.La(tr, i), this.save()), e;
    }
    get_property(t) {
        return this.props[t];
    }
    set_property(t, i) {
        this.La(t, i), this.save();
    }
    La(t, i, e) {
        var r;
        void 0 === e && (e = !0);
        var s = this.props[t];
        this.props[t] = i, e && (t !== Je && t !== Br || s === i || (this.ca = !0), t !== Ze || Oo(s, i) || (this.pa = !0), this.ja(t, s, i), null != (r = to(t)) && r.volatile || this.Na(t));
    }
    Da(t, i) {
        void 0 === i && (i = !0), delete this.props[t], i && (Co(t) && this.Ta(t, !0), t === Ze && (this.pa = !0), this.Na(t));
    }
    Na(t) {
        var i, e = null == (i = to(t)) ? void 0 : i.storageGroup;
        e && (this.Ia(e).dirty = !0);
    }
    Ia(t) {
        return this.sa[t] || (this.sa[t] = {});
    }
}
var Mo = {
    GZipJS: "gzip-js",
    Base64: "base64"
}, Do = {
    Activation: "events",
    Cancellation: "cancelEvents"
}, No = {
    Button: "button",
    Tab: "tab",
    Selector: "selector"
}, Lo = {
    TopLeft: "top_left",
    TopRight: "top_right",
    TopCenter: "top_center",
    MiddleLeft: "middle_left",
    MiddleRight: "middle_right",
    MiddleCenter: "middle_center",
    Left: "left",
    Center: "center",
    Right: "right",
    NextToTrigger: "next_to_trigger"
}, jo = {
    Top: "top",
    Left: "left",
    Right: "right",
    Bottom: "bottom"
}, Uo = {
    Popover: "popover",
    API: "api",
    Widget: "widget",
    ExternalSurvey: "external_survey"
}, Bo = {
    Open: "open",
    MultipleChoice: "multiple_choice",
    SingleChoice: "single_choice",
    Rating: "rating",
    Link: "link"
}, zo = {
    NextQuestion: "next_question",
    End: "end",
    ResponseBased: "response_based",
    SpecificQuestion: "specific_question"
}, Ho = {
    Once: "once",
    Recurring: "recurring",
    Always: "always"
}, qo = {
    SHOWN: "survey shown",
    DISMISSED: "survey dismissed",
    SENT: "survey sent",
    ABANDONED: "survey abandoned"
}, Vo = {
    SURVEY_ID: "$survey_id",
    SURVEY_NAME: "$survey_name",
    SURVEY_RESPONSE: "$survey_response",
    SURVEY_ITERATION: "$survey_iteration",
    SURVEY_ITERATION_START_DATE: "$survey_iteration_start_date",
    SURVEY_PARTIALLY_COMPLETED: "$survey_partially_completed",
    SURVEY_SUBMISSION_ID: "$survey_submission_id",
    SURVEY_QUESTIONS: "$survey_questions",
    SURVEY_COMPLETED: "$survey_completed",
    PRODUCT_TOUR_ID: "$product_tour_id",
    SURVEY_LAST_SEEN_DATE: "$survey_last_seen_date",
    SURVEY_LANGUAGE: "$survey_language"
}, Wo = {
    Popover: "popover",
    Inline: "inline"
};
function Go(t) {
    var i = !0;
    return {
        dispose () {
            if (i) {
                i = !1;
                var e = t();
                e && F(e.then) && e.then(void 0, ()=>{});
            }
        }
    };
}
var Jo = {
    backgroundColor: "#ffffff",
    textColor: "#1d1f27",
    buttonColor: "#1d1f27",
    borderRadius: 8,
    buttonBorderRadius: 6,
    borderColor: "#e5e7eb",
    fontFamily: "system-ui",
    boxShadow: "0 4px 12px rgba(0, 0, 0, 0.15)",
    showOverlay: !0,
    whiteLabel: !1,
    dismissOnClickOutside: !0,
    zIndex: 2147483646
}, Ko = {
    SHOWN: "product tour shown",
    DISMISSED: "product tour dismissed",
    COMPLETED: "product tour completed",
    STEP_SHOWN: "product tour step shown",
    STEP_COMPLETED: "product tour step completed",
    BUTTON_CLICKED: "product tour button clicked",
    STEP_SELECTOR_FAILED: "product tour step selector failed",
    BANNER_CONTAINER_SELECTOR_FAILED: "product tour banner container selector failed",
    BANNER_ACTION_CLICKED: "product tour banner action clicked"
}, Yo = {
    TOUR_ID: "$product_tour_id",
    TOUR_NAME: "$product_tour_name",
    TOUR_ITERATION: "$product_tour_iteration",
    TOUR_RENDER_REASON: "$product_tour_render_reason",
    TOUR_STEP_ID: "$product_tour_step_id",
    TOUR_STEP_ORDER: "$product_tour_step_order",
    TOUR_STEP_TYPE: "$product_tour_step_type",
    TOUR_DISMISS_REASON: "$product_tour_dismiss_reason",
    TOUR_BUTTON_TEXT: "$product_tour_button_text",
    TOUR_BUTTON_ACTION: "$product_tour_button_action",
    TOUR_BUTTON_LINK: "$product_tour_button_link",
    TOUR_BUTTON_TOUR_ID: "$product_tour_button_tour_id",
    TOUR_STEPS_COUNT: "$product_tour_steps_count",
    TOUR_STEP_SELECTOR: "$product_tour_step_selector",
    TOUR_STEP_SELECTOR_FOUND: "$product_tour_step_selector_found",
    TOUR_STEP_ELEMENT_TAG: "$product_tour_step_element_tag",
    TOUR_STEP_ELEMENT_ID: "$product_tour_step_element_id",
    TOUR_STEP_ELEMENT_CLASSES: "$product_tour_step_element_classes",
    TOUR_STEP_ELEMENT_TEXT: "$product_tour_step_element_text",
    TOUR_ERROR: "$product_tour_error",
    TOUR_MATCHES_COUNT: "$product_tour_matches_count",
    TOUR_FAILURE_PHASE: "$product_tour_failure_phase",
    TOUR_WAITED_FOR_ELEMENT: "$product_tour_waited_for_element",
    TOUR_WAIT_DURATION_MS: "$product_tour_wait_duration_ms",
    TOUR_BANNER_SELECTOR: "$product_tour_banner_selector",
    TOUR_LINKED_SURVEY_ID: "$product_tour_linked_survey_id",
    USE_MANUAL_SELECTOR: "$use_manual_selector",
    INFERENCE_DATA_PRESENT: "$inference_data_present",
    TOUR_LAST_SEEN_DATE: "$product_tour_last_seen_date",
    TOUR_TYPE: "$product_tour_type"
}, Qo = Be("[RateLimiter]");
class Xo {
    constructor(t){
        this.serverLimits = {}, this.lastEventRateLimited = !1, this.checkForLimiting = (t)=>{
            var i = t.text;
            if (i && i.length) try {
                (JSON.parse(i).quota_limited || []).forEach((t)=>{
                    Qo.info((t || "events") + " is quota limited."), this.serverLimits[t] = (new Date).getTime() + 6e4;
                });
            } catch (t) {
                return void Qo.warn('could not rate limit - continuing. Error: "' + (null == t ? void 0 : t.message) + '"', {
                    text: i
                });
            }
        }, this.instance = t, this.lastEventRateLimited = this.clientRateLimitContext(!0).isRateLimited;
    }
    get captureEventsPerSecond() {
        var t;
        return (null == (t = this.instance.config.rate_limiting) ? void 0 : t.events_per_second) || 10;
    }
    get captureEventsBurstLimit() {
        var t;
        return Math.max((null == (t = this.instance.config.rate_limiting) ? void 0 : t.events_burst_limit) || 10 * this.captureEventsPerSecond, this.captureEventsPerSecond);
    }
    clientRateLimitContext(t) {
        var i, e, r;
        void 0 === t && (t = !1);
        var s = this.captureEventsBurstLimit, n = this.captureEventsPerSecond, o = (new Date).getTime(), a = null !== (i = null == (e = this.instance.persistence) ? void 0 : e.get_property(Hr)) && void 0 !== i ? i : {
            tokens: s,
            last: o
        };
        a.tokens += (o - a.last) / 1e3 * n, a.last = o, a.tokens > s && (a.tokens = s);
        var l = 1 > a.tokens;
        if (l || t || (a.tokens = Math.max(0, a.tokens - 1)), l && !t) {
            var h = (B(a.dropped) ? a.dropped : 0) + 1;
            a.dropped = h, !this.lastEventRateLimited && this.lo(h) && (a.dropped = 0);
        }
        return this.lastEventRateLimited = l, null == (r = this.instance.persistence) || r.set_property(Hr, a), {
            isRateLimited: l,
            remainingTokens: a.tokens
        };
    }
    uo(t) {
        var i = this.instance.config.property_denylist;
        return !I(i) || !i.includes(t);
    }
    ho() {
        var t;
        if (this.uo("$current_url") && this.uo("$pathname") && null != s && s.pathname) return "" + (null !== (t = s.origin) && void 0 !== t ? t : "") + s.pathname;
    }
    lo(t) {
        var i, e, r = this.captureEventsBurstLimit, s = this.captureEventsPerSecond, n = this.ho(), o = this.uo("$session_id") ? null == (i = (e = this.instance).get_session_id) ? void 0 : i.call(e) : void 0, a = [
            t + " event(s) dropped since the last warning",
            n ? "triggered on " + n : void 0,
            o ? "session " + o : void 0
        ].filter(Boolean).join(", ");
        return !!this.instance.capture("$$client_ingestion_warning", {
            $$client_ingestion_warning_message: "posthog-js client rate limited: " + a + ". Config is set to " + s + " events per second and " + r + " events burst limit."
        }, {
            skip_client_rate_limiting: !0
        });
    }
    isServerRateLimited(t) {
        var i = this.serverLimits[t || "events"] || !1;
        return !1 !== i && (new Date).getTime() < i;
    }
}
var Zo = Be("[RemoteConfig]");
class ta {
    constructor(t){
        this._instance = t;
    }
    get remoteConfig() {
        var t;
        return null == (t = v._POSTHOG_REMOTE_CONFIG) || null == (t = t[this._instance.config.token]) ? void 0 : t.config;
    }
    do(t) {
        var i, e;
        null != (i = v.__PosthogExtensions__) && i.loadExternalDependency ? null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this._instance, "remote-config", ()=>t(this.remoteConfig)) : t();
    }
    vo(t) {
        this._instance._send_request({
            method: "GET",
            url: this._instance.requestRouter.endpointFor("assets", "/array/" + this._instance.config.token + "/config"),
            callback: t
        });
    }
    load() {
        try {
            if (this.remoteConfig) return Zo.info("Using preloaded remote config", this.remoteConfig), void this.co(this.remoteConfig);
            if (this._instance.fo()) return void Zo.warn("Remote config is disabled. Falling back to local config.");
            this.do((t)=>{
                if (!t) return Zo.info("No config found after loading remote JS config. Falling back to JSON."), void this.vo((t)=>{
                    this.co(t.json, t);
                });
                this.co(t);
            });
        } catch (t) {
            Zo.error("Error loading remote config", t), this.co();
        }
    }
    co(t, i) {
        !t && i && (0 === i.statusCode ? i.error || Zo.warn("Failed to fetch remote config from PostHog.") : Zo.error("Failed to fetch remote config from PostHog."));
        try {
            this._instance.co(t ? {
                ok: !0,
                config: t
            } : {
                ok: !1
            });
        } catch (t) {
            Zo.error("Error applying remote config", t);
        }
        if (!1 !== (null == t ? void 0 : t.hasFeatureFlags) && !this._instance.config.advanced_disable_feature_flags_on_first_load) try {
            var e;
            null == (e = this._instance.featureFlags) || e.ensureFlagsLoaded();
        } catch (t) {
            Zo.error("Error loading feature flags", t);
        }
    }
}
var ia = [
    "fatal",
    "error",
    "warning",
    "log",
    "info",
    "debug"
], ea = Uint8Array, ra = Uint16Array, sa = Uint32Array, na = new ea([
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    2,
    2,
    2,
    2,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    5,
    5,
    5,
    5,
    0,
    0,
    0,
    0
]), oa = new ea([
    0,
    0,
    0,
    0,
    1,
    1,
    2,
    2,
    3,
    3,
    4,
    4,
    5,
    5,
    6,
    6,
    7,
    7,
    8,
    8,
    9,
    9,
    10,
    10,
    11,
    11,
    12,
    12,
    13,
    13,
    0,
    0
]), aa = new ea([
    16,
    17,
    18,
    0,
    8,
    7,
    9,
    6,
    10,
    5,
    11,
    4,
    12,
    3,
    13,
    2,
    14,
    1,
    15
]), la = function(t, i) {
    for(var e = new ra(31), r = 0; 31 > r; ++r)e[r] = i += 1 << t[r - 1];
    var s = new sa(e[30]);
    for(r = 1; 30 > r; ++r)for(var n = e[r]; e[r + 1] > n; ++n)s[n] = n - e[r] << 5 | r;
    return [
        e,
        s
    ];
}, ha = la(na, 2), ua = ha[1];
ha[0][28] = 258, ua[258] = 28;
for(var da = la(oa, 0)[1], va = new ra(32768), ca = 0; 32768 > ca; ++ca){
    var fa = (43690 & ca) >>> 1 | (21845 & ca) << 1;
    va[ca] = ((65280 & (fa = (61680 & (fa = (52428 & fa) >>> 2 | (13107 & fa) << 2)) >>> 4 | (3855 & fa) << 4)) >>> 8 | (255 & fa) << 8) >>> 1;
}
var pa = function(t, i, e) {
    for(var r = t.length, s = 0, n = new ra(i); r > s; ++s)++n[t[s] - 1];
    var o, a = new ra(i);
    for(s = 0; i > s; ++s)a[s] = a[s - 1] + n[s - 1] << 1;
    if (e) {
        o = new ra(1 << i);
        var l = 15 - i;
        for(s = 0; r > s; ++s)if (t[s]) for(var h = s << 4 | t[s], u = i - t[s], d = a[t[s] - 1]++ << u, v = d | (1 << u) - 1; v >= d; ++d)o[va[d] >>> l] = h;
    } else for(o = new ra(r), s = 0; r > s; ++s)o[s] = va[a[t[s] - 1]++] >>> 15 - t[s];
    return o;
}, _a = new ea(288);
for(ca = 0; 144 > ca; ++ca)_a[ca] = 8;
for(ca = 144; 256 > ca; ++ca)_a[ca] = 9;
for(ca = 256; 280 > ca; ++ca)_a[ca] = 7;
for(ca = 280; 288 > ca; ++ca)_a[ca] = 8;
var ga = new ea(32);
for(ca = 0; 32 > ca; ++ca)ga[ca] = 5;
var ma = pa(_a, 9, 0), ba = pa(ga, 5, 0), ya = function(t) {
    return (t / 8 >> 0) + (7 & t && 1);
}, wa = function(t, i, e) {
    (null == e || e > t.length) && (e = t.length);
    var r = new (t instanceof ra ? ra : t instanceof sa ? sa : ea)(e - i);
    return r.set(t.subarray(i, e)), r;
}, Sa = function(t, i, e) {
    var r = i / 8 >> 0;
    t[r] |= e <<= 7 & i, t[r + 1] |= e >>> 8;
}, xa = function(t, i, e) {
    var r = i / 8 >> 0;
    t[r] |= e <<= 7 & i, t[r + 1] |= e >>> 8, t[r + 2] |= e >>> 16;
}, Ea = function(t, i) {
    for(var e = [], r = 0; t.length > r; ++r)t[r] && e.push({
        s: r,
        f: t[r]
    });
    var s = e.length, n = e.slice();
    if (!s) return [
        new ea(0),
        0
    ];
    if (1 == s) {
        var o = new ea(e[0].s + 1);
        return o[e[0].s] = 1, [
            o,
            1
        ];
    }
    e.sort(function(t, i) {
        return t.f - i.f;
    }), e.push({
        s: -1,
        f: 25001
    });
    var a = e[0], l = e[1], h = 0, u = 1, d = 2;
    for(e[0] = {
        s: -1,
        f: a.f + l.f,
        l: a,
        r: l
    }; u != s - 1;)a = e[e[d].f > e[h].f ? h++ : d++], l = e[h != u && e[d].f > e[h].f ? h++ : d++], e[u++] = {
        s: -1,
        f: a.f + l.f,
        l: a,
        r: l
    };
    var v = n[0].s;
    for(r = 1; s > r; ++r)n[r].s > v && (v = n[r].s);
    var c = new ra(v + 1), f = ka(e[u - 1], c, 0);
    if (f > i) {
        r = 0;
        var p = 0, _ = f - i, g = 1 << _;
        for(n.sort(function(t, i) {
            return c[i.s] - c[t.s] || t.f - i.f;
        }); s > r; ++r){
            var m = n[r].s;
            if (i >= c[m]) break;
            p += g - (1 << f - c[m]), c[m] = i;
        }
        for(p >>>= _; p > 0;){
            var b = n[r].s;
            i > c[b] ? p -= 1 << i - c[b]++ - 1 : ++r;
        }
        for(; r >= 0 && p; --r){
            var y = n[r].s;
            c[y] == i && (--c[y], ++p);
        }
        f = i;
    }
    return [
        new ea(c),
        f
    ];
}, ka = function(t, i, e) {
    return -1 == t.s ? Math.max(ka(t.l, i, e + 1), ka(t.r, i, e + 1)) : i[t.s] = e;
}, Ta = function(t) {
    for(var i = t.length; i && !t[--i];);
    for(var e = new ra(++i), r = 0, s = t[0], n = 1, o = function(t) {
        e[r++] = t;
    }, a = 1; i >= a; ++a)if (t[a] == s && a != i) ++n;
    else {
        if (!s && n > 2) {
            for(; n > 138; n -= 138)o(32754);
            n > 2 && (o(n > 10 ? n - 11 << 5 | 28690 : n - 3 << 5 | 12305), n = 0);
        } else if (n > 3) {
            for(o(s), --n; n > 6; n -= 6)o(8304);
            n > 2 && (o(n - 3 << 5 | 8208), n = 0);
        }
        for(; n--;)o(s);
        n = 1, s = t[a];
    }
    return [
        e.subarray(0, r),
        i
    ];
}, $a = function(t, i) {
    for(var e = 0, r = 0; i.length > r; ++r)e += t[r] * i[r];
    return e;
}, Pa = function(t, i, e) {
    var r = e.length, s = ya(i + 2);
    t[s] = 255 & r, t[s + 1] = r >>> 8, t[s + 2] = 255 ^ t[s], t[s + 3] = 255 ^ t[s + 1];
    for(var n = 0; r > n; ++n)t[s + n + 4] = e[n];
    return 8 * (s + 4 + r);
}, Ra = function(t, i, e, r, s, n, o, a, l, h, u) {
    Sa(i, u++, e), ++s[256];
    for(var d = Ea(s, 15), v = d[0], c = d[1], f = Ea(n, 15), p = f[0], _ = f[1], g = Ta(v), m = g[0], b = g[1], y = Ta(p), w = y[0], S = y[1], x = new ra(19), E = 0; m.length > E; ++E)x[31 & m[E]]++;
    for(E = 0; w.length > E; ++E)x[31 & w[E]]++;
    for(var k = Ea(x, 7), T = k[0], P = k[1], R = 19; R > 4 && !T[aa[R - 1]]; --R);
    var C, O, I, F, A = h + 5 << 3, M = $a(s, _a) + $a(n, ga) + o, D = $a(s, v) + $a(n, p) + o + 14 + 3 * R + $a(x, T) + (2 * x[16] + 3 * x[17] + 7 * x[18]);
    if (M >= A && D >= A) return Pa(i, u, t.subarray(l, l + h));
    if (Sa(i, u, 1 + (M > D)), u += 2, M > D) {
        C = pa(v, c, 0), O = v, I = pa(p, _, 0), F = p;
        var N = pa(T, P, 0);
        for(Sa(i, u, b - 257), Sa(i, u + 5, S - 1), Sa(i, u + 10, R - 4), u += 14, E = 0; R > E; ++E)Sa(i, u + 3 * E, T[aa[E]]);
        u += 3 * R;
        for(var L = [
            m,
            w
        ], j = 0; 2 > j; ++j){
            var U = L[j];
            for(E = 0; U.length > E; ++E)Sa(i, u, N[B = 31 & U[E]]), u += T[B], B > 15 && (Sa(i, u, U[E] >>> 5 & 127), u += U[E] >>> 12);
        }
    } else C = ma, O = _a, I = ba, F = ga;
    for(E = 0; a > E; ++E)if (r[E] > 255) {
        var B;
        xa(i, u, C[257 + (B = r[E] >>> 18 & 31)]), u += O[B + 257], B > 7 && (Sa(i, u, r[E] >>> 23 & 31), u += na[B]);
        var z = 31 & r[E];
        xa(i, u, I[z]), u += F[z], z > 3 && (xa(i, u, r[E] >>> 5 & 8191), u += oa[z]);
    } else xa(i, u, C[r[E]]), u += O[r[E]];
    return xa(i, u, C[256]), u + O[256];
}, Ca = new sa([
    65540,
    131080,
    131088,
    131104,
    262176,
    1048704,
    1048832,
    2114560,
    2117632
]), Oa = function() {
    for(var t = new sa(256), i = 0; 256 > i; ++i){
        for(var e = i, r = 9; --r;)e = (1 & e && 3988292384) ^ e >>> 1;
        t[i] = e;
    }
    return t;
}(), Ia = function(t, i, e) {
    for(; e; ++i)t[i] = e, e >>>= 8;
};
function Fa(t, i) {
    void 0 === i && (i = {});
    var e = function() {
        var t = 4294967295;
        return {
            p (i) {
                for(var e = t, r = 0; i.length > r; ++r)e = Oa[255 & e ^ i[r]] ^ e >>> 8;
                t = e;
            },
            d () {
                return 4294967295 ^ t;
            }
        };
    }(), r = t.length;
    e.p(t);
    var s, n, o, a, l, h = (a = 10 + ((s = i).filename && s.filename.length + 1 || 0), l = 8, function(t, i, e, r, s, n) {
        var o = t.length, a = new ea(r + o + 5 * (1 + Math.floor(o / 7e3)) + s), l = a.subarray(r, a.length - s), h = 0;
        if (!i || 8 > o) for(var u = 0; o >= u; u += 65535){
            var d = u + 65535;
            o > d ? h = Pa(l, h, t.subarray(u, d)) : (l[u] = !0, h = Pa(l, h, t.subarray(u, o)));
        }
        else {
            for(var v = Ca[i - 1], c = v >>> 13, f = 8191 & v, p = (1 << e) - 1, _ = new ra(32768), g = new ra(p + 1), m = Math.ceil(e / 3), b = 2 * m, y = function(i) {
                return (t[i] ^ t[i + 1] << m ^ t[i + 2] << b) & p;
            }, w = new sa(25e3), S = new ra(288), x = new ra(32), E = 0, k = 0, T = (u = 0, 0), P = 0, R = 0; o > u; ++u){
                var C = y(u), O = 32767 & u, I = g[C];
                if (_[O] = I, g[C] = O, u >= P) {
                    var F = o - u;
                    if ((E > 7e3 || T > 24576) && F > 423) {
                        h = Ra(t, l, 0, w, S, x, k, T, R, u - R, h), T = E = k = 0, R = u;
                        for(var A = 0; 286 > A; ++A)S[A] = 0;
                        for(A = 0; 30 > A; ++A)x[A] = 0;
                    }
                    var M = 2, D = 0, N = f, L = O - I & 32767;
                    if (F > 2 && C == y(u - L)) for(var j = Math.min(c, F) - 1, U = Math.min(32767, u), B = Math.min(258, F); U >= L && --N && O != I;){
                        if (t[u + M] == t[u + M - L]) {
                            for(var z = 0; B > z && t[u + z] == t[u + z - L]; ++z);
                            if (z > M) {
                                if (M = z, D = L, z > j) break;
                                var H = Math.min(L, z - 2), q = 0;
                                for(A = 0; H > A; ++A){
                                    var V = u - L + A + 32768 & 32767, W = V - _[V] + 32768 & 32767;
                                    W > q && (q = W, I = V);
                                }
                            }
                        }
                        L += (O = I) - (I = _[O]) + 32768 & 32767;
                    }
                    if (D) {
                        w[T++] = 268435456 | ua[M] << 18 | da[D];
                        var G = 31 & ua[M], J = 31 & da[D];
                        k += na[G] + oa[J], ++S[257 + G], ++x[J], P = u + M, ++E;
                    } else w[T++] = t[u], ++S[t[u]];
                }
            }
            h = Ra(t, l, !0, w, S, x, k, T, R, u - R, h);
        }
        return wa(a, 0, r + ya(h) + s);
    }(n = t, null == (o = i).level ? 6 : o.level, null == o.mem ? Math.ceil(1.5 * Math.max(8, Math.min(13, Math.log(n.length)))) : 12 + o.mem, a, l)), u = h.length;
    return function(t, i) {
        var e = i.filename;
        if (t[0] = 31, t[1] = 139, t[2] = 8, t[8] = 2 > i.level ? 4 : 9 == i.level ? 2 : 0, t[9] = 3, 0 != i.mtime && Ia(t, 4, Math.floor(new Date(i.mtime || Date.now()) / 1e3)), e) {
            t[3] = 8;
            for(var r = 0; e.length >= r; ++r)t[r + 10] = e.charCodeAt(r);
        }
    }(h, i), Ia(h, u - 8, e.d()), Ia(h, u - 4, r), h;
}
var Aa = !!o || !!n, Ma = "text/plain", Da = !1, Na = (t, i)=>{
    var e = t.split("#"), r = e[1], s = e[0].split("?"), n = s[0], o = s[1];
    if (!o) return t;
    var a = o.split("&").filter((t)=>t.split("=")[0] !== i).join("&");
    return n + (a ? "?" + a : "") + (r ? "#" + r : "");
}, La = function(t, i, e) {
    var r;
    void 0 === e && (e = !0);
    var s = t.split("?"), n = s[0], o = s[1], a = _({}, i), l = null !== (r = null == o ? void 0 : o.split("&").map((t)=>{
        var i, r = t.split("="), s = r[0], n = e && null !== (i = a[s]) && void 0 !== i ? i : r[1];
        return delete a[s], s + "=" + n;
    })) && void 0 !== r ? r : [], h = function(t, i) {
        var e, r;
        void 0 === i && (i = "&");
        var s = [];
        return vs(t, function(t, i) {
            D(t) || D(i) || "undefined" === i || (e = encodeURIComponent(((t)=>t instanceof File)(t) ? t.name : t.toString()), r = encodeURIComponent(i), s[s.length] = r + "=" + e);
        }), s.join(i);
    }(a);
    return h && l.push(h), l.length > 0 ? n + "?" + l.join("&") : n;
}, ja = (t)=>{
    if (t.po) return t.po;
    var i = t.data, e = t.compression;
    if (i) {
        if (e === Mo.GZipJS) {
            var r = Fa(function(t, i) {
                var e = t.length;
                if ("undefined" != typeof TextEncoder) return (new TextEncoder).encode(t);
                for(var r = new ea(t.length + (t.length >>> 1)), s = 0, n = function(t) {
                    r[s++] = t;
                }, o = 0; e > o; ++o){
                    if (s + 5 > r.length) {
                        var a = new ea(s + 8 + (e - o << 1));
                        a.set(r), r = a;
                    }
                    var l = t.charCodeAt(o);
                    128 > l ? n(l) : 2048 > l ? (n(192 | l >>> 6), n(128 | 63 & l)) : l > 55295 && 57344 > l ? (n(240 | (l = 65536 + (1047552 & l) | 1023 & t.charCodeAt(++o)) >>> 18), n(128 | l >>> 12 & 63), n(128 | l >>> 6 & 63), n(128 | 63 & l)) : (n(224 | l >>> 12), n(128 | l >>> 6 & 63), n(128 | 63 & l));
                }
                return wa(r, 0, s);
            }(io(i)), {
                mtime: 0
            });
            return {
                contentType: Ma,
                body: r.buffer.slice(r.byteOffset, r.byteOffset + r.byteLength),
                estimatedSize: r.byteLength
            };
        }
        if (e === Mo.Base64) {
            var s = function(t) {
                return t ? btoa(encodeURIComponent(t).replace(/%([0-9A-F]{2})/g, (t, i)=>String.fromCharCode(parseInt(i, 16)))) : t;
            }(io(i)), n = ((t)=>"data=" + encodeURIComponent("string" == typeof t ? t : io(t)))(s);
            return {
                contentType: "application/x-www-form-urlencoded",
                body: n,
                estimatedSize: new Blob([
                    n
                ]).size
            };
        }
        var o = io(i);
        return {
            contentType: "application/json",
            body: o,
            estimatedSize: new Blob([
                o
            ]).size
        };
    }
}, Ua = (t)=>{
    var i, e, r = ()=>"sendBeacon" === t.transport ? {
            url: La(t.url, {
                compression: Mo.Base64
            }),
            encodedBody: ja(_({}, t, {
                compression: Mo.Base64,
                po: void 0
            }))
        } : {
            url: Na(t.url, "compression"),
            encodedBody: ja(_({}, t, {
                compression: void 0,
                po: void 0
            }))
        };
    try {
        i = ja(t);
    } catch (i) {
        if (fe(t.compression, ro(t.url, "compression"))) return Ue.error("Failed to gzip request body, sending uncompressed payload", i), r();
        throw i;
    }
    return i && fe(t.compression, ro(t.url, "compression")) && !((e = i.body) instanceof ArrayBuffer ? ce(new Uint8Array(e)) : ArrayBuffer.isView(e) && ce(new Uint8Array(e.buffer, e.byteOffset, e.byteLength))) ? (Da = !0, r()) : {
        url: t.url,
        encodedBody: i
    };
}, Ba = (t)=>{
    try {
        return Ua(t);
    } catch (i) {
        return Ue.error(i), void (null == t.callback || t.callback({
            statusCode: 0,
            error: i
        }));
    }
}, za = function() {
    var t = p(function*(t) {
        var i = io(t.data), e = yield function(t, i, e) {
            return me.apply(this, arguments);
        }(i, c.DEBUG, {
            rethrow: !0
        });
        if (!e) return t;
        var r = yield e.arrayBuffer();
        return _({}, t, {
            po: {
                contentType: Ma,
                body: r,
                estimatedSize: r.byteLength
            }
        });
    });
    return function(i) {
        return t.apply(this, arguments);
    };
}(), Ha = /Failed to fetch|NetworkError|Load failed/i, qa = (t)=>"TypeError" === (null == t ? void 0 : t.name) && Ha.test((null == t ? void 0 : t.message) || ""), Va = (t)=>{
    var i = Ba(t);
    if (i) {
        var e = i.url, r = i.encodedBody, s = null != r ? r : {}, o = s.contentType, l = s.body, h = s.estimatedSize, u = new Headers;
        vs(t.headers, function(t, i) {
            u.append(i, t);
        }), o && u.append("Content-Type", o);
        var d = null, v = !1;
        if (a) {
            var c = new a;
            d = {
                signal: c.signal,
                timeout: setTimeout(()=>{
                    var i;
                    v = !0, c.abort(ki("AbortError", "PostHog request timed out" + ((i = t.timeout) ? " after " + i + "ms" : "")));
                }, t.timeout)
            };
        }
        var f = (i)=>{
            v && "AbortError" === (null == i ? void 0 : i.name) || qa(i) ? Ue.warn(i) : Ue.error(i), null == t.callback || t.callback({
                statusCode: 0,
                error: i
            });
        };
        try {
            var p;
            n(e, _({
                method: (null == t ? void 0 : t.method) || "GET",
                headers: u,
                keepalive: "POST" === t.method && !t.mo && 52428.8 > (h || 0),
                body: l,
                signal: null == (p = d) ? void 0 : p.signal
            }, t.fetchOptions)).then((i)=>i.text().then((e)=>{
                    var r = {
                        statusCode: i.status,
                        text: e
                    };
                    if (200 === i.status) try {
                        r.json = JSON.parse(e);
                    } catch (t) {
                        Ue.error(t);
                    }
                    null == t.callback || t.callback(r);
                })).catch(f).finally(()=>d ? clearTimeout(d.timeout) : null);
        } catch (t) {
            d && clearTimeout(d.timeout), f(t);
        }
    }
}, Wa = (t)=>{
    try {
        var i, r = Ua(t), s = r.url, n = r.encodedBody, o = null != n ? n : {}, a = o.body, l = o.estimatedSize;
        if (!a) return;
        var h = a instanceof Blob ? a : new Blob([
            a
        ], {
            type: o.contentType
        });
        if (e.sendBeacon(s, h)) return;
        var u = I(t.data) ? t.data : null == (i = t.data) ? void 0 : i.batch;
        if (I(u) && u.length > 1 && (null != l ? l : 0) > 16384) {
            var d = Math.ceil(u.length / 2), v = (i)=>I(t.data) ? i : _({}, t.data, {
                    batch: i
                });
            return Wa(_({}, t, {
                data: v(u.slice(0, d))
            })), void Wa(_({}, t, {
                data: v(u.slice(d))
            }));
        }
        Ue.warn("Beacon of ~" + (null != l ? l : 0) + " bytes was rejected by the browser, falling back to fetch"), Va(_({}, t, {
            mo: !0
        }));
    } catch (t) {
        Ue.warn("Beacon send failed", t);
    }
}, Ga = (t, i, e, r)=>{
    var s = "query" === r ? "POST" === i ? "sent_at" : "_" : void 0;
    return La(e === Mo.GZipJS ? Na(t, "compression") : t, _({}, s ? {
        [s]: Date.now().toString()
    } : {}, e === Mo.GZipJS ? {} : {
        compression: e
    }));
}, Ja = [];
n && Ja.push({
    transport: "fetch",
    method: Va
}), o && Ja.push({
    transport: "XHR",
    method (t) {
        var i = Ba(t);
        if (i) {
            var e = new o, r = i.encodedBody;
            e.open(t.method || "GET", i.url, !0);
            var s = null != r ? r : {}, n = s.contentType, a = s.body;
            vs(t.headers, function(t, i) {
                e.setRequestHeader(i, t);
            }), n && e.setRequestHeader("Content-Type", n), t.timeout && (e.timeout = t.timeout), e.onreadystatechange = ()=>{
                if (4 === e.readyState) {
                    var i = {
                        statusCode: e.status,
                        text: e.responseText
                    };
                    if (200 === e.status) try {
                        i.json = JSON.parse(e.responseText);
                    } catch (t) {}
                    null == t.callback || t.callback(i);
                }
            }, e.send(a);
        }
    }
}), null != e && e.sendBeacon && Ja.push({
    transport: "sendBeacon",
    method: Wa
});
var Ka = 3e3;
class Ya {
    constructor(t, i){
        this.yo = !0, this.bo = [], this._o = it((null == i ? void 0 : i.flush_interval_ms) || Ka, 250, 5e3, Ue.createLogger("flush interval"), Ka), this.wo = t;
    }
    enqueue(t) {
        this.bo.push(t), this.ko || this.So();
    }
    unload() {
        this.xo();
        var t = this.bo.length > 0 ? this.Co() : {}, i = Object.values(t);
        [
            ...i.filter((t)=>0 === t.url.indexOf("/e")),
            ...i.filter((t)=>0 !== t.url.indexOf("/e"))
        ].map((t)=>{
            this.To(_({}, t, {
                transport: "sendBeacon"
            }));
        });
    }
    enable() {
        this.yo = !1, this.So();
    }
    So() {
        var t = this;
        this.yo || (this.ko = setTimeout(()=>{
            if (this.xo(), this.bo.length > 0) {
                var i = this.Co(), e = function() {
                    var e = i[r], s = (new Date).getTime();
                    e.data && I(e.data) && vs(e.data, (t)=>{
                        t.offset = Math.abs(t.timestamp - s), delete t.timestamp;
                    }), t.To(e);
                };
                for(var r in i)e();
            }
        }, this._o));
    }
    To(t) {
        try {
            this.wo(t);
        } catch (t) {
            Ue.error(t);
        }
    }
    xo() {
        clearTimeout(this.ko), this.ko = void 0;
    }
    Co() {
        var t = {};
        return vs(this.bo, (i)=>{
            var e, r = i, s = (r ? r.batchKey : null) || r.url;
            D(t[s]) && (t[s] = _({}, r, {
                data: []
            })), null == (e = t[s].data) || e.push(r.data);
        }), this.bo = [], t;
    }
}
var Qa = [
    "retriesPerformedSoFar"
];
class Xa {
    constructor(i){
        this.Mo = !1, this.Io = 3e3, this.bo = [], this._instance = i, this.bo = [], this.Eo = !0, !D(t) && "onLine" in t.navigator && (this.Eo = t.navigator.onLine, this.Ro = ()=>{
            this.Eo = !0, this.Po();
        }, this.Ao = ()=>{
            this.Eo = !1;
        }, ys(t, "online", this.Ro), ys(t, "offline", this.Ao));
    }
    get length() {
        return this.bo.length;
    }
    retriableRequest(t) {
        var i = t.retriesPerformedSoFar, e = g(t, Qa);
        z(i) && (e.url = La(e.url, {
            retry_count: i
        })), this._instance._send_request(_({}, e, {
            callback: (t)=>{
                if (200 !== t.statusCode && (400 > t.statusCode || t.statusCode >= 500)) {
                    if ((0 === t.statusCode ? 3 : 10) > (null != i ? i : 0)) return void this.os(_({
                        retriesPerformedSoFar: i
                    }, e));
                    0 === t.statusCode && Ue.warn("Request failed before receiving an HTTP response; this can happen due to network issues, CORS, browser blocking, or ad blockers. Stopped retrying after " + (null != i ? i : 0) + " retries.");
                }
                null == e.callback || e.callback(t);
            }
        }));
    }
    os(t) {
        var i = t.retriesPerformedSoFar || 0;
        t.retriesPerformedSoFar = i + 1;
        var e = function(t) {
            var i = 3e3 * Math.pow(2, t), e = i / 2, r = Math.min(18e5, i), s = Math.random() - .5;
            return Math.ceil(r + s * (r - e));
        }(i), r = Date.now() + e;
        this.bo.push({
            retryAt: r,
            requestOptions: t
        });
        var s = "Enqueued failed request for retry in " + e;
        navigator.onLine || (s += " (Browser is offline)"), Ue.warn(s), this.Mo || (this.Mo = !0, this.Fo());
    }
    Fo() {
        if (this.Oo && clearTimeout(this.Oo), 0 === this.bo.length) return this.Mo = !1, void (this.Oo = void 0);
        this.Oo = setTimeout(()=>{
            this.Eo && this.bo.length > 0 && this.Po(), this.Fo();
        }, this.Io);
    }
    Po() {
        var t = Date.now(), i = [], e = this.bo.filter((e)=>t > e.retryAt || (i.push(e), !1));
        if (this.bo = i, e.length > 0) for (var r of e)this.retriableRequest(r.requestOptions);
    }
    unload() {
        for (var i of (this.Oo && (clearTimeout(this.Oo), this.Oo = void 0), this.Mo = !1, D(t) || (this.Ro && (t.removeEventListener("online", this.Ro), this.Ro = void 0), this.Ao && (t.removeEventListener("offline", this.Ao), this.Ao = void 0)), this.bo)){
            var e = i.requestOptions;
            try {
                this._instance._send_request(_({}, e, {
                    transport: "sendBeacon"
                }));
            } catch (t) {
                Ue.error(t);
            }
        }
        this.bo = [];
    }
}
class Za {
    constructor(t){
        this.Lo = ()=>{
            var t, i, e, r;
            this.Do || (this.Do = {});
            var s = this.scrollElement(), n = this.scrollY(), o = s ? Math.max(0, s.scrollHeight - s.clientHeight) : 0, a = n + ((null == s ? void 0 : s.clientHeight) || 0), l = (null == s ? void 0 : s.scrollHeight) || 0;
            this.Do.lastScrollY = Math.ceil(n), this.Do.maxScrollY = Math.max(n, null !== (t = this.Do.maxScrollY) && void 0 !== t ? t : 0), this.Do.maxScrollHeight = Math.max(o, null !== (i = this.Do.maxScrollHeight) && void 0 !== i ? i : 0), this.Do.lastContentY = a, this.Do.maxContentY = Math.max(a, null !== (e = this.Do.maxContentY) && void 0 !== e ? e : 0), this.Do.maxContentHeight = Math.max(l, null !== (r = this.Do.maxContentHeight) && void 0 !== r ? r : 0);
        }, this._instance = t;
    }
    get $o() {
        return this._instance.config.scroll_root_selector;
    }
    getContext() {
        return this.Do;
    }
    resetContext() {
        var t = this.Do;
        return setTimeout(this.Lo, 0), t;
    }
    startMeasuringScrollPosition() {
        ys(t, "scroll", this.Lo, {
            capture: !0
        }), ys(t, "scrollend", this.Lo, {
            capture: !0
        }), ys(t, "resize", this.Lo);
    }
    scrollElement() {
        var i;
        if (!this.$o) return null == t || null == (i = t.document) ? void 0 : i.documentElement;
        var e = I(this.$o) ? this.$o : [
            this.$o
        ];
        for (var r of e){
            var s, n = null == t || null == (s = t.document) ? void 0 : s.querySelector(r);
            if (n) return n;
        }
    }
    No(i) {
        var e, r, s = "y" === i ? "scrollTop" : "scrollLeft";
        if (this.$o) {
            var n = this.scrollElement();
            return n && n[s] || 0;
        }
        return t ? "y" === i ? t.scrollY || t.pageYOffset || (null == (e = t.document) || null == (e = e.documentElement) ? void 0 : e.scrollTop) || 0 : t.scrollX || t.pageXOffset || (null == (r = t.document) || null == (r = r.documentElement) ? void 0 : r.scrollLeft) || 0 : 0;
    }
    scrollY() {
        return this.No("y");
    }
    scrollX() {
        return this.No("x");
    }
}
var tl = (t)=>yo(null == t ? void 0 : t.config.mask_personal_data_properties, null == t ? void 0 : t.config.custom_personal_data_properties, null == t ? void 0 : t.config.disable_capture_url_hashes);
class il {
    constructor(t, i, e, r){
        this.Tt = (t)=>{
            var i = this.qo();
            if (!i || i.sessionId !== t) {
                var e = {
                    sessionId: t,
                    props: this.jo(this._instance)
                };
                this.Bo.register({
                    [zr]: e
                });
            }
        }, this._instance = t, this.Ho = i, this.Bo = e, this.jo = r || tl, this.Ho.onSessionId(this.Tt);
    }
    qo() {
        return this.Bo.props[zr];
    }
    getSetOnceProps() {
        var t, i = null == (t = this.qo()) ? void 0 : t.props;
        return i ? "r" in i ? wo(i, this._instance.config.disable_capture_url_hashes) : {
            $referring_domain: i.referringDomain,
            $pathname: i.initialPathName,
            utm_source: i.utm_source,
            utm_campaign: i.utm_campaign,
            utm_medium: i.utm_medium,
            utm_content: i.utm_content,
            utm_term: i.utm_term
        } : {};
    }
    getSessionProps() {
        var t = {};
        return vs(gs(this.getSetOnceProps()), (i, e)=>{
            "$current_url" === e && (e = "url"), t["$session_entry_" + S(e)] = i;
        }), t;
    }
}
class el {
    on(t, i) {
        return this.zo[t] || (this.zo[t] = []), this.zo[t].push(i), ()=>{
            this.zo[t] = this.zo[t].filter((t)=>t !== i);
        };
    }
    emit(t, i) {
        for (var e of this.zo[t] || [])e(i);
        for (var r of this.zo["*"] || [])r(t, i);
    }
    constructor(){
        this.zo = {};
    }
}
var rl = Be("[SessionId]"), sl = 864e5;
class nl {
    on(t, i) {
        return this.Uo.on(t, i);
    }
    constructor(t, i, e){
        var r;
        if (this.Wo = null, this.Vo = null, this.Go = [], this.Zo = void 0, this.Qo = !1, this.Uo = new el, this.Jo = (t, i)=>!(!z(t) || !z(i)) && Math.abs(t - i) > this.sessionTimeoutMs, !t.persistence) throw new Error("SessionIdManager requires a PostHogPersistence instance");
        if (t.config.cookieless_mode === is) throw new Error('SessionIdManager cannot be used with cookieless_mode="always"');
        this.mn = t.config, this.Bo = t.persistence, this.It = void 0, this.Pe = void 0, this._sessionStartTimestamp = null, this.Ko = void 0, this._sessionActivityTimestamp = null, this.Yo = i || Ps, this.Xo = e || Ps;
        var s = this.mn.persistence_name || this.mn.token;
        if (this._sessionTimeoutMs = 1e3 * it(this.mn.session_idle_timeout_seconds || 1800, 60, 36e3, rl.createLogger("session_idle_timeout_seconds"), 1800), t.register({
            $configured_session_timeout_ms: this._sessionTimeoutMs
        }), this.tl(), this.el = "ph_" + s + "_window_id", this.il = "ph_" + s + "_primary_window_exists", this.rl()) {
            var n = Ks.ui(this.el), o = Ks.ui(this.il);
            n && !o ? this.It = n : Ks.oi(this.el), Ks.ni(this.il, !0);
        }
        null != (r = this.mn.bootstrap) && r.sessionID && this.setBootstrapSessionId(this.mn.bootstrap.sessionID), this.nl();
    }
    get sessionTimeoutMs() {
        return this._sessionTimeoutMs;
    }
    onSessionId(t) {
        return D(this.Go) && (this.Go = []), this.Go.push(t), this.Pe && t(this.Pe, this.It), ()=>{
            this.Go = this.Go.filter((i)=>i !== t);
        };
    }
    rl() {
        return "memory" !== this.mn.persistence && !this.Bo.Ma && Ks.ii();
    }
    sl(t) {
        t !== this.It && (this.It = t, this.rl() && Ks.ni(this.el, t));
    }
    al() {
        return this.It ? this.It : this.rl() ? Ks.ui(this.el) : null;
    }
    ol(t) {
        var i = this.Wo;
        return !j(i) && !j(t) && 5e3 > Math.abs(t - i);
    }
    ll(t, i, e) {
        var r = i !== this._sessionActivityTimestamp, s = !(t !== this.Pe || e !== this._sessionStartTimestamp);
        this._sessionStartTimestamp = e, this._sessionActivityTimestamp = i, this.Pe = t, s && !r || s && this.ol(i) || (this.Wo = i, this.Bo.register({
            [gr]: [
                i,
                t,
                e
            ]
        }));
    }
    ul() {
        var t, i = null == (t = this.mn) ? void 0 : t.persistence_save_debounce_ms;
        return z(i) && i > 0;
    }
    hl() {
        this.ul() ? this.Bo.refreshKey(gr) : (this.Bo.flush(), this.Bo.load());
    }
    dl() {
        var t;
        if (!j(this._sessionActivityTimestamp) && this._sessionActivityTimestamp !== this.Wo) {
            this.hl();
            var i = this.vl();
            i[1] === this.Pe && i[2] === this._sessionStartTimestamp && (this.Wo = this._sessionActivityTimestamp, this.Bo.register({
                [gr]: [
                    this._sessionActivityTimestamp,
                    null !== (t = this.Pe) && void 0 !== t ? t : null,
                    this._sessionStartTimestamp
                ]
            }), this.Bo.flush());
        }
    }
    cl() {
        var t = this.vl()[0], i = z(t) ? t : 0, e = z(this._sessionActivityTimestamp) ? this._sessionActivityTimestamp : 0;
        return Math.max(i, e);
    }
    fl(t) {
        return this.hl(), this.Jo(t, this.cl());
    }
    vl() {
        var t = this.Bo.props[gr];
        return I(t) && 2 === t.length && t.push(t[0]), t || [
            0,
            null,
            0
        ];
    }
    resetSessionId() {
        this.Wo = null, this.Ko = void 0, clearTimeout(this.pl), this.pl = void 0, this.ll(null, null, null);
    }
    setBootstrapSessionId(t, i) {
        void 0 === i && (i = !1);
        var e = function(t, i) {
            void 0 === i && (i = (new Date).getTime());
            try {
                var e = ((t)=>{
                    var i = t.replace(/-/g, "");
                    if (32 !== i.length) throw new Error("Not a valid UUID");
                    if ("7" !== i[12]) throw new Error("Not a UUIDv7");
                    return parseInt(i.substring(0, 12), 16);
                })(t);
                return e > i + 6e4 ? void rl.error("Bootstrap sessionID cannot be in the future") : e;
            } catch (t) {
                return void rl.error("Invalid sessionID in bootstrap", t);
            }
        }(t);
        return !D(e) && (i ? this.Ko = {
            sessionId: t,
            sessionStartTimestamp: e
        } : this.ll(t, (new Date).getTime(), e), !0);
    }
    destroy() {
        this.Qo = !0, this.dl(), clearTimeout(this.pl), this.pl = void 0, this.Zo && t && (t.removeEventListener(os, this.Zo, {
            capture: !1
        }), this.Zo = void 0), this.Go = [];
    }
    nl() {
        this.Zo = ()=>{
            this.dl(), this.rl() && Ks.oi(this.il);
        }, ys(t, os, this.Zo, {
            capture: !1
        });
    }
    checkAndGetSessionAndWindowId(t, i, e) {
        if (void 0 === t && (t = !1), void 0 === i && (i = null), void 0 === e && (e = !1), this.mn.cookieless_mode === is) throw new Error('checkAndGetSessionAndWindowId should not be called with cookieless_mode="always"');
        var r = i || (new Date).getTime(), s = this.Pe;
        if (e) this.Vo = r;
        else if (j(this.Vo) || this.Vo > r || r - this.Vo >= 1e3) {
            var n, o;
            null == (n = (o = this.Bo).syncCookieProperties) || n.call(o), this.Vo = r;
        }
        var a = this.vl(), l = a[1], h = a[2], u = !D(s) && l !== s, d = this.cl(), v = this.al(), c = this.Ko, f = !!c && (c.sessionStartTimestamp > r + 6e4 || r - c.sessionStartTimestamp > sl), p = c ? f : z(h) && Math.abs(r - h) > sl, _ = !1, g = u, m = !l || !!c, b = l, y = !m && !t && this.Jo(r, d);
        if (y) {
            (y = this.fl(r)) || rl.info("cross-tab refresh kept the session alive", {
                sessionId: l
            });
            var w = this.vl();
            l = w[1], h = w[2];
        }
        if (m || y || p) {
            g = !1;
            var S = c && !f;
            l = S ? c.sessionId : this.Yo(), v = this.Xo(), rl.info("new session ID assigned", {
                sessionId: l,
                windowId: v,
                bootstrapped: !!S,
                changeReason: {
                    noSessionId: m,
                    activityTimeout: y,
                    sessionPastMaximumLength: p
                }
            }), h = S ? c.sessionStartTimestamp : r, this.Ko = void 0, _ = !0;
        } else v || (v = this.Xo(), _ = !0), (g = g || l !== b) && (rl.info("adopted cross-tab session id", {
            sessionId: l,
            windowId: v
        }), _ = !0);
        var x = z(d) && t && !p ? d : r, E = z(h) ? h : (new Date).getTime();
        this.sl(v), this.ll(l, x, E), t || this.tl();
        var k = {
            noSessionId: m,
            activityTimeout: y,
            sessionPastMaximumLength: p,
            crossTabAdoption: g
        };
        return _ && this.Go.forEach((t)=>t(l, v, k)), {
            sessionId: l,
            windowId: v,
            sessionStartTimestamp: E,
            changeReason: _ ? k : void 0,
            lastActivityTimestamp: d
        };
    }
    tl() {
        this.Qo || (clearTimeout(this.pl), this.pl = setTimeout(()=>{
            if (!this.Qo) if (this.fl((new Date).getTime())) {
                var t = this.Pe;
                this.resetSessionId(), this.Uo.emit("forcedIdleReset", {
                    idleSessionId: t
                });
            } else this.tl();
        }, 1.1 * this.sessionTimeoutMs));
    }
}
var ol = function(t, i) {
    if (!t) return !1;
    var e = t.userAgent;
    if (e && b(e, i)) return !0;
    try {
        var r = null == t ? void 0 : t.userAgentData;
        if (null != r && r.brands && r.brands.some((t)=>b(null == t ? void 0 : t.brand, i))) return !0;
    } catch (t) {}
    return !!t.webdriver;
};
function al() {
    return (al = p(function*() {
        var t = null == e ? void 0 : e.userAgentData;
        if (null != t && t.getHighEntropyValues) try {
            var i = yield t.getHighEntropyValues([
                "model"
            ]), r = null == i ? void 0 : i.model;
            return N(r) && r.length > 0 ? r : void 0;
        } catch (t) {
            return void Ue.info("Unable to resolve $device_model from userAgentData.getHighEntropyValues", t);
        }
    })).apply(this, arguments);
}
function ll(t) {
    var i;
    return !(null == (i = t.conditions) || null == (i = i.events) || null == (i = i.values) || !i.length);
}
var hl = (t, i)=>{
    if (!((t)=>{
        try {
            new RegExp(t);
        } catch (t) {
            return !1;
        }
        return !0;
    })(i)) return !1;
    try {
        return new RegExp(i).test(t);
    } catch (t) {
        return !1;
    }
}, ul = (t)=>t.toLowerCase(), dl = {
    exact: (t, i)=>i.some((i)=>t.some((t)=>i === t)),
    is_not: (t, i)=>i.every((i)=>t.every((t)=>i !== t)),
    regex: (t, i)=>i.some((i)=>t.some((t)=>hl(i, t))),
    not_regex: (t, i)=>i.every((i)=>t.every((t)=>!hl(i, t))),
    icontains: (t, i)=>i.map(ul).some((i)=>t.map(ul).some((t)=>i.includes(t))),
    not_icontains: (t, i)=>i.map(ul).every((i)=>t.map(ul).every((t)=>!i.includes(t))),
    gt: (t, i)=>i.some((i)=>{
            var e = parseFloat(i);
            return !isNaN(e) && t.some((t)=>e > parseFloat(t));
        }),
    lt: (t, i)=>i.some((i)=>{
            var e = parseFloat(i);
            return !isNaN(e) && t.some((t)=>e < parseFloat(t));
        })
};
function vl(t, i) {
    return !t || Object.entries(t).every((t)=>{
        var e = t[1], r = null == i ? void 0 : i[t[0]];
        if (null == r) return !1;
        var s = dl[e.operator];
        return !!s && s(e.values, [
            String(r)
        ]);
    });
}
function cl(t, i, e) {
    return io({
        distinct_id: t,
        userPropertiesToSet: i,
        userPropertiesToSetOnce: e
    });
}
var fl = "custom", pl = "i.posthog.com", _l = /^\/static\//, gl = [
    "/s/",
    "/e/",
    "/i/"
];
class ml {
    constructor(t){
        this.gl = {}, this.instance = t;
    }
    get apiHost() {
        var t = this.instance.config.api_host.trim().replace(/\/$/, "");
        return "https://app.posthog.com" === t ? "https://us.i.posthog.com" : t;
    }
    get flagsApiHost() {
        var t = this.instance.config.flags_api_host;
        return t ? t.trim().replace(/\/$/, "") : this.apiHost;
    }
    get uiHost() {
        var t, i = null == (t = this.instance.config.ui_host) ? void 0 : t.replace(/\/$/, "");
        return i || (i = this.apiHost.replace("." + pl, ".posthog.com")), "https://app.posthog.com" === i ? "https://us.posthog.com" : i;
    }
    get region() {
        return this.gl[this.apiHost] || (this.gl[this.apiHost] = /https:\/\/(app|us|us-assets)(\.i)?\.posthog\.com/i.test(this.apiHost) ? "us" : /https:\/\/(eu|eu-assets)(\.i)?\.posthog\.com/i.test(this.apiHost) ? "eu" : fl), this.gl[this.apiHost];
    }
    ml(t) {
        if (_l.test(t)) {
            var i = this.instance.config.asset_host;
            if ("string" == typeof i) return i.trim().replace(/\/$/, "") || void 0;
        }
    }
    yl(t) {
        var i = eo(t);
        return i ? i.protocol + "//" + i.host + i.pathname : void 0;
    }
    bl(t, i, e) {
        if ("ui" === t) return e;
        var r = e, s = this.instance.config.rewriteRequestPath;
        if (s) {
            var n, o = (null == (n = eo(e)) ? void 0 : n.href) || e;
            r = s(new URL(o)).toString();
        }
        if (s && "api" === t && gl.some((t)=>0 === i.indexOf(t))) {
            var a = this.yl(r);
            if (a) {
                var l, h = this.apiHost, u = this._l;
                (null == (l = u) ? void 0 : l.apiHost) === h && u.rewriteRequestPath === s || (u = {
                    apiHost: h,
                    rewriteRequestPath: s,
                    urls: new Set
                }, this._l = u), u.urls.add(a);
            }
        }
        return r;
    }
    isIngestionEndpoint(t) {
        var i = this._l, e = this.yl(t);
        return (null == i ? void 0 : i.apiHost) === this.apiHost && i.rewriteRequestPath === this.instance.config.rewriteRequestPath && !!e && i.urls.has(e);
    }
    endpointFor(t, i) {
        if (void 0 === i && (i = ""), i && (i = "/" === i[0] ? i : "/" + i), "ui" === t) return this.bl(t, i, this.uiHost + i);
        if ("flags" === t) return this.bl(t, i, this.flagsApiHost + i);
        if ("assets" === t) {
            var e = this.ml(i);
            if (e) return this.bl(t, i, "" + e + i);
        }
        if (this.region === fl) return this.bl(t, i, this.apiHost + i);
        var r = pl + i;
        switch(t){
            case "assets":
                return this.bl(t, i, "https://" + this.region + "-assets." + r);
            case "api":
                return this.bl(t, i, "https://" + this.region + "." + r);
        }
    }
}
var bl = Be("[Surveys]"), yl = "seenSurvey_", wl = (t)=>{
    try {
        var i = ((t)=>((t, i)=>"" + yl + function(t) {
                    return t.current_iteration && t.current_iteration > 0 ? t.id + "_" + t.current_iteration : t.id;
                }(i))(0, t))(t);
        if (localStorage.getItem(i)) return;
        localStorage.setItem(i, "true");
    } catch (t) {
        bl.error("Failed to persist survey seen state", t);
    }
}, Sl = [
    Uo.Popover,
    Uo.Widget,
    Uo.API
], xl = {
    ignoreConditions: !1,
    ignoreDelay: !1,
    displayType: Wo.Popover
}, El = Be("[PostHog ExternalIntegrations]"), kl = {
    intercom: "intercom-integration",
    crispChat: "crisp-chat-integration"
};
class Tl {
    constructor(t){
        this._instance = t;
    }
    Ys(t, i) {
        var e;
        null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this._instance, t, (t)=>{
            if (t) return El.error("failed to load script", t);
            i();
        });
    }
    startIfEnabledOrStop() {
        var t = this, i = function() {
            var i, r, s, n = e[0], o = e[1];
            !o || null != (i = v.__PosthogExtensions__) && null != (i = i.integrations) && i[n] || t.Ys(kl[n], ()=>{
                var i;
                null == (i = v.__PosthogExtensions__) || null == (i = i.integrations) || null == (i = i[n]) || i.start(t._instance);
            }), !o && null != (r = v.__PosthogExtensions__) && null != (r = r.integrations) && r[n] && (null == (s = v.__PosthogExtensions__) || null == (s = s.integrations) || null == (s = s[n]) || s.stop());
        };
        for (var e of Object.entries(null !== (r = this._instance.config.integrations) && void 0 !== r ? r : {})){
            var r;
            i();
        }
    }
}
class $l {
    constructor(t, i){
        this.A = t, this.Ns = i, this.wl = new Map, this.Os = !1;
    }
    add(t) {
        var i = this;
        return p(function*() {
            if (i.Os) throw new Error("Cannot add an extension to a disposed ExtensionRuntime");
            if (i.wl.has(t.name)) throw new Error('Browser extension "' + t.name + '" is already registered');
            i.wl.set(t.name, t);
            try {
                var e = t.setup(i.Ns);
                e && (yield e);
            } catch (e) {
                var r = i.wl.get(t.name) === t;
                r && i.wl.delete(t.name), i.A.error('Failed to set up browser extension "' + t.name + '"', e), r && i.kl(t);
            }
        })();
    }
    getExtension(t) {
        return this.wl.get(t);
    }
    dispose() {
        if (!this.Os) {
            this.Os = !0;
            var t = Array.from(this.wl.values()).reverse();
            for (var i of (this.wl.clear(), t))this.kl(i);
        }
    }
    kl(t) {
        try {
            var i = null == t.dispose ? void 0 : t.dispose();
            i && F(i.then) && i.then(void 0, (i)=>{
                this.A.error('Failed to dispose browser extension "' + t.name + '"', i);
            });
        } catch (i) {
            this.A.error('Failed to dispose browser extension "' + t.name + '"', i);
        }
    }
}
class Pl {
    constructor(t){
        this._instance = t;
    }
    initialize() {}
    get(t) {
        var i = this._instance.persistence;
        if ("string" == typeof t) return null == i ? void 0 : i.get_property(t);
        var e = {};
        for (var r of t){
            var s = null == i ? void 0 : i.get_property(r);
            D(s) || (e[r] = s);
        }
        return e;
    }
    set(t, i) {
        var e;
        null == (e = this._instance.persistence) || e.register("string" == typeof t ? {
            [t]: i
        } : t);
    }
    remove(t) {
        var i;
        null == (i = this._instance.persistence) || i.unregister(t);
    }
}
var Rl = "extensionsRemoteConfig";
class Cl {
    constructor(t){
        this.Os = !1, this.instance = t, this.A = Ue, this.Sl = t.xl, this.kv = new Pl(t), this.onEvent = (t)=>Go(this.instance.on("eventCaptured", (i)=>{
                try {
                    t({
                        event: i.event,
                        properties: i.properties
                    });
                } catch (t) {
                    this.A.error("Browser extension event listener failed", t);
                }
            })), this.onRemoteConfig = (t)=>{
            if (this.Os) return Go(()=>{});
            var i = (i)=>{
                try {
                    t(i);
                } catch (t) {
                    this.A.error("Browser extension remote config listener failed", t);
                }
            }, e = this.instance.Cl.on(Rl, i);
            return this.Sl && i(this.Sl), Go(e);
        }, this.Tl = new $l(Ue.createLogger("[BrowserExtensions]"), this);
    }
    get logger() {
        return this.A;
    }
    get distinctId() {
        return this.instance.get_distinct_id();
    }
    get anonymousId() {
        var t;
        return null !== (t = this.instance.get_property(Ke)) && void 0 !== t ? t : this.distinctId;
    }
    get deviceId() {
        var t = this.instance.get_property(Ke);
        return "string" == typeof t ? t : void 0;
    }
    get library() {
        return {
            name: c.LIB_NAME,
            version: c.LIB_VERSION
        };
    }
    get initialPersonProperties() {
        var t, i;
        return null !== (t = null == (i = this.instance.persistence) ? void 0 : i.get_initial_props()) && void 0 !== t ? t : {};
    }
    get groups() {
        return this.instance.getGroups();
    }
    get session() {
        try {
            var t, i, e, r, s = null == (t = this.instance.sessionManager) ? void 0 : t.checkAndGetSessionAndWindowId(!0);
            return {
                sessionId: null !== (i = null == s ? void 0 : s.sessionId) && void 0 !== i ? i : "",
                windowId: null !== (e = null == s ? void 0 : s.windowId) && void 0 !== e ? e : "",
                sessionStartTimestamp: null !== (r = null == s ? void 0 : s.sessionStartTimestamp) && void 0 !== r ? r : 0
            };
        } catch (t) {
            return {
                sessionId: "",
                windowId: "",
                sessionStartTimestamp: 0
            };
        }
    }
    get canCapture() {
        return this.instance.is_capturing();
    }
    get projectToken() {
        return this.instance.config.token;
    }
    add(t) {
        return this.Tl.add(t);
    }
    getExtension(t) {
        return this.Tl.getExtension(t);
    }
    capture(t, i, e) {
        var r = this;
        return p(function*() {
            e ? r.instance.capture(t, i, {
                timestamp: e.timestamp,
                uuid: e.uuid,
                $set: e.set,
                $set_once: e.setOnce
            }) : r.instance.capture(t, i);
        })();
    }
    registerDynamicEventProperties(t) {
        return Go(this.instance.Ml(t));
    }
    handleRemoteConfig(t) {
        this.Os || (this.Sl = t, this.instance.Cl.emit(Rl, t));
    }
    sendRequest(t, i) {
        var e = this;
        return p(function*() {
            var r;
            void 0 === i && (i = {});
            var s = e.instance.requestRouter.endpointFor(null !== (r = i.target) && void 0 !== r ? r : "api", t), n = {
                method: i.method,
                url: i.query ? La(s, i.query) : s,
                data: i.body,
                headers: i.headers,
                timeout: i.timeoutMs,
                fireCallbackOnDrop: !0,
                transport: i.transport,
                compression: i.compression,
                compressionFallback: "flags" === i.target && "best-available" === i.compression ? k.Base64 : void 0,
                timestampMode: i.sentAt
            };
            return "sendBeacon" === i.transport ? (e.instance._send_request(n), {
                statusCode: 202
            }) : new Promise((t)=>{
                n.callback = t, e.instance._send_request(n);
            });
        })();
    }
    dispose() {
        this.Os || (this.Os = !0, this.Tl.dispose());
    }
}
var Ol = {}, Il = 0, Fl = ()=>{}, Al = 'Consent opt in/out is not valid with cookieless_mode="always" and will be ignored', Ml = "Surveys module not available", Dl = "sanitize_properties is deprecated. Use before_send instead", Nl = "Invalid value for property_denylist config: ", Ll = /^[A-Za-z0-9_-]{1,400}$/, jl = /^fb\.[0-9]+\.[0-9]+\.[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+)?$/, Ul = [
    "token",
    "distinct_id",
    Kr
], Bl = "posthog", zl = !Aa && -1 === (null == h ? void 0 : h.indexOf("MSIE")) && -1 === (null == h ? void 0 : h.indexOf("Mozilla")), Hl = (t)=>{
    var i = {};
    return t && "unset" !== t ? ("2025-11-30" > t || (i.strictMinimumDuration = !0), "2026-05-30" > t || (i.canvasCapture = {
        resolutionScale: .6
    }), "2026-06-25" > t || (i.streamNetworkBody = !0), "2026-08-30" > t || (i.captureJsonLd = !0), i) : i;
}, ql = (i)=>{
    var e;
    return _({
        api_host: "https://us.i.posthog.com",
        flags_api_host: null,
        ui_host: null,
        asset_host: null,
        token: "",
        autocapture: !0,
        cross_subdomain_cookie: bs(null == r ? void 0 : r.location),
        persistence: "localStorage+cookie",
        persistence_name: "",
        cookie_persisted_properties: [],
        loaded: Fl,
        save_campaign_params: !0,
        custom_campaign_params: [],
        custom_blocked_useragents: [],
        save_referrer: !0,
        capture_pageleave: "if_capture_pageview",
        defaults: null != i ? i : "unset",
        __preview_deferred_init_extensions: !1,
        __preview_external_dependency_versioned_paths: !1,
        __preview_cookie_wins_on_conflict: !1,
        debug: s && N(null == s ? void 0 : s.search) && -1 !== s.search.indexOf("__posthog_debug=true") || !1,
        cookie_expiration: 365,
        upgrade: !1,
        disable_session_recording: !1,
        disable_persistence: !1,
        disable_web_experiments: !0,
        disable_surveys: !1,
        disable_surveys_automatic_display: !1,
        disable_conversations: !1,
        disable_product_tours: !1,
        disableDeviceModel: !1,
        disable_external_dependency_loading: !1,
        strict_script_versioning: "fallback",
        enable_recording_console_log: void 0,
        secure_cookie: "https:" === (null == t || null == (e = t.location) ? void 0 : e.protocol),
        ip: !1,
        opt_out_capturing_by_default: !1,
        opt_out_persistence_by_default: !1,
        opt_out_useragent_filter: !1,
        opt_out_capturing_persistence_type: "localStorage",
        consent_persistence_name: null,
        opt_out_capturing_cookie_prefix: null,
        opt_in_site_apps: !1,
        property_denylist: [],
        respect_dnt: !1,
        sanitize_properties: null,
        request_headers: {},
        request_batching: !0,
        properties_string_max_length: 65535,
        mask_all_element_attributes: !1,
        mask_all_text: !1,
        mask_personal_data_properties: !1,
        custom_personal_data_properties: [],
        advanced_disable_flags: !1,
        advanced_disable_decide: !1,
        advanced_disable_feature_flags: !1,
        advanced_disable_feature_flags_on_first_load: !1,
        advanced_only_evaluate_survey_feature_flags: !1,
        advanced_feature_flags_dedup_per_session: !1,
        advanced_enable_surveys: !1,
        advanced_disable_toolbar_metrics: !1,
        feature_flag_request_timeout_ms: 3e3,
        surveys_request_timeout_ms: 1e4,
        on_request_error (t) {
            Ue.error("Bad HTTP status: " + t.statusCode + " " + t.text);
        },
        get_device_id: (t)=>t,
        capture_performance: void 0,
        name: "posthog",
        bootstrap: {},
        disable_compression: !1,
        session_idle_timeout_seconds: 1800,
        person_profiles: ss,
        before_send: void 0,
        get_current_url: void 0,
        request_queue_config: {
            flush_interval_ms: Ka
        },
        error_tracking: {},
        _onCapture: Fl
    }, ((t)=>({
            rageclick: t && t >= "2026-05-30" ? {
                content_ignorelist: yn,
                ignore_text_selection: !0
            } : !t || "2025-11-30" > t || {
                content_ignorelist: !0
            },
            capture_pageview: !t || "2025-05-24" > t || "history_change",
            session_recording: Hl(t),
            external_scripts_inject_target: t && t >= "2026-01-30" ? "head" : "body",
            internal_or_test_user_hostname: t && t >= "2026-01-30" ? /^(localhost|127\.0\.0\.1)$/ : void 0,
            persistence_save_debounce_ms: t && t >= "2026-05-30" ? 250 : 0,
            split_storage: !(!t || "2026-05-30" > t),
            detect_google_search_app: !(!t || "2026-05-30" > t),
            disable_capture_url_hashes: !(!t || "2026-06-25" > t),
            cookieWinsOnConflict: !(!t || "unset" === t || "2026-08-29" > t)
        }))(i));
}, Vl = [
    [
        "process_person",
        "person_profiles"
    ],
    [
        "xhr_headers",
        "request_headers"
    ],
    [
        "cookie_name",
        "persistence_name"
    ],
    [
        "disable_cookie",
        "disable_persistence"
    ],
    [
        "__preview_disable_beacon",
        "disable_beacon"
    ],
    [
        "store_google",
        "save_campaign_params"
    ],
    [
        "verbose",
        "debug"
    ],
    [
        "__preview_cookie_wins_on_conflict",
        "cookieWinsOnConflict"
    ]
], Wl = (t)=>{
    var i = {};
    for (var e of Vl){
        var r = e[0], s = e[1];
        D(t[r]) || (i[s] = t[r]);
    }
    var n = cs({}, i, t), o = t.__preview_external_dependency_versioned_paths;
    return D(o) || (D(t.strict_script_versioning) && (n.strict_script_versioning = !!o), N(o) && D(t.asset_host) && (n.asset_host = o)), I(t.property_blacklist) && (D(t.property_denylist) ? n.property_denylist = t.property_blacklist : I(t.property_denylist) ? n.property_denylist = [
        ...t.property_blacklist,
        ...t.property_denylist
    ] : Ue.error(Nl + t.property_denylist)), n;
};
class Gl {
    constructor(){
        this.__forceAllowLocalhost = !1;
    }
    get Il() {
        return this.__forceAllowLocalhost;
    }
    set Il(t) {
        Ue.error("WebPerformanceObserver is deprecated and has no impact on network capture. Use `_forceAllowLocalhostNetworkCapture` on `posthog.sessionRecording`"), this.__forceAllowLocalhost = t;
    }
}
class Jl {
    El(t) {
        if (t) {
            var i = this.wl.indexOf(t);
            -1 !== i && this.wl.splice(i, 1);
        }
    }
    Rl(t, i) {
        return this.El(t), this.wl.push(i), null == i.initialize || i.initialize(), i;
    }
    Pl() {
        return this.config.cookieless_mode === is || this.config.cookieless_mode === ts && this.consent.isRejected();
    }
    Al() {
        if (!this.Fl && !this.config.segment && !this.Pl()) {
            var t, i, e, r = "memory" === this.config.persistence || "sessionStorage" === this.config.persistence;
            (r || this.config.disable_persistence) && (this.Ol || (r ? (t = "persistence is set to '" + this.config.persistence + "'", i = "memory" === this.config.persistence ? "on every page load" : "for every new browser tab or window", e = "Either set persistence to 'localStorage+cookie', or keep this persistence and pass a stable ID through bootstrap.distinctID.") : (t = "persistence is disabled (disable_persistence is true)", i = "on every page load", e = "Either set disable_persistence to false, or keep persistence disabled and pass a stable ID through bootstrap.distinctID."), this.Fl = !0, console.warn("[PostHog.js]", t + " but no bootstrap.distinctID was provided. PostHog will mint a new distinct ID " + i + ", so calling identify() merges a new ID onto the person each time. A person can then pass the distinct-ID limit and its events stop appearing on person pages and the session tab. " + e)));
        }
    }
    Ll() {
        if (!this.Pl() && this.get_distinct_id() === Jr) {
            var t = this.persistence;
            if (t) {
                this.Dl() || t.load(!0);
                var i = this.get_distinct_id();
                if (!i || i === Jr) {
                    var e = this.config.get_device_id(Ps());
                    this.register({
                        distinct_id: e,
                        $device_id: e
                    }), t.set_property(Br, es);
                }
                this.$l();
            }
        }
    }
    get decideEndpointWasHit() {
        var t, i;
        return null !== (t = null == (i = this.featureFlags) ? void 0 : i.hasLoadedFlags) && void 0 !== t && t;
    }
    get flagsEndpointWasHit() {
        var t, i;
        return null !== (t = null == (i = this.featureFlags) ? void 0 : i.hasLoadedFlags) && void 0 !== t && t;
    }
    constructor(){
        var t;
        this.webPerformance = new Gl, this.Nl = !1, this.version = c.LIB_VERSION, this.ql = new Set, this.jl = "", this.Cl = new el, this.wl = [], this.Bl = [], this.Ol = !1, this.Fl = !1, this._calculate_event_properties = this.calculateEventProperties.bind(this), this.config = ql(), this.SentryIntegration = Kn, this.sentryIntegration = (t)=>(function(t, i) {
                var e = Jn(t, i);
                return {
                    name: Gn,
                    processEvent: (t)=>e(t)
                };
            })(this, t), this.__request_queue = [], this.__loaded = !1, this.analyticsDefaultEndpoint = "/e/", this.Hl = !1, this.zl = null, this.Ul = null, this.Wl = null, this.scrollManager = new Za(this), this.pageViewManager = new Yn(this), this.rateLimiter = new Xo(this), this.requestRouter = new ml(this), this.consent = new Ys(this), this.externalIntegrations = new Tl(this);
        var i = null !== (t = Jl.__defaultExtensionClasses) && void 0 !== t ? t : {};
        this.featureFlags = i.featureFlags && new i.featureFlags(this), this.toolbar = i.toolbar && new i.toolbar(this), this.surveys = i.surveys && new i.surveys(this), this.conversations = i.conversations && new i.conversations(this), this.logs = i.logs && new i.logs(this), this.metrics = i.metrics && new i.metrics(this), this.experiments = i.experiments && new i.experiments(this), this.exceptions = i.exceptions && new i.exceptions(this), this.people = {
            set: (t, i, e)=>{
                var r = N(t) ? {
                    [t]: i
                } : t;
                this.setPersonProperties(r), null == e || e({});
            },
            set_once: (t, i, e)=>{
                var r = N(t) ? {
                    [t]: i
                } : t;
                this.setPersonProperties(void 0, r), null == e || e({});
            }
        }, this.on("eventCaptured", (t)=>Ue.info('send "' + (null == t ? void 0 : t.event) + '"', t));
    }
    init(t, i, e) {
        if (e && e !== Bl) {
            var r, s = null !== (r = Ol[e]) && void 0 !== r ? r : new Jl;
            return s._init(t, i, e), Ol[e] = s, Ol[Bl][e] = s, s;
        }
        return this._init(t, i, e);
    }
    _init(i, e, r) {
        var s, n, o;
        void 0 === e && (e = {});
        var a, l = N(i) ? i.trim() : "";
        if (!l) return Ue.critical("PostHog was initialized without a token. This likely indicates a misconfiguration. Please check the first argument passed to posthog.init()"), this;
        if (this.__loaded) return l !== (null == (a = this.config) ? void 0 : a.token) ? console.warn("[PostHog.js]", "You have already initialized PostHog with a different project token! Re-initializing is a no-op, so events will keep going to the project this instance was initialized with. To capture into a second project, load PostHog once, then initialize a named instance after the SDK has loaded, e.g. posthog.init('" + l + "', { ... }, 'project2')") : console.warn("[PostHog.js]", "You have already initialized PostHog! Re-initializing is a no-op"), this;
        this.__loaded = !0, this.config = ql(e.defaults), e.debug = this.Vl(e.debug), this.Gl = e, this.Zl = [], e.person_profiles ? this.Ul = e.person_profiles : e.process_person && (this.Ul = e.process_person);
        var h = ql(e.defaults), u = Wl(e), d = cs({}, h, u, {
            name: r,
            token: l
        });
        A(h.rageclick) && A(u.rageclick) && (d.rageclick = cs({}, h.rageclick, u.rageclick)), A(h.session_recording) && A(u.session_recording) && (d.session_recording = cs({}, h.session_recording, u.session_recording)), this.set_config(d), this.config.on_xhr_error && Ue.error("on_xhr_error is deprecated. Use on_request_error instead"), this.compression = e.disable_compression ? void 0 : Mo.GZipJS;
        var v = this.Dl();
        if (this.persistence = new Ao(this.config, v), this.sessionPersistence = "sessionStorage" === this.config.persistence || "memory" === this.config.persistence ? this.persistence : new Ao(_({}, this.config, {
            persistence: "sessionStorage"
        }), v, !1), this.jl = "ph_" + (this.config.persistence_name || this.config.token) + "_session_registered_properties", "memory" !== this.config.persistence && !v && Ks.ii()) {
            var f = Ks.ui(this.jl);
            I(f) && f.forEach((t)=>{
                N(t) && this.ql.add(t);
            });
        } else Ks.oi(this.jl);
        var p = _({}, this.persistence.props), g = _({}, this.sessionPersistence.props);
        this.register({
            $initialization_time: (new Date).toISOString()
        }), this.Ql = new Ya((t)=>this.Jl(t), this.config.request_queue_config), this.Kl = new Xa(this), this.__request_queue = [];
        var m = this.Pl();
        m || (this.sessionManager = new nl(this), this.sessionPropsManager = new il(this, this.sessionManager, this.persistence), this.sessionManager.onSessionId((t, i, e)=>{
            (null != e && e.activityTimeout || null != e && e.sessionPastMaximumLength || null != e && e.crossTabAdoption) && this.Yl();
        })), this.Xl(), this.config.__preview_deferred_init_extensions ? (Ue.info("Deferring extension initialization to improve startup performance"), setTimeout(()=>{
            this.tu(m);
        }, 0)) : (Ue.info("Initializing extensions synchronously"), this.tu(m)), c.DEBUG = c.DEBUG || this.config.debug, c.DEBUG && Ue.info("Starting in debug mode", {
            this: this,
            config: e,
            thisC: _({}, this.config),
            p: p,
            s: g
        }), !this.config.identity_distinct_id || null != (s = e.bootstrap) && s.distinctID || (e.bootstrap = _({}, e.bootstrap, {
            distinctID: this.config.identity_distinct_id,
            isIdentifiedID: !0
        }));
        var b = null == (n = e.bootstrap) ? void 0 : n.distinctID;
        if (this.Ol = !!b && !L(b), void 0 !== (null == (o = e.bootstrap) ? void 0 : o.distinctID)) {
            var y = e.bootstrap.distinctID, w = this.get_distinct_id(), S = this.persistence.get_property(Br);
            if (e.bootstrap.isIdentifiedID && null != w && w !== y && S === es) this.identify(y);
            else if (e.bootstrap.isIdentifiedID && null != w && w !== y && S === rs) Ue.warn("Bootstrap distinctID differs from an already-identified user. The existing identity is preserved. Call reset() before reinitializing if you intend to switch users.");
            else {
                var x = this.config.get_device_id(Ps()), E = e.bootstrap.isIdentifiedID ? x : y;
                this.persistence.set_property(Br, e.bootstrap.isIdentifiedID ? rs : es), this.register({
                    distinct_id: y,
                    $device_id: E
                });
            }
        }
        if (m) this.register_once({
            distinct_id: Jr,
            $device_id: null
        }, "");
        else if (!this.get_distinct_id()) {
            var k = this.config.get_device_id(Ps());
            this.register_once({
                distinct_id: k,
                $device_id: k
            }, ""), this.persistence.set_property(Br, es);
        }
        return ys(t, "onpagehide" in self ? "pagehide" : "unload", this._handle_unload.bind(this), {
            passive: !1
        }), e.segment ? Wn(this, ()=>this.eu()) : this.eu(), F(this.config._onCapture) && this.config._onCapture !== Fl && (Ue.warn("onCapture is deprecated. Please use `before_send` instead"), this.on("eventCaptured", (t)=>this.config._onCapture(t.event, t))), this.config.ip && Ue.warn('The `ip` config option has NO EFFECT AT ALL and has been deprecated. Use a custom transformation or "Discard IP data" project setting instead. See https://posthog.com/tutorials/web-redact-properties#hiding-customer-ip-address for more information.'), this.config.disableDeviceModel || (function() {
            return al.apply(this, arguments);
        })().then((t)=>{
            t && this.register({
                [Ye]: t
            });
        }).catch(Fl), this;
    }
    iu(t) {
        var i = t;
        return N(i.name) && F(i.setup);
    }
    ru(t, i) {
        this.iu(t) ? i.push(()=>{
            this.nu().add(t).catch(()=>null == t.dispose ? void 0 : t.dispose()).catch((i)=>{
                Ue.error('Failed to dispose browser extension "' + t.name + '"', i);
            });
        }) : this.wl.push(t);
    }
    Xl() {
        var t, i, e, r, s, n, o = null !== (t = null == (i = this.config.__extensionClasses) ? void 0 : i.featureFlags) && void 0 !== t ? t : null == (e = Jl.__defaultExtensionClasses) ? void 0 : e.featureFlags;
        o && (this.featureFlags && this.featureFlags instanceof o || (null == (r = this.su) || r.call(this), this.su = void 0, this.featureFlags = new o(this)), F(this.featureFlags.onReloading) && F(this.featureFlags.setup) ? this.su || (this.su = this.featureFlags.onReloading(()=>{
            this.Cl.emit("featureFlagsReloading", !0);
        }), this.nu().add(this.featureFlags)) : null == (s = (n = this.featureFlags).initialize) || s.call(n));
    }
    tu(t) {
        var i, e, r, s, n, o, a, l = performance.now(), h = _({}, Jl.__defaultExtensionClasses, this.config.__extensionClasses), u = [];
        h.exceptions && this.wl.push(this.exceptions = null !== (i = this.exceptions) && void 0 !== i ? i : new h.exceptions(this)), h.historyAutocapture && this.wl.push(this.historyAutocapture = new h.historyAutocapture(this)), h.tracingHeaders && this.wl.push(this.tracingHeaders = new h.tracingHeaders(this)), h.siteApps && this.wl.push(this.siteApps = new h.siteApps(this)), h.sessionRecording && !t && this.wl.push(this.sessionRecording = new h.sessionRecording(this)), this.config.disable_scroll_properties || u.push(()=>{
            this.scrollManager.startMeasuringScrollPosition();
        }), h.autocapture && this.ru(this.autocapture = new h.autocapture(this), u), h.surveys && this.ru(this.surveys = null !== (e = this.surveys) && void 0 !== e ? e : new h.surveys(this), u), h.logs && this.ru(this.logs = null !== (r = this.logs) && void 0 !== r ? r : new h.logs(this), u), h.metrics && this.wl.push(this.metrics = null !== (s = this.metrics) && void 0 !== s ? s : new h.metrics(this)), h.conversations && this.wl.push(this.conversations = null !== (n = this.conversations) && void 0 !== n ? n : new h.conversations(this)), h.productTours && this.wl.push(this.productTours = new h.productTours(this)), h.heatmaps && this.wl.push(this.heatmaps = new h.heatmaps(this)), h.webVitalsAutocapture && this.wl.push(this.webVitalsAutocapture = new h.webVitalsAutocapture(this)), h.exceptionObserver && this.wl.push(this.exceptionObserver = new h.exceptionObserver(this)), h.deadClicksAutocapture && this.wl.push(this.deadClicksAutocapture = new h.deadClicksAutocapture(this, Hn)), h.toolbar && this.wl.push(this.toolbar = null !== (o = this.toolbar) && void 0 !== o ? o : new h.toolbar(this)), h.experiments && this.wl.push(this.experiments = null !== (a = this.experiments) && void 0 !== a ? a : new h.experiments(this)), this.wl.forEach((t)=>{
            t.initialize && u.push(()=>{
                null == t.initialize || t.initialize();
            });
        }), u.push(()=>{
            if (this.au) {
                var t = this.au;
                this.au = void 0, this.wl.forEach((i)=>null == i.onRemoteConfig ? void 0 : i.onRemoteConfig(t));
            }
        }), this.ou(u, l);
    }
    ou(t, i) {
        for(; t.length > 0;){
            if (this.config.__preview_deferred_init_extensions && performance.now() - i >= 30 && t.length > 0) return void setTimeout(()=>{
                this.ou(t, i);
            }, 0);
            var e = t.shift();
            if (e) try {
                e();
            } catch (t) {
                Ue.error("Error initializing extension:", t);
            }
        }
        var r = Math.round(performance.now() - i);
        this.register_for_session({
            [Yr]: this.config.__preview_deferred_init_extensions ? "deferred" : "synchronous",
            [Qr]: r
        }), this.config.__preview_deferred_init_extensions && Ue.info("PostHog extensions initialized (" + r + "ms)");
    }
    co(t) {
        var i;
        if (!r || !r.body) return Ue.info("document not ready yet, trying again in 500 milliseconds..."), void setTimeout(()=>{
            this.co(t);
        }, 500);
        if (this.config.__preview_deferred_init_extensions && (this.au = t), this.xl = t, this.compression = void 0, t.ok) {
            var e, s = t.config;
            s.supportedCompression && !this.config.disable_compression && (this.compression = y(s.supportedCompression, Mo.GZipJS) ? Mo.GZipJS : y(s.supportedCompression, Mo.Base64) ? Mo.Base64 : void 0), null != (e = s.analytics) && e.endpoint && (this.analyticsDefaultEndpoint = s.analytics.endpoint);
        }
        this.set_config({
            person_profiles: this.Ul ? this.Ul : ss
        }), null == (i = this.lu) || i.handleRemoteConfig(t), this.wl.forEach((i)=>null == i.onRemoteConfig ? void 0 : i.onRemoteConfig(t));
    }
    eu() {
        try {
            this.config.loaded(this);
        } catch (t) {
            Ue.critical("`loaded` function failed", t);
        }
        if (this.uu(), this.config.internal_or_test_user_hostname && null != s && s.hostname) {
            var t = s.hostname, i = this.config.internal_or_test_user_hostname;
            ("string" == typeof i ? t === i : i.test(t)) && this.setInternalOrTestUser();
        }
        this.config.capture_pageview && setTimeout(()=>{
            (this.consent.isOptedIn() || this.Pl()) && this.hu();
        }, 1), this.du = new ta(this), this.du.load();
    }
    uu() {
        var t;
        this.is_capturing() && this.config.request_batching && (null == (t = this.Ql) || t.enable());
    }
    _dom_loaded() {
        this.is_capturing() && ds(this.__request_queue, (t)=>this.Jl(t)), this.__request_queue = [], this.uu();
    }
    _handle_unload() {
        var t, i, e, r, s;
        null == (t = this.surveys) || null == t.handlePageUnload || t.handlePageUnload(), null == (i = this.metrics) || i.flush("sendBeacon"), this.config.request_batching ? (this.vu() && this.capture(ls), null == (e = this.logs) || e.flushLogs("sendBeacon"), null == (r = this.Ql) || r.unload(), null == (s = this.Kl) || s.unload()) : this.vu() && this.capture(ls, null, {
            transport: "sendBeacon"
        });
    }
    _send_request(t) {
        var i;
        this.__loaded ? zl ? this.__request_queue.push(t) : this.rateLimiter.isServerRateLimited(t.batchKey) ? t.fireCallbackOnDrop && (null == t.callback || t.callback({
            statusCode: 429
        })) : (t.transport = t.transport || this.config.api_transport, t.headers = _({}, this.config.request_headers, t.headers), t.compression = "best-available" === t.compression ? null !== (i = this.compression) && void 0 !== i ? i : t.compressionFallback : t.compression, (D(this.config.disable_beacon) ? this.config.__preview_disable_beacon : this.config.disable_beacon) && (t.disableTransport = [
            "sendBeacon"
        ]), t.fetchOptions = t.fetchOptions || this.config.fetch_options, ((t)=>{
            var i, e, r, s = _({}, t);
            s.timeout = s.timeout || 6e4;
            var n, o, a, h, u, d = null !== (i = s.transport) && void 0 !== i ? i : "fetch";
            "sendBeacon" === d && D(s.compression) && s.data && (s.compression = Mo.Base64), "POST" === s.method && s.data && ("capture-body" === s.timestampMode ? s.data = {
                api_key: null !== (o = null == (u = (h = (I(n = s.data) ? n : [
                    n
                ]).map((t)=>_({}, t, t.timestamp instanceof Date && !isNaN(t.timestamp.getTime()) ? {
                        timestamp: t.timestamp.toISOString()
                    } : {})))[0]) || null == (a = u.properties) ? void 0 : a.token) && void 0 !== o ? o : null == u ? void 0 : u.token,
                batch: h,
                sent_at: (new Date).toISOString()
            } : "body" === s.timestampMode && (s.data = function(t, i) {
                return void 0 === i && (i = (new Date).toISOString()), I(t) ? t.map((t)=>_({}, t, {
                        sent_at: i
                    })) : _({}, t, {
                    sent_at: i
                });
            }(s.data))), s.url = Ga(s.url, s.method, s.compression, s.timestampMode);
            var v = Ja.filter((t)=>!s.disableTransport || !t.transport || !s.disableTransport.includes(t.transport)), c = null !== (e = null == (r = function(t, i) {
                for(var e = 0; t.length > e; e++)if (t[e].transport === d) return t[e];
            }(v)) ? void 0 : r.method) && void 0 !== e ? e : v[0].method;
            if (!c) throw new Error("No available transport method");
            var f = (t)=>{
                try {
                    c(t);
                } catch (t) {
                    qa(t) ? Ue.warn(t) : Ue.error(t), null == s.callback || s.callback({
                        statusCode: 0,
                        error: t
                    });
                }
            };
            "sendBeacon" !== d && s.data && s.compression === Mo.GZipJS && l && "undefined" != typeof Promise && !Da ? za(s).then((t)=>{
                f(t);
            }).catch((i)=>{
                if (pe(i)) return Da = !0, void f(_({}, s, {
                    compression: void 0,
                    url: Ga(t.url, t.method, void 0, t.timestampMode)
                }));
                ((t)=>{
                    if (!t || "object" != typeof t) return !1;
                    var i = "name" in t ? String(t.name) : "";
                    return pe(t) || i === ve;
                })(i) && (Da = !0), f(s);
            }) : c(s);
        })(_({}, t, {
            callback: (i)=>{
                var e, r;
                this.rateLimiter.checkForLimiting(i), 400 > i.statusCode || null == (e = (r = this.config).on_request_error) || e.call(r, i), null == t.callback || t.callback(i);
            }
        }))) : t.fireCallbackOnDrop && (null == t.callback || t.callback({
            statusCode: 0
        }));
    }
    Jl(t) {
        this.Kl ? this.Kl.retriableRequest(t) : this._send_request(t);
    }
    _execute_array(t) {
        Il++;
        try {
            var i, e = [], r = [], s = [];
            ds(t, (t)=>{
                if (t) if (I(i = t[0])) s.push(t);
                else if (F(t)) try {
                    t.call(this);
                } catch (i) {
                    Ue.error("Error executing queued PostHog call", t, i);
                }
                else I(t) && "alias" === i ? e.push(t) : I(t) && -1 !== i.indexOf("capture") && F(this[i]) ? s.push(t) : r.push(t);
            });
            var n = function(t, i) {
                ds(t, function(t) {
                    try {
                        if (I(t[0])) {
                            var e = i;
                            vs(t, function(t) {
                                e = e[t[0]].apply(e, t.slice(1));
                            });
                        } else i[t[0]].apply(i, t.slice(1));
                    } catch (i) {
                        Ue.error("Error executing queued PostHog call", t, i);
                    }
                });
            };
            n(e, this), n(r, this), n(s, this);
        } finally{
            Il--;
        }
    }
    push(t) {
        if (Il > 0 && I(t) && N(t[0])) {
            var i = Jl.prototype[t[0]];
            F(i) && i.apply(this, t.slice(1));
        } else this._execute_array([
            t
        ]);
    }
    cu() {
        var t, i = null == (t = this.persistence) ? void 0 : t.get_property(Ze);
        return N(i) && jl.test(i) ? {
            value: i,
            delivered: !1
        } : A(i) && N(i.value) && jl.test(i.value) ? {
            value: i.value,
            delivered: !0 === i.delivered
        } : void 0;
    }
    fu(t, i, e, r) {
        if (this.persistence) {
            this.persistence.refreshKey(Ze);
            var s = this.cu();
            if (!r) {
                if (e) return N(i) && jl.test(i) ? (i !== (null == s ? void 0 : s.value) && this.persistence.register({
                    [Ze]: {
                        value: i,
                        delivered: !1
                    }
                }), {
                    value: i,
                    pending: i !== (null == s ? void 0 : s.value) || !s.delivered
                }) : void this.persistence.unregister(Ze);
                if (N(t) && Ll.test(t)) {
                    if ((null == s ? void 0 : s.value.split(".")[3]) === t) return {
                        value: s.value,
                        pending: !s.delivered
                    };
                    var n = "fb.1." + Date.now() + "." + t;
                    return this.persistence.register({
                        [Ze]: {
                            value: n,
                            delivered: !1
                        }
                    }), {
                        value: n,
                        pending: !0
                    };
                }
                return s ? {
                    value: s.value,
                    pending: !s.delivered
                } : void 0;
            }
            this.persistence.unregister(Ze);
        }
    }
    pu(t) {
        if (this.persistence) {
            this.persistence.refreshKey(Ze);
            var i = this.cu();
            (null == i ? void 0 : i.value) !== t || i.delivered || this.persistence.register({
                [Ze]: {
                    value: t,
                    delivered: !0
                }
            });
        }
    }
    capture(t, i, e) {
        var r, s, n, o, a, l, h, u, d, v;
        if (this.__loaded && this.persistence && this.sessionPersistence && this.Ql) {
            if (this.is_capturing()) if (!D(t) && N(t)) {
                this.Ll();
                var c = !this.config.opt_out_useragent_filter && this._is_bot();
                if (!c || this.config.__preview_capture_bot_pageviews) {
                    var f = null != e && e.skip_client_rate_limiting ? void 0 : this.rateLimiter.clientRateLimitContext();
                    if (null == f || !f.isRateLimited) {
                        var p;
                        null != i && i.$current_url && !N(null == i ? void 0 : i.$current_url) && (Ue.error("Invalid `$current_url` property provided to `posthog.capture`. Input must be a string. Ignoring provided value."), null == i || delete i.$current_url), "$exception" !== t || null != e && e.gu || Ue.warn("Using `posthog.capture('$exception')` is unreliable because it does not attach required metadata. Use `posthog.captureException(error)` instead, which attaches required metadata automatically."), this.sessionPersistence.update_search_keyword(), this.config.save_campaign_params && (p = this.sessionPersistence.update_campaign_params()), this.config.save_referrer && this.sessionPersistence.update_referrer_info(), (this.config.save_campaign_params || this.config.save_referrer) && this.persistence.set_initial_person_info();
                        var g = new Date, m = (null == e ? void 0 : e.timestamp) || g, b = Ei(null == e ? void 0 : e.uuid, Ps), y = {
                            uuid: b,
                            event: t,
                            properties: this.calculateEventProperties(t, i || {}, m, b)
                        };
                        t === as && this.config.__preview_capture_bot_pageviews && c && (y.event = "$bot_pageview", y.properties.$browser_type = "bot"), f && (y.properties.$lib_rate_limit_remaining_tokens = f.remainingTokens);
                        var w = "$feature_flag_called" === t && !1 === y.properties.$feature_flag_has_experiment && !0 === this.get_property(kr);
                        (null == e ? void 0 : e.$set) && !w && (y.$set = null == e ? void 0 : e.$set);
                        var S = A(null == i ? void 0 : i.$set) ? i.$set : void 0, x = !(null == e || !e.$set) && Xe in e.$set, E = x || !!S && Xe in S, k = x ? null == e || null == (r = e.$set) ? void 0 : r[Xe] : null == S ? void 0 : S[Xe], T = I(null == i ? void 0 : i.$unset) ? i.$unset : [], P = (null == e ? void 0 : e.$unset) || [], R = -1 !== T.indexOf(Xe) || -1 !== P.indexOf(Xe), C = this.fu(null == (s = p) ? void 0 : s.fbclid, k, E, R);
                        C && !0 === y.properties.$process_person_profile && C.pending && !E && !w && (y.$set = _({
                            [Xe]: C.value
                        }, y.$set));
                        var O = null == e ? void 0 : e.$unset;
                        O && (y.$unset = O);
                        var F, L, j, B = w ? void 0 : this.mu(null == e ? void 0 : e.$set_once, t !== us, t === hs);
                        if (B && (y.$set_once = B), null != e && e._noTruncate || (h = this.config.properties_string_max_length, u = y, d = (t)=>N(t) ? t.slice(0, h) : t, v = new Set, y = function t(i, e) {
                            if (i !== Object(i)) return d ? d(i) : i;
                            if (!v.has(i)) {
                                var r;
                                if (v.add(i), I(i)) r = [], ds(i, (i)=>{
                                    r.push(t(i));
                                });
                                else {
                                    var s = {};
                                    vs(i, (i, e)=>{
                                        v.has(i) || (s[e] = t(i, e));
                                    }), r = s;
                                }
                                return r;
                            }
                        }(u)), y.timestamp = m, D(null == e ? void 0 : e.timestamp) || (y.properties.$event_time_override_provided = !0, y.properties.$event_time_override_system_time = g), w && (y.properties = function(t, i) {
                            void 0 === i && (i = []);
                            var e = {}, r = (i)=>{
                                void 0 !== t[i] && (e[i] = t[i]);
                            };
                            return de.forEach(r), i.forEach(r), e;
                        }(y.properties, Ul)), t === qo.DISMISSED || t === qo.SENT) {
                            var z = null == i ? void 0 : i[Vo.SURVEY_ID], H = null == i ? void 0 : i[Vo.SURVEY_ITERATION];
                            wl({
                                id: z,
                                current_iteration: H
                            }), y.$set = _({}, y.$set, {
                                [(F = {
                                    id: z,
                                    current_iteration: H
                                }, L = t === qo.SENT ? "responded" : "dismissed", j = "$survey_" + L + "/" + F.id, F.current_iteration && F.current_iteration > 0 && (j = "$survey_" + L + "/" + F.id + "/" + F.current_iteration), j)]: !0
                            });
                        } else t === qo.SHOWN && (y.$set = _({}, y.$set, {
                            [Vo.SURVEY_LAST_SEEN_DATE]: (new Date).toISOString()
                        }));
                        if (t === Ko.SHOWN) {
                            var q = null == i ? void 0 : i[Yo.TOUR_TYPE];
                            q && (y.$set = _({}, y.$set, {
                                [Yo.TOUR_LAST_SEEN_DATE + "/" + q]: (new Date).toISOString()
                            }));
                        }
                        var V = _({}, y.properties.$set, y.$set);
                        if (M(V) || this.setPersonPropertiesForFlags(V), !U(this.config.before_send)) {
                            var W = this.ns(y);
                            if (!W) return;
                            (y = W).uuid = Ei(y.uuid, Ps);
                        }
                        var G = null !== (n = null == (o = y.$set) ? void 0 : o[Xe]) && void 0 !== n ? n : A(null == (a = y.properties) ? void 0 : a.$set) ? y.properties.$set[Xe] : void 0, J = null != C && C.pending && G === C.value ? C.value : void 0;
                        this.Cl.emit("eventCaptured", y);
                        var K = null !== (l = null == e ? void 0 : e._url) && void 0 !== l ? l : this.requestRouter.endpointFor("api", this.analyticsDefaultEndpoint), Y = _({
                            method: "POST",
                            url: K,
                            data: y,
                            compression: "best-available",
                            timestampMode: "recordings" === (null == e ? void 0 : e._batchKey) || /\/s\/(?:\?|$)/.test(K) ? "body" : "capture-body",
                            batchKey: null == e ? void 0 : e._batchKey
                        }, null != e && e.transport ? {
                            transport: e.transport
                        } : {}, J ? {
                            fireCallbackOnDrop: !0,
                            callback: (t)=>{
                                t.statusCode >= 200 && 300 > t.statusCode && this.pu(J);
                            }
                        } : {});
                        return !this.config.request_batching || e && (null == e || !e._batchKey) || null != e && e.send_instantly || J ? this.Jl(Y) : this.Ql.enqueue(Y), y;
                    }
                    Ue.critical("This capture call is ignored due to client rate limiting.");
                }
            } else Ue.error("No event name provided to posthog.capture");
        } else Ue.uninitializedWarning("posthog.capture");
    }
    _addCaptureHook(t) {
        return this.on("eventCaptured", (i)=>t(i.event, i));
    }
    getExtension(t) {
        var i;
        return null == (i = this.lu) ? void 0 : i.getExtension(t);
    }
    nu() {
        var t;
        return null !== (t = this.lu) && void 0 !== t ? t : this.lu = new Cl(this);
    }
    Ml(t) {
        this.Bl.push(t);
        var i = !0;
        return ()=>{
            if (i) {
                i = !1;
                var e = this.Bl.indexOf(t);
                -1 !== e && this.Bl.splice(e, 1);
            }
        };
    }
    yu(t) {
        var i, e, r;
        return void 0 === t && (t = !0), !(null == (i = this.persistence) || !i.consumeCookieIdentityChange()) && (this.Wl = null, this.persistence.get_property(Br) === es && (null == (r = this.sessionPersistence) || r.clear(), this.ql.clear(), this.bu()), null == (e = this.featureFlags) || e.reset(), t && this.reloadFeatureFlags(), !0);
    }
    calculateEventProperties(i, e, n, o, a) {
        if (n = n || new Date, !this.persistence || !this.sessionPersistence) return e;
        this.persistence.syncCookieProperties(), this.yu();
        var l = a ? void 0 : this.persistence.remove_event_timer(i), u = _({}, e);
        if (u.token = this.config.token, u.$config_defaults = this.config.defaults, this.Pl() && (u[Kr] = !0), "$snapshot" === i) {
            var d = _({}, this.persistence.properties(), this.sessionPersistence.properties());
            return u.distinct_id = d.distinct_id, (!N(u.distinct_id) && !B(u.distinct_id) || L(u.distinct_id)) && Ue.error("Invalid distinct_id for replay event. This indicates a bug in your implementation"), u;
        }
        var v, f = function(i, e, r, n) {
            var o, a, l, u;
            if (void 0 === n && (n = !1), !h) return {};
            var d, v = i ? [
                ...ho,
                ...e || []
            ] : [], f = ui(h), p = f[0], _ = f[1], g = null != (d = "u" > typeof navigator ? navigator : void 0) && d.brave ? {
                brave: !0
            } : {}, m = {};
            D(r) || (m.detectGoogleSearchApp = r);
            var b = {}, y = null == (o = navigator) || null == (o = o.userAgentData) ? void 0 : o.platform, w = null == (a = navigator) ? void 0 : a.maxTouchPoints, S = null == t || null == (l = t.screen) ? void 0 : l.width, x = null == t || null == (u = t.screen) ? void 0 : u.height, E = null == t ? void 0 : t.devicePixelRatio;
            D(y) || (b.userAgentDataPlatform = y), D(w) || (b.maxTouchPoints = w), D(S) || (b.screenWidth = S), D(x) || (b.screenHeight = x), D(E) || (b.devicePixelRatio = E);
            var k, T, P, R, C, O, I, F, A = cs(gs({
                $os: p,
                $os_version: _,
                $browser: oi(h, navigator.vendor, g, m),
                $device: di(h),
                $device_type: (T = h, P = b, F = di(T), F === lt || F === at || "Kobo" === F || "Kindle Fire" === F || F === Lt ? ot : F === $t || F === Rt || F === Pt || F === Mt ? "Console" : F === ut ? "Wearable" : F ? rt : "Android" === (null == P ? void 0 : P.userAgentDataPlatform) && (null !== (R = null == P ? void 0 : P.maxTouchPoints) && void 0 !== R ? R : 0) > 0 ? 600 > Math.min(null !== (C = null == P ? void 0 : P.screenWidth) && void 0 !== C ? C : 0, null !== (O = null == P ? void 0 : P.screenHeight) && void 0 !== O ? O : 0) / (null !== (I = null == P ? void 0 : P.devicePixelRatio) && void 0 !== I ? I : 1) ? rt : ot : "Desktop"),
                $timezone: So(),
                $timezone_offset: xo()
            }), {
                $current_url: so(n ? Ti(null == s ? void 0 : s.href) : null == s ? void 0 : s.href, v, vo),
                $host: null == s ? void 0 : s.host,
                $pathname: null == s ? void 0 : s.pathname,
                $raw_user_agent: h.length > 1e3 ? h.substring(0, 997) + "..." : h,
                $browser_version: li(h, navigator.vendor, g, m),
                $browser_language: go(),
                $browser_language_prefix: (k = go(), "string" == typeof k ? k.split("-")[0] : void 0),
                $screen_height: null == t ? void 0 : t.screen.height,
                $screen_width: null == t ? void 0 : t.screen.width,
                $viewport_height: null == t ? void 0 : t.innerHeight,
                $viewport_width: null == t ? void 0 : t.innerWidth,
                $lib: c.LIB_NAME,
                $lib_version: c.LIB_VERSION,
                $insert_id: Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10),
                $time: Date.now() / 1e3
            });
            return c.SDK_DIST_CHANNEL && (A.$sdk_dist_channel = c.SDK_DIST_CHANNEL), A;
        }(this.config.mask_personal_data_properties, this.config.custom_personal_data_properties, this.config.detect_google_search_app, this.config.disable_capture_url_hashes);
        if (this.sessionManager) {
            var p = this.sessionManager.checkAndGetSessionAndWindowId(a, n.getTime(), !0), g = p.windowId;
            u.$session_id = p.sessionId, u.$window_id = g;
        }
        this.sessionPropsManager && cs(u, this.sessionPropsManager.getSessionProps());
        try {
            var m;
            this.sessionRecording && cs(u, this.sessionRecording.sdkDebugProperties), u.$sdk_debug_retry_queue_size = null == (m = this.Kl) ? void 0 : m.length;
        } catch (t) {
            u.$sdk_debug_error_capturing_properties = String(t);
        }
        if (this.requestRouter.region === fl && (u.$lib_custom_api_host = this.config.api_host), v = i !== as || a ? i !== ls || a ? this.pageViewManager.doEvent() : this.pageViewManager.doPageLeave(n) : this.pageViewManager.doPageView(n, o), u = cs(u, v), i === as && r && (u.title = r.title), !D(l)) {
            var b = n.getTime() - l;
            u.$duration = parseFloat((b / 1e3).toFixed(3));
        }
        h && this.config.opt_out_useragent_filter && (u.$browser_type = this._is_bot() ? "bot" : "browser");
        var y = this.persistence.properties(), w = this.sessionPersistence.properties(), S = u.$groups, x = y.$groups;
        A(S) && !M(S) && (u.$groups = _({}, A(x) ? x : {}, S)), vs([
            "$referrer",
            "$referring_domain"
        ], (t)=>{
            t in y && delete w[t];
        });
        var E = {};
        if (this.Bl.length > 0) for (var k of this.Bl.slice())try {
            cs(E, k());
        } catch (t) {
            Ue.error("Failed to produce browser extension event properties", t);
        }
        (u = cs({}, f, y, w, _({}, E, u))).$is_identified = this._isIdentified(), I(this.config.property_denylist) ? vs(this.config.property_denylist, function(t) {
            delete u[t];
        }) : Ue.error(Nl + this.config.property_denylist + " or property_blacklist config: " + this.config.property_blacklist);
        var T = this.config.sanitize_properties;
        T && (Ue.error(Dl), u = T(u, i));
        var P = this._u();
        return u.$process_person_profile = P, P && !a && this.wu("_calculate_event_properties"), u;
    }
    mu(t, i, e) {
        var r;
        if (void 0 === i && (i = !0), void 0 === e && (e = !1), !this.persistence || !this._u()) return t;
        if (this.Nl && !e) return t;
        var s = this.persistence.get_initial_props(), n = null == (r = this.sessionPropsManager) ? void 0 : r.getSetOnceProps(), o = cs({}, s, n || {}, t || {}), a = this.config.sanitize_properties;
        return a && (Ue.error(Dl), o = a(o, "$set_once")), i && (this.Nl = !0), M(o) ? void 0 : o;
    }
    register(t, i) {
        var e;
        null == (e = this.persistence) || e.register(t, i);
    }
    register_once(t, i, e) {
        var r;
        null == (r = this.persistence) || r.register_once(t, i, e);
    }
    register_for_session(t) {
        var i, e;
        null == (i = this.persistence) || i.syncCookieProperties(), this.yu(), null == (e = this.sessionPersistence) || e.register(t), Object.keys(t).forEach((t)=>this.ql.add(t)), this.bu();
    }
    unregister(t) {
        var i;
        null == (i = this.persistence) || i.unregister(t);
    }
    unregister_for_session(t) {
        var i;
        null == (i = this.sessionPersistence) || i.unregister(t), this.ql.delete(t), this.bu();
    }
    ku(t, i) {
        this.register({
            [t]: i
        });
    }
    Yl() {
        this.ql.forEach((t)=>{
            var i;
            null == (i = this.sessionPersistence) || i.unregister(t);
        }), this.ql.clear(), this.bu();
    }
    bu() {
        var t;
        if (this.jl) if ("memory" === this.config.persistence || null != (t = this.sessionPersistence) && t.Ma || !Ks.ii()) Ks.oi(this.jl);
        else {
            var i = [];
            this.ql.forEach((t)=>i.push(t)), i.length > 0 ? Ks.ni(this.jl, i) : Ks.oi(this.jl);
        }
    }
    getFeatureFlag(t, i) {
        var e;
        return null == (e = this.featureFlags) ? void 0 : e.getFeatureFlag(t, i);
    }
    getFeatureFlagPayload(t) {
        var i;
        return null == (i = this.featureFlags) ? void 0 : i.getFeatureFlagPayload(t);
    }
    getFeatureFlagResult(t, i) {
        var e;
        return null == (e = this.featureFlags) ? void 0 : e.getFeatureFlagResult(t, i);
    }
    getAllFeatureFlags() {
        var t, i;
        return null !== (t = null == (i = this.featureFlags) ? void 0 : i.getAllFeatureFlags()) && void 0 !== t ? t : [];
    }
    isFeatureEnabled(t, i) {
        var e, r;
        return null !== (e = null == (r = this.featureFlags) ? void 0 : r.isFeatureEnabled(t, i)) && void 0 !== e ? e : null == i ? void 0 : i.defaultValue;
    }
    reloadFeatureFlags() {
        var t;
        null == (t = this.featureFlags) || t.reloadFeatureFlags();
    }
    updateFlags(t, i, e) {
        var r;
        null == (r = this.featureFlags) || r.updateFlags(t, i, e);
    }
    updateEarlyAccessFeatureEnrollment(t, i, e) {
        var r;
        null == (r = this.featureFlags) || r.updateEarlyAccessFeatureEnrollment(t, i, e);
    }
    getEarlyAccessFeatures(t, i, e) {
        var r;
        return void 0 === i && (i = !1), null == (r = this.featureFlags) ? void 0 : r.getEarlyAccessFeatures(t, i, e);
    }
    on(t, i) {
        return this.Cl.on(t, i);
    }
    onFeatureFlags(t) {
        return this.featureFlags ? this.featureFlags.onFeatureFlags(t) : (t([], {}, {
            errorsLoading: !0
        }), ()=>{});
    }
    onSurveysLoaded(t) {
        return this.surveys ? this.surveys.onSurveysLoaded(t) : (t([], {
            isLoaded: !1,
            error: Ml
        }), ()=>{});
    }
    onSessionId(t) {
        var i, e;
        return null !== (i = null == (e = this.sessionManager) ? void 0 : e.onSessionId(t)) && void 0 !== i ? i : ()=>{};
    }
    getSurveys(t, i) {
        void 0 === i && (i = !1), this.surveys ? this.surveys.getSurveys(t, i) : t([], {
            isLoaded: !1,
            error: Ml
        });
    }
    getActiveMatchingSurveys(t, i) {
        void 0 === i && (i = !1), this.surveys ? this.surveys.getActiveMatchingSurveys(t, i) : t([], {
            isLoaded: !1,
            error: Ml
        });
    }
    renderSurvey(t, i) {
        var e;
        null == (e = this.surveys) || e.renderSurvey(t, i);
    }
    displaySurvey(t, i) {
        var e;
        void 0 === i && (i = xl), null == (e = this.surveys) || e.displaySurvey(t, i);
    }
    cancelPendingSurvey(t) {
        var i;
        null == (i = this.surveys) || i.cancelPendingSurvey(t);
    }
    canRenderSurvey(t) {
        var i, e;
        return null !== (i = null == (e = this.surveys) ? void 0 : e.canRenderSurvey(t)) && void 0 !== i ? i : {
            visible: !1,
            disabledReason: Ml
        };
    }
    canRenderSurveyAsync(t, i) {
        var e, r;
        return void 0 === i && (i = !1), null !== (e = null == (r = this.surveys) ? void 0 : r.canRenderSurveyAsync(t, i)) && void 0 !== e ? e : Promise.resolve({
            visible: !1,
            disabledReason: Ml
        });
    }
    Su(t) {
        return !t || L(t) ? (Ue.critical("Unique user id has not been set in posthog.identify"), !1) : t === Jr ? (Ue.critical('The string "' + t + '" was set in posthog.identify which indicates an error. This ID is only used as a sentinel value.'), !1) : ![
            "distinct_id",
            "distinctid"
        ].includes(t.toLowerCase()) && ![
            "undefined",
            "null"
        ].includes(t.toLowerCase()) || (Ue.critical('The string "' + t + '" was set in posthog.identify which indicates an error. This ID should be unique to the user and not a hardcoded string.'), !1);
    }
    identify(t, i, e) {
        if (!this.__loaded || !this.persistence) return Ue.uninitializedWarning("posthog.identify");
        if (B(t) && (t = t.toString(), Ue.warn("The first argument to posthog.identify was a number, but it should be a string. It has been converted to a string.")), this.Su(t) && this.wu("posthog.identify")) {
            this.Ll();
            var r = this.get_distinct_id(), s = this.persistence.syncCookieProperties() && this.get_distinct_id() !== r, n = this.yu(!1), o = this.persistence.Va(), a = !1;
            try {
                var l = this.get_distinct_id();
                this.register({
                    $user_id: t
                }), this.get_property(Ke) || this.register_once({
                    $had_persisted_distinct_id: !0,
                    $device_id: l
                }, ""), t !== l && t !== this.get_property(Qe) && (this.unregister(Qe), this.register({
                    distinct_id: t
                }));
                var h, u = (this.persistence.get_property(Br) || es) === es, d = t !== l, v = !d && u;
                if (d && u) this.persistence.set_property(Br, rs), this.setPersonPropertiesForFlags({
                    $set: i || {},
                    $set_once: e || {}
                }, !1), this.config.cookieWinsOnConflict && this.persistence.Ga(), this.capture(hs, {
                    distinct_id: t,
                    $anon_distinct_id: l
                }, {
                    $set: i || {},
                    $set_once: e || {}
                }), this.Wl = cl(t, i, e), null == (h = this.featureFlags) || h.setAnonymousDistinctId(l);
                else if (v) {
                    this.persistence.set_property(Br, rs);
                    var c = i || {}, f = e || {};
                    this.setPersonPropertiesForFlags({
                        $set: c,
                        $set_once: f
                    }, !1), this.config.cookieWinsOnConflict && this.persistence.Ga(), this.capture("$set", {
                        $set: c,
                        $set_once: f
                    }), this.Wl = cl(t, i, e);
                } else (i || e) && this.setPersonProperties(i, e);
                d || s || n ? (this.reloadFeatureFlags(), this.featureFlags ? this.featureFlags.resetFlagCallReported() : this.unregister(Nr)) : v && (i || e) && this.reloadFeatureFlags(), a = !0;
            } finally{
                o && this.persistence.Ja(a);
            }
        }
    }
    setPersonProperties(t, i) {
        if ((t || i) && this.wu("posthog.setPersonProperties")) {
            var e = cl(this.get_distinct_id(), t, i);
            this.Wl !== e ? (this.setPersonPropertiesForFlags({
                $set: t || {},
                $set_once: i || {}
            }, !0), this.capture("$set", {
                $set: t || {},
                $set_once: i || {}
            }), this.Wl = e) : Ue.info("A duplicate setPersonProperties call was made with the same properties. It has been ignored.");
        }
    }
    unsetPersonProperties(t) {
        var i, e = (I(t) ? t : [
            t
        ]).filter((t)=>N(t) && t.length > 0);
        0 !== e.length && this.wu("posthog.unsetPersonProperties") && (null == (i = this.featureFlags) || i.unsetPersonPropertiesForFlags(e, !0), this.capture("$set", {
            $unset: e
        }), this.Wl = null);
    }
    group(t, i, e) {
        var r;
        if (t && i) {
            null == (r = this.persistence) || r.syncCookieProperties(), this.yu();
            var s = this.getGroups(), n = s[t] !== i;
            if (n && this.resetGroupPropertiesForFlags(t), this.register({
                $groups: _({}, s, {
                    [t]: i
                })
            }), (n || e) && this._u()) {
                var o = {
                    $group_type: t,
                    $group_key: i
                };
                e && (o.$group_set = e), this.capture(us, o);
            }
            e && this.setGroupPropertiesForFlags({
                [t]: e
            }), n && !e && this.reloadFeatureFlags();
        } else Ue.error("posthog.group requires a group type and group key");
    }
    resetGroups() {
        this.register({
            $groups: {}
        }), this.resetGroupPropertiesForFlags(), this.reloadFeatureFlags();
    }
    setPersonPropertiesForFlags(t, i) {
        var e;
        void 0 === i && (i = !0), null == (e = this.featureFlags) || e.setPersonPropertiesForFlags(t, i);
    }
    resetPersonPropertiesForFlags(t) {
        var i;
        void 0 === t && (t = !0), null == (i = this.featureFlags) || i.resetPersonPropertiesForFlags(t);
    }
    setGroupPropertiesForFlags(t, i) {
        var e;
        void 0 === i && (i = !0), this.wu("posthog.setGroupPropertiesForFlags") && (null == (e = this.featureFlags) || e.setGroupPropertiesForFlags(t, i));
    }
    resetGroupPropertiesForFlags(t) {
        var i;
        null == (i = this.featureFlags) || i.resetGroupPropertiesForFlags(t);
    }
    reset(t) {
        var i = H(t) ? t : null == t ? void 0 : t.resetDeviceID, e = H(t) || null == t ? void 0 : t.bootstrap;
        this.xu(i, !1, e);
    }
    xu(t, i, e) {
        var r, s, n;
        if (void 0 === i && (i = !1), Ue.info("reset"), !this.__loaded) return Ue.uninitializedWarning("posthog.reset");
        var o = null == e ? void 0 : e.sessionID;
        this.config.bootstrap = e || (null == (r = this.Gl) ? void 0 : r.bootstrap) || {}, null == (s = this.featureFlags) || null == s.updateConfig || s.updateConfig(this.config, this.fo());
        var a = this.get_property(Ke), l = this.get_property(Ye), h = this.get_property(dr), u = this.is_capturing();
        this.consent.reset(), i || !u || this.is_capturing() || console.warn("[PostHog.js]", "reset() cleared the stored consent, and capturing is now off because of `opt_out_capturing_by_default`. Call opt_in_capturing() again, and prefer calling reset() before opting in rather than after.");
        var d = null == (n = this.persistence) || null == n.Va ? void 0 : n.Va(), v = !1;
        try {
            var c, f, p, g, m, b, y, w, S, x, E, k, T;
            if (null == (c = this.persistence) || c.clear(), null == (f = this.sessionPersistence) || f.clear(), this.ql.clear(), this.bu(), D(h) || null == (x = this.persistence) || x.register({
                [dr]: h
            }), null == (p = this.surveys) || p.reset(), null == (g = this.featureFlags) || g.reset(), null == (m = this.conversations) || m.reset(), null == (b = this.logs) || b.reset(), null == (y = this.metrics) || y.reset(), null == (w = this.persistence) || w.set_property(Br, es), null == (S = this.sessionManager) || S.resetSessionId(), this.Wl = null, this.config.cookieless_mode === is) this.register_once({
                distinct_id: Jr,
                $device_id: null
            }, "");
            else {
                var P = this.config.get_device_id(Ps());
                this.register_once({
                    distinct_id: P,
                    $device_id: t ? P : a
                }, ""), t || D(l) || this.register({
                    [Ye]: l
                });
            }
            if (this.register({
                $last_posthog_reset: (new Date).toISOString()
            }, 1), e) {
                if (void 0 === e.distinctID || this.Pl() || (null == (T = this.persistence) || T.set_property(Br, e.isIdentifiedID ? rs : es), this.register({
                    distinct_id: e.distinctID
                })), null == (E = this.featureFlags) || E.initialize(), !(D(o) || null != (k = this.sessionManager) && k.setBootstrapSessionId(o, !0))) {
                    var R = _({}, e);
                    delete R.sessionID, this.config.bootstrap = R;
                }
            }
            delete this.config.identity_distinct_id, delete this.config.identity_hash, delete this.config.identity_claims, v = !0;
        } finally{
            var C;
            d && (null == (C = this.persistence) || null == C.Ja || C.Ja(v));
        }
        this.reloadFeatureFlags();
    }
    shutdown(t) {
        var i = this;
        return p(function*() {
            var t, e, r, s, n, o, a;
            if (i.__loaded) {
                i.nu().dispose(), null == (t = i.sessionRecording) || t.dispose(), null == (e = i.logs) || e.flushLogs("sendBeacon"), null == (r = i.metrics) || r.flush("sendBeacon"), null == (s = i.Ql) || s.unload(), null == (n = i.Kl) || n.unload();
                try {
                    var l;
                    null == (l = i.featureFlags) || l.destroy();
                } catch (t) {
                    Ue.error("Error while destroying feature flags", t);
                }
                null == (o = i.persistence) || o.destroy(), null == (a = i.sessionPersistence) || a.destroy();
            } else Ue.uninitializedWarning("posthog.shutdown");
        })();
    }
    setIdentity(t, i) {
        var e;
        delete this.config.identity_claims, this.config.identity_distinct_id = t, this.config.identity_hash = i, this.alias(t), null == (e = this.conversations) || e.Cu();
    }
    clearIdentity() {
        var t;
        delete this.config.identity_distinct_id, delete this.config.identity_hash, delete this.config.identity_claims, null == (t = this.conversations) || t.Tu();
    }
    get_distinct_id() {
        return this.get_property("distinct_id");
    }
    getGroups() {
        return this.get_property("$groups") || {};
    }
    get_session_id() {
        var t, i;
        return null !== (t = null == (i = this.sessionManager) ? void 0 : i.checkAndGetSessionAndWindowId(!0).sessionId) && void 0 !== t ? t : "";
    }
    get_session_replay_url(t) {
        if (!this.sessionManager) return "";
        var i = this.sessionManager.checkAndGetSessionAndWindowId(!0), e = i.sessionStartTimestamp, r = this.requestRouter.endpointFor("ui", "/project/" + this.config.token + "/replay/" + i.sessionId);
        if (null != t && t.withTimestamp && e) {
            var s, n = null !== (s = t.timestampLookBack) && void 0 !== s ? s : 10;
            if (!e) return r;
            r += "?t=" + Math.max(Math.floor(((new Date).getTime() - e) / 1e3) - n, 0);
        }
        return r;
    }
    alias(t, i) {
        return t === this.get_property(Ge) ? (Ue.critical("Attempting to create alias for existing People user - aborting."), -2) : this.wu("posthog.alias") ? (D(i) && (i = this.get_distinct_id()), t !== i ? (this.ku(Qe, t), this.capture("$create_alias", {
            alias: t,
            distinct_id: i
        })) : (Ue.warn("alias matches current distinct_id - skipping api call."), this.identify(t), -1)) : void 0;
    }
    set_config(t) {
        var i = _({}, this.config);
        if (A(t)) {
            var e, r, s, n, o, a, l, h, u, d, v, f;
            cs(this.config, Wl(t));
            var p = this.Dl();
            null == (e = this.persistence) || e.update_config(this.config, i, p), this.sessionPersistence = "sessionStorage" === this.config.persistence || "memory" === this.config.persistence ? this.persistence : new Ao(_({}, this.config, {
                persistence: "sessionStorage"
            }), p, !1);
            var g, m = this.Vl(this.config.debug);
            H(m) && (this.config.debug = m), H(this.config.debug) && (this.config.debug ? (c.DEBUG = !0, Ms.ii() && Ms.ni("ph_debug", !0), Ue.info("set_config", {
                config: t,
                oldConfig: i,
                newConfig: _({}, this.config)
            })) : (c.DEBUG = !1, Ms.ii() && Ms.oi("ph_debug"))), null == (r = this.featureFlags) || null == r.updateConfig || r.updateConfig(this.config, this.fo()), null == (s = this.exceptionObserver) || s.onConfigChange(), null == (n = this.exceptions) || n.onConfigChange(), null == (o = this.sessionRecording) || o.startIfEnabledOrStop(), null == (a = this.tracingHeaders) || a.startIfEnabledOrStop(), null == (l = this.autocapture) || l.startIfEnabled(), null == (h = this.heatmaps) || h.startIfEnabled(), ("capture_pageview" in t || "disable_capture_url_hashes" in t) && (null == (g = this.historyAutocapture) || g.startIfEnabledOrStop()), null == (u = this.exceptionObserver) || u.startIfEnabledOrStop(), null == (d = this.deadClicksAutocapture) || d.startIfEnabledOrStop(), null == (v = this.surveys) || v.loadIfEnabled(), this.$l(), null == (f = this.externalIntegrations) || f.startIfEnabledOrStop(), !i.segment && this.config.segment && this.persistence && Wn(this, Fl, !1);
        }
    }
    _overrideSDKInfo(t, i) {
        c.LIB_NAME = t, c.LIB_VERSION = i;
    }
    startSessionRecording(t) {
        var i, e, r, s, n, o = !0 === t, a = {
            sampling: o || !(null == t || !t.sampling),
            linked_flag: o || !(null == t || !t.linked_flag),
            url_trigger: o || !(null == t || !t.url_trigger),
            event_trigger: o || !(null == t || !t.event_trigger)
        };
        Object.values(a).some(Boolean) && (null == (i = this.sessionManager) || i.checkAndGetSessionAndWindowId(), a.sampling && (null == (e = this.sessionRecording) || e.overrideSampling()), a.linked_flag && (null == (r = this.sessionRecording) || r.overrideLinkedFlag()), a.url_trigger && (null == (s = this.sessionRecording) || s.overrideTrigger("url")), a.event_trigger && (null == (n = this.sessionRecording) || n.overrideTrigger("event")));
        this.set_config({
            disable_session_recording: !1
        });
    }
    stopSessionRecording() {
        this.set_config({
            disable_session_recording: !0
        });
    }
    sessionRecordingStarted() {
        var t;
        return !(null == (t = this.sessionRecording) || !t.started);
    }
    captureException(t, i) {
        if (this.exceptions) {
            var e = new Error("PostHog syntheticException"), r = this.exceptions.buildProperties(t, {
                handled: !0,
                syntheticException: e
            });
            return this.exceptions.sendExceptionEvent(_({}, r, i));
        }
    }
    addExceptionStep(t, i) {
        var e;
        null == (e = this.exceptions) || e.addExceptionStep(t, i);
    }
    captureLog(t) {
        var i;
        null == (i = this.logs) || i.captureLog(t);
    }
    get logger() {
        var t, i;
        return null !== (t = null == (i = this.logs) ? void 0 : i.logger) && void 0 !== t ? t : Jl.Mu;
    }
    startExceptionAutocapture(t) {
        this.set_config({
            capture_exceptions: null == t || t
        });
    }
    stopExceptionAutocapture() {
        this.set_config({
            capture_exceptions: !1
        });
    }
    loadToolbar(t) {
        var i, e;
        return null !== (i = null == (e = this.toolbar) ? void 0 : e.loadToolbar(t)) && void 0 !== i && i;
    }
    get_property(t) {
        var i;
        return null == (i = this.persistence) ? void 0 : i.props[t];
    }
    getSessionProperty(t) {
        var i;
        return null == (i = this.sessionPersistence) ? void 0 : i.props[t];
    }
    toString() {
        var t, i = null !== (t = this.config.name) && void 0 !== t ? t : Bl;
        return i !== Bl && (i = Bl + "." + i), i;
    }
    _isIdentified() {
        var t, i;
        return (null == (t = this.persistence) ? void 0 : t.get_property(Br)) === rs || (null == (i = this.sessionPersistence) ? void 0 : i.get_property(Br)) === rs;
    }
    _u() {
        var t, i;
        return !("never" === this.config.person_profiles || this.config.person_profiles === ss && !this._isIdentified() && M(this.getGroups()) && (null == (t = this.persistence) || null == (t = t.props) || !t[Qe]) && (null == (i = this.persistence) || null == (i = i.props) || !i[Gr]));
    }
    vu() {
        return !0 === this.config.capture_pageleave || "if_capture_pageview" === this.config.capture_pageleave && !!this.config.capture_pageview;
    }
    createPersonProfile() {
        this._u() || this.wu("posthog.createPersonProfile") && this.setPersonProperties({}, {});
    }
    setInternalOrTestUser() {
        this.wu("posthog.setInternalOrTestUser") && this.setPersonProperties({
            $internal_or_test_user: !0
        });
    }
    wu(t) {
        return "never" === this.config.person_profiles ? (Ue.error(t + ' was called, but process_person is set to "never". This call will be ignored.'), !1) : (this.Al(), this.ku(Gr, !0), !0);
    }
    Dl() {
        if ("always" === this.config.cookieless_mode) return !0;
        var t = this.consent.isOptedOut();
        return this.config.disable_persistence || t && !(!this.config.opt_out_persistence_by_default && this.config.cookieless_mode !== ts);
    }
    $l() {
        var t, i, e, r, s, n = this.Dl();
        return this.is_capturing() || null == (e = this.logs) || e.Iu(), (null == (t = this.persistence) ? void 0 : t.Ma) !== n && (null == (r = this.persistence) || r.set_disabled(n)), (null == (i = this.sessionPersistence) ? void 0 : i.Ma) !== n && (null == (s = this.sessionPersistence) || s.set_disabled(n)), n && (this.ql.clear(), this.bu()), n;
    }
    opt_in_capturing(t) {
        var i;
        if (this.config.cookieless_mode !== is) {
            if (this.Pl()) {
                var e, r, s, n, o, a;
                null == (e = this.sessionRecording) || e.dispose({
                    discardBufferedEvents: !0
                }), this.xu(!0, !0), null == (r = this.sessionManager) || r.destroy(), null == (s = this.pageViewManager) || s.destroy(), this.sessionManager = new nl(this), this.pageViewManager = new Yn(this), this.persistence && (this.sessionPropsManager = new il(this, this.sessionManager, this.persistence));
                var l, h = null !== (n = null == (o = this.config.__extensionClasses) ? void 0 : o.sessionRecording) && void 0 !== n ? n : null == (a = Jl.__defaultExtensionClasses) ? void 0 : a.sessionRecording;
                h && (this.sessionRecording = this.Rl(this.sessionRecording, new h(this)), this.xl && (null == (l = this.sessionRecording) || null == l.onRemoteConfig || l.onRemoteConfig(this.xl)));
            }
            var u, d;
            this.consent.optInOut(!0), this.$l(), this.uu(), null == (i = this.sessionRecording) || i.startIfEnabledOrStop(), this.config.cookieless_mode == ts && (null == (u = this.surveys) || u.loadIfEnabled()), (D(null == t ? void 0 : t.captureEventName) || null != t && t.captureEventName) && this.capture(null !== (d = null == t ? void 0 : t.captureEventName) && void 0 !== d ? d : "$opt_in", null == t ? void 0 : t.captureProperties, {
                send_instantly: !0
            }), this.config.capture_pageview && this.hu();
        } else Ue.warn(Al);
    }
    opt_out_capturing() {
        if (this.config.cookieless_mode !== is) {
            var t, i, e = this.config.cookieless_mode === ts ? this.sessionRecording : void 0;
            null == e || e.dispose({
                discardBufferedEvents: !0
            }), this.config.cookieless_mode === ts && this.consent.isOptedIn() && this.xu(!0, !0), this.consent.optInOut(!1), this.$l(), this.config.cookieless_mode === ts && (this.register({
                distinct_id: Jr,
                $device_id: null
            }), this.El(e), this.sessionRecording = void 0, null == (t = this.sessionManager) || t.destroy(), null == (i = this.pageViewManager) || i.destroy(), this.sessionManager = void 0, this.sessionPropsManager = void 0, this.config.capture_pageview && this.hu(), this.uu());
        } else Ue.warn(Al);
    }
    has_opted_in_capturing() {
        return this.consent.isOptedIn();
    }
    has_opted_out_capturing() {
        return this.consent.isOptedOut();
    }
    get_explicit_consent_status() {
        var t = this.consent.consent;
        return 1 === t ? "granted" : 0 === t ? "denied" : "pending";
    }
    is_capturing() {
        return this.config.cookieless_mode === is || (this.config.cookieless_mode === ts ? this.consent.isRejected() || this.consent.isOptedIn() : !this.has_opted_out_capturing());
    }
    clear_opt_in_out_capturing() {
        this.consent.reset(), this.$l();
    }
    _is_bot() {
        return e ? ol(e, this.config.custom_blocked_useragents) : void 0;
    }
    hu() {
        r && ("visible" === r.visibilityState ? this.Hl || (this.Hl = !0, this.capture(as, {
            title: r.title
        }, {
            send_instantly: !0
        }), this.zl && (r.removeEventListener(ns, this.zl), this.zl = null)) : this.zl || (this.zl = this.hu.bind(this), ys(r, ns, this.zl)));
    }
    debug(i) {
        !1 === i ? (null == t || t.console.log("You've disabled debug mode."), this.set_config({
            debug: !1
        })) : (null == t || t.console.log("You're now in debug mode. All calls to PostHog will be logged in your console.\nYou can disable this with `posthog.debug(false)`."), this.set_config({
            debug: !0
        }));
    }
    fo() {
        var t = this.Gl || {};
        return "advanced_disable_flags" in t ? !!t.advanced_disable_flags : !1 !== this.config.advanced_disable_flags ? !!this.config.advanced_disable_flags : !0 === this.config.advanced_disable_decide ? (Ue.warn("Config field 'advanced_disable_decide' is deprecated. Please use 'advanced_disable_flags' instead. The old field will be removed in a future major version."), !0) : function(t, i, e, r, s) {
            var n = i in t && !U(t[i]), o = e in t && !U(t[e]);
            return n ? t[i] : !!o && (s && s.warn("Config field '" + e + "' is deprecated. Please use '" + i + "' instead. The old field will be removed in a future major version."), t[e]);
        }(t, "advanced_disable_flags", "advanced_disable_decide", 0, Ue);
    }
    ns(t) {
        var i;
        if (U(this.config.before_send)) return t;
        var e = Object.keys(null !== (i = t.properties) && void 0 !== i ? i : {}).filter(W), r = I(this.config.before_send) ? this.config.before_send : [
            this.config.before_send
        ], s = t;
        for (var n of r)try {
            if (s = n(s), U(s)) {
                var o = "Event '" + t.event + "' was rejected in beforeSend function";
                return V(t.event) ? Ue.warn(o + ". This can cause unexpected behavior.") : Ue.info(o), null;
            }
            s.properties && !M(s.properties) || Ue.warn("Event '" + t.event + "' has no properties after beforeSend function, this is likely an error.");
        } catch (i) {
            return Ue.error("Error in beforeSend function for event '" + t.event + "':", i), null;
        }
        for (var a of e)if (s.properties && U(s.properties[a])) return Ue.warn("Event '" + t.event + "' had its '" + a + "' property removed in a beforeSend function. This property is required for ingestion, so the event will be dropped."), null;
        return s;
    }
    getPageViewId() {
        var t;
        return null == (t = this.pageViewManager.ea) ? void 0 : t.pageViewId;
    }
    captureTraceFeedback(t, i) {
        this.capture("$ai_feedback", {
            $ai_trace_id: String(t),
            $ai_feedback_text: i
        });
    }
    captureTraceMetric(t, i, e) {
        this.capture("$ai_metric", {
            $ai_trace_id: String(t),
            $ai_metric_name: i,
            $ai_metric_value: String(e)
        });
    }
    Vl(t) {
        var i = H(t) && !t, e = Ms.ii() && "true" === Ms.ai("ph_debug");
        return !i && (!!e || t);
    }
}
Jl.__defaultExtensionClasses = {}, Jl.Mu = (()=>{
    var t = ()=>{};
    return {
        trace: t,
        debug: t,
        info: t,
        warn: t,
        error: t,
        fatal: t
    };
})(), function(t, i) {
    for(var e = 0; i.length > e; e++)t.prototype[i[e]] = _s(t.prototype[i[e]]);
}(Jl, [
    "identify"
]);
class Kl {
    constructor(t){
        this.disabled = !1 === t;
        var i = A(t) ? t : {};
        this.thresholdPx = i.threshold_px || 30, this.timeoutMs = i.timeout_ms || 1e3, this.clickCount = i.click_count || 3, this.clicks = [];
    }
    isRageClick(t, i, e) {
        if (this.disabled) return !1;
        var r = this.clicks[this.clicks.length - 1];
        if (r && Math.abs(t - r.x) + Math.abs(i - r.y) < this.thresholdPx && this.timeoutMs > e - r.timestamp) {
            if (this.clicks.push({
                x: t,
                y: i,
                timestamp: e
            }), this.clicks.length === this.clickCount) return !0;
        } else this.clicks = [
            {
                x: t,
                y: i,
                timestamp: e
            }
        ];
        return !1;
    }
}
var Yl = "$copy_autocapture", Ql = Be("[AutoCapture]");
function Xl(t, i) {
    return i.length > t ? i.slice(0, t) + "..." : i;
}
function Zl(t) {
    if (t.previousElementSibling) return t.previousElementSibling;
    var i = t;
    do {
        i = i.previousSibling;
    }while (i && !sn(i))
    return i;
}
function th(i, e) {
    var r, s, n = e.e, o = e.maskAllElementAttributes, a = e.maskAllText, l = e.elementAttributeIgnoreList, h = e.elementsChainAsString, u = e.disableCaptureUrlHashes;
    if (!sn(i)) return {
        props: {}
    };
    for(var d = [
        i
    ], v = new Set([
        i
    ]), c = i; c.parentNode && !nn(c, "body") && ln > d.length;)if (an(c.parentNode)) {
        var f = c.parentNode.host;
        if (v.has(f)) break;
        v.add(f), d.push(f), c = f;
    } else {
        if (!sn(c.parentNode)) break;
        if (v.has(c.parentNode)) break;
        v.add(c.parentNode), d.push(c.parentNode), c = c.parentNode;
    }
    var p, g, m = [], b = {}, w = !1, S = !1;
    if (vs(d, (t)=>{
        var i = $n(t);
        if (nn(t, "a")) {
            var e = t.getAttribute("href");
            w = !!(i && e && Dn(e)) && (u ? Ti(e) : e);
        }
        y(dn(t), "ph-no-capture") && (S = !0), m.push(function(t, i, e, r, s) {
            void 0 === s && (s = !1);
            var n = t.tagName.toLowerCase(), o = {
                tag_name: n
            };
            pn.indexOf(n) > -1 && !e && (o.$el_text = "a" === n.toLowerCase() || "button" === n.toLowerCase() ? Xl(1024, Nn(t)) : Xl(1024, cn(t)));
            var a = dn(t);
            a.length > 0 && (o.classes = a.filter(function(t) {
                return "" !== t;
            })), vs(t.attributes, function(e) {
                var n;
                if ((!Pn(t) || -1 !== [
                    "name",
                    "id",
                    "class",
                    "aria-label"
                ].indexOf(e.name)) && (null == r || !r.includes(e.name)) && !i && Dn(e.value) && (!N(n = e.name) || "_ngcontent" !== n.substring(0, 10) && "_nghost" !== n.substring(0, 7))) {
                    var a = e.value;
                    "class" === e.name && (a = hn(a).join(" ")), o["attr__" + e.name] = Xl(1024, "href" === e.name && s ? Ti(a) : a);
                }
            });
            for(var l = 1, h = 1, u = t; u = Zl(u);)l++, u.tagName === t.tagName && h++;
            return o.nth_child = l, o.nth_of_type = h, o;
        }(t, o, a, l, u));
        var r = function(t) {
            if (!$n(t)) return {};
            var i = {};
            return vs(t.attributes, function(t) {
                if (t.name && 0 === t.name.indexOf("data-ph-capture-attribute")) {
                    var e = t.name.replace("data-ph-capture-attribute-", ""), r = t.value;
                    e && r && Dn(r) && (i[e] = r);
                }
            }), i;
        }(t);
        vs(r, (t, i)=>{
            ({}).hasOwnProperty.call(b, i) || (b[i] = t);
        });
    }), S) return {
        props: {},
        explicitNoCapture: S
    };
    if (a || (m[0].$el_text = nn(i, "a") || nn(i, "button") ? Nn(i) : cn(i)), w) {
        var x, E;
        m[0].attr__href = w;
        var k = null == (x = eo(w)) ? void 0 : x.host, T = null == t || null == (E = t.location) ? void 0 : E.host;
        k && T && k !== T && (p = w);
    }
    return {
        props: cs({
            $event_type: n.type,
            $ce_version: 1
        }, h ? {} : {
            $elements: m
        }, {
            $elements_chain: (g = m, I(g) ? function(t) {
                return t.map((t)=>{
                    var i, e, r = "";
                    if (t.tag_name && (r += t.tag_name), t.attr_class) for (var s of (t.attr_class.sort(), t.attr_class))r += "." + s.replace(/"/g, "");
                    var n = _({}, t.text ? {
                        text: t.text
                    } : {}, {
                        "nth-child": null !== (i = t.nth_child) && void 0 !== i ? i : 0,
                        "nth-of-type": null !== (e = t.nth_of_type) && void 0 !== e ? e : 0
                    }, t.href ? {
                        href: t.href
                    } : {}, t.attr_id ? {
                        attr_id: t.attr_id
                    } : {}, t.attributes), o = {};
                    return fs(n).sort((t, i)=>{
                        return (r = i[0]) > (e = t[0]) ? -1 : e > r ? 1 : 0;
                        //TURBOPACK unreachable
                        ;
                        var e, r;
                    }).forEach((t)=>{
                        var i = t[1];
                        return o[jn(t[0].toString())] = jn(i.toString());
                    }), (r += ":") + fs(o).map((t)=>t[0] + '="' + t[1] + '"').join("");
                }).join(";");
            }(function(t) {
                return t.map((t)=>{
                    var i, e, r = {
                        text: null == (i = t.$el_text) ? void 0 : i.slice(0, 400),
                        tag_name: t.tag_name,
                        href: null == (e = t.attr__href) ? void 0 : e.slice(0, 2048),
                        attr_class: Un(t),
                        attr_id: t.attr__id,
                        nth_child: t.nth_child,
                        nth_of_type: t.nth_of_type,
                        attributes: {}
                    };
                    return fs(t).filter((t)=>0 === t[0].indexOf("attr__")).forEach((t)=>r.attributes[t[0]] = t[1]), r;
                });
            }(g)) : "")
        }, null != (r = m[0]) && r.$el_text ? {
            $el_text: null == (s = m[0]) ? void 0 : s.$el_text
        } : {}, p && "click" === n.type ? {
            $external_click_url: p
        } : {}, b)
    };
}
class ih {
    constructor(t){
        this.name = "autocapture", this.Rs = !1, this.Ps = null, this.As = !1, this.Fs = !1, this.mn = {
            enabled: !1,
            rageclick: !1,
            maskAllElementAttributes: !1,
            maskAllText: !1,
            disableCaptureUrlHashes: !1,
            remoteRequestsDisabled: !1
        }, this.Os = !1, this.Ls = t, this.Ls.refresh(this.mn), this.rageclicks = new Kl(this.mn.rageclick), this.Ds = null;
    }
    setup(t) {
        this.$s(), this.Ns = t;
        var i = t.onRemoteConfig(this.onRemoteConfig.bind(this));
        this.Os ? i.dispose() : (this.qs = i, this.startIfEnabled());
    }
    dispose() {
        var t;
        this.Os || (this.Os = !0, this.Ns = void 0, null == (t = this.qs) || t.dispose(), this.qs = void 0, this.js());
    }
    Bs() {
        return this.Ls.refresh(this.mn), this.mn;
    }
    $s() {
        var t, i;
        return this.Bs(), this.mn.url_allowlist = null == (t = this.mn.url_allowlist) ? void 0 : t.map((t)=>new RegExp(t)), this.mn.url_ignorelist = null == (i = this.mn.url_ignorelist) ? void 0 : i.map((t)=>new RegExp(t)), this.mn;
    }
    Hs() {
        if (this.isBrowserSupported()) {
            if (t && r) {
                var i = this.zs = (i)=>{
                    i = i || (null == t ? void 0 : t.event);
                    try {
                        this.Us(i);
                    } catch (t) {
                        Ql.error("Failed to capture event", t);
                    }
                };
                if (ys(r, "submit", i, {
                    capture: !0
                }), ys(r, "change", i, {
                    capture: !0
                }), ys(r, "click", i, {
                    capture: !0
                }), this.Bs().capture_copied_text) {
                    var e = this.Ws = (i)=>{
                        i = i || (null == t ? void 0 : t.event);
                        try {
                            this.Us(i, Yl);
                        } catch (t) {
                            Ql.error("Failed to capture clipboard event", t);
                        }
                    };
                    ys(r, "copy", e, {
                        capture: !0
                    }), ys(r, "cut", e, {
                        capture: !0
                    }), ys(r, "paste", e, {
                        capture: !0
                    });
                }
            }
        } else Ql.info("Disabling Automatic Event Collection because this browser is not supported");
    }
    js() {
        this.zs && (null == r || r.removeEventListener("submit", this.zs, !0), null == r || r.removeEventListener("change", this.zs, !0), null == r || r.removeEventListener("click", this.zs, !0), this.zs = void 0), this.Ws && (null == r || r.removeEventListener("copy", this.Ws, !0), null == r || r.removeEventListener("cut", this.Ws, !0), null == r || r.removeEventListener("paste", this.Ws, !0), this.Ws = void 0), this.Rs = !1;
    }
    startIfEnabled() {
        !this.Os && this.Ns && this.isEnabled && !this.Rs && (this.Hs(), this.Rs = !0);
    }
    onRemoteConfig(t) {
        if (!this.Os) if (this.As = !0, t.ok) {
            var i = t.config;
            i.elementsChainAsString && (this.Fs = i.elementsChainAsString);
            var e, r = i.autocapture_opt_out;
            H(r) && (null == (e = this.Ns) || e.kv.set(ir, r), this.Ps = r), this.startIfEnabled();
        } else this.startIfEnabled();
    }
    setElementSelectors(t) {
        this.Ds = t;
    }
    getElementSelectors(t) {
        var i, e = [];
        return null == (i = this.Ds) || i.forEach((i)=>{
            var s = null == r ? void 0 : r.querySelectorAll(i);
            null == s || s.forEach((r)=>{
                t === r && e.push(i);
            });
        }), e;
    }
    get isEnabled() {
        var t, i;
        if (this.Os) return !1;
        var e = null == (t = this.Ns) ? void 0 : t.kv.get(ir), r = this.Ps, s = this.Bs(), n = s.remoteRequestsDisabled && !this.As;
        if (j(r) && !H(e) && !n) return !1;
        var o = null !== (i = this.Ps) && void 0 !== i ? i : !!e;
        return !!s.enabled && !o;
    }
    Us(i, e) {
        if (void 0 === e && (e = "$autocapture"), this.isEnabled) {
            var r = fn(i);
            on(r) && (r = r.parentNode || null);
            var s, n = this.$s();
            "$autocapture" === e && "click" === i.type && i instanceof MouseEvent && n.rageclick && null != (s = this.rageclicks) && s.isRageClick(i.clientX, i.clientY, i.timeStamp || (new Date).getTime()) && En(r, n.rageclick) && this.Us(i, "$rageclick");
            var o = e === Yl, a = o ? _({}, n, {
                dom_event_allowlist: void 0
            }) : n;
            if (r && function(i, e, r, s, n, o) {
                var a;
                if (!t || kn(i)) return !1;
                if (null != r && r.url_allowlist && !un(r.url_allowlist, o)) return !1;
                if (null != r && r.url_ignorelist && un(r.url_ignorelist, o)) return !1;
                if (null != r && r.dom_event_allowlist) {
                    var l = r.dom_event_allowlist;
                    if (l && !l.some((t)=>e.type === t)) return !1;
                }
                var h = Tn(i, s), u = h.parentIsUsefulElement, d = h.targetElementList;
                if (!function(t, i) {
                    var e = null == i ? void 0 : i.element_allowlist;
                    if (D(e)) return !0;
                    var r, s = function(t) {
                        if (e.some((i)=>t.tagName.toLowerCase() === i)) return {
                            v: !0
                        };
                    };
                    for (var n of t)if (r = s(n)) return r.v;
                    return !1;
                }(d, r)) return !1;
                if (!_n(d, null == r ? void 0 : r.css_selector_allowlist)) return !1;
                if (_n(d, null !== (a = null == r ? void 0 : r.css_selector_ignorelist) && void 0 !== a ? a : mn)) return !1;
                try {
                    var v = t.getComputedStyle(i);
                    if (v && "pointer" === v.getPropertyValue("cursor") && "click" === e.type) return !0;
                } catch (t) {}
                var c = i.tagName.toLowerCase();
                switch(c){
                    case "html":
                        return !1;
                    case "form":
                        return (n || [
                            "submit"
                        ]).indexOf(e.type) >= 0;
                    case "input":
                    case "select":
                    case "textarea":
                        return (n || [
                            "change",
                            "click"
                        ]).indexOf(e.type) >= 0;
                    default:
                        return u ? (n || [
                            "click"
                        ]).indexOf(e.type) >= 0 : (n || [
                            "click"
                        ]).indexOf(e.type) >= 0 && (pn.indexOf(c) > -1 || "true" === i.getAttribute("contenteditable"));
                }
            }(r, i, a, o, o ? [
                "copy",
                "cut",
                "paste"
            ] : void 0, {
                config: {
                    get_current_url: n.getCurrentUrl
                }
            })) {
                var l, h = th(r, {
                    e: i,
                    maskAllElementAttributes: n.maskAllElementAttributes,
                    maskAllText: n.maskAllText,
                    elementAttributeIgnoreList: n.element_attribute_ignorelist,
                    elementsChainAsString: this.Fs,
                    disableCaptureUrlHashes: n.disableCaptureUrlHashes
                }), u = h.props;
                if (h.explicitNoCapture) return !1;
                var d = this.getElementSelectors(r);
                if (d && d.length > 0 && (u.$element_selectors = d), e === Yl) {
                    var v = i.type || "clipboard";
                    if ("paste" !== v) {
                        var c, f, p = null == t || null == (c = t.getSelection()) ? void 0 : c.toString(), g = vn(p);
                        if (!g) return !1;
                        u.$selected_content = g, u.$clipboard_text_length = null !== (f = null == p ? void 0 : p.length) && void 0 !== f ? f : 0;
                    }
                    u.$copy_type = v;
                }
                return null == (l = this.Ns) || l.capture(e, u).catch((t)=>Ql.error("Failed to capture event", t)), !0;
            }
        }
    }
    isBrowserSupported() {
        return F(null == r ? void 0 : r.querySelectorAll);
    }
}
class eh {
    constructor(t){
        this._instance = t;
    }
    refresh(t) {
        var i = this._instance.config, e = A(i.autocapture) ? i.autocapture : void 0;
        t.enabled = !!i.autocapture, t.rageclick = i.rageclick, t.maskAllElementAttributes = i.mask_all_element_attributes, t.maskAllText = i.mask_all_text, t.disableCaptureUrlHashes = i.disable_capture_url_hashes, t.getCurrentUrl = i.get_current_url, t.remoteRequestsDisabled = this._instance.fo(), t.url_allowlist = null == e ? void 0 : e.url_allowlist, t.url_ignorelist = null == e ? void 0 : e.url_ignorelist, t.dom_event_allowlist = null == e ? void 0 : e.dom_event_allowlist, t.element_allowlist = null == e ? void 0 : e.element_allowlist, t.css_selector_allowlist = null == e ? void 0 : e.css_selector_allowlist, t.css_selector_ignorelist = null == e ? void 0 : e.css_selector_ignorelist, t.element_attribute_ignorelist = null == e ? void 0 : e.element_attribute_ignorelist, t.capture_copied_text = null == e ? void 0 : e.capture_copied_text;
    }
}
var rh = Be("[ExceptionAutocapture]"), sh = ()=>{}, nh = (t)=>{
    var i;
    if (F(t)) return null !== (i = t.__posthog_layer__) && void 0 !== i ? i : t.__rrweb_layer__;
};
function oh(t, i, e) {
    try {
        if (!(i in t)) return sh;
        var r = {
            next: t[i]
        }, s = e(function() {
            for(var t = arguments.length, i = new Array(t), e = 0; t > e; e++)i[e] = arguments[e];
            return r.next.apply(this, i);
        });
        return F(s) && (s.prototype = s.prototype || {}, Object.defineProperties(s, {
            __posthog_wrapped__: {
                enumerable: !1,
                value: !0
            },
            __posthog_layer__: {
                enumerable: !1,
                value: r
            }
        })), t[i] = s, ()=>{
            if (t[i] !== s) for(var e = t[i], n = nh(e); n;){
                if (n.next === s) return void (n.next = r.next);
                n = nh(e = n.next);
            }
            else t[i] = r.next;
        };
    } catch (t) {
        return sh;
    }
}
var ah = Be("[TracingHeaders]"), lh = Be("[Web Vitals]"), hh = 9e5, uh = [
    "CLS",
    "FCP",
    "INP",
    "LCP"
], dh = [
    "INP",
    "LCP"
], vh = [
    "interactionTarget",
    "interactionType",
    "inputDelay",
    "processingDuration",
    "presentationDelay",
    "loadState",
    "target",
    "url",
    "timeToFirstByte",
    "resourceLoadDelay",
    "resourceLoadDuration",
    "elementRenderDelay",
    "largestShiftTarget",
    "largestShiftTime",
    "largestShiftValue",
    "firstByteToFCP"
], ch = "disabled", fh = "lazy_loading", ph = "awaiting_config", _h = "missing_config";
Be("[SessionRecording]"), Be("[SessionRecording]");
var gh = "[SessionRecording]", mh = Be(gh), bh = Be("[Heatmaps]");
function yh(t) {
    return A(t) && "clientX" in t && "clientY" in t && B(t.clientX) && B(t.clientY);
}
var wh = Be("[Product Tours]"), Sh = (t)=>{
    var i;
    return !t.config.disable_product_tours && !(null == (i = t.persistence) || !i.get_property(lr));
}, xh = [
    "$set_once",
    "$set"
], Eh = Be("[SiteApps]"), kh = "Error while initializing PostHog app with config id ", Th = (t, i)=>null != t && t.then ? t.then(i) : i(t), $h = "SDK is not enabled or survey functionality is not yet loaded", Ph = "Disabled. Not loading surveys.";
class Rh {
    constructor(t, i){
        this.name = "surveys", this._surveyEventReceiver = null, this._surveyManager = null, this.Eu = !1, this.Ru = [], this.Pu = null, this.Au = null, this.Os = !1, this.Fu = new Set, this.onRemoteConfig = (t)=>{
            if (!this.Os && !this.mn.disableSurveys) {
                if (!t.ok) return bl.warn("Remote config unavailable. Not loading surveys.");
                var i = t.config.surveys;
                if (U(i)) return bl.warn("Flags not loaded yet. Not loading surveys.");
                this.Ou = H(i) ? i : i.length > 0, bl.info("flags response received, isSurveysEnabled: " + this.Ou), this.loadIfEnabled();
            }
        }, this.Ls = t, this.Lu = i;
    }
    setup(t) {
        if (!this.Os) return this.Du = t, Th(t.kv.initialize(), ()=>{
            if (this.Du === t && !this.Os) {
                this.Du = void 0, this.Ns = t;
                var i = t.onRemoteConfig(this.onRemoteConfig);
                this.Os ? i.dispose() : (this.qs = i, this.loadIfEnabled());
            }
        });
    }
    dispose() {
        var t, i, e;
        this.Os || (this.Os = !0, this.Du = void 0, this.Ns = void 0, null == (t = this.qs) || t.dispose(), this.qs = void 0, null == (i = this._surveyEventReceiver) || i.dispose(), this._surveyEventReceiver = null, null == (e = this._surveyManager) || null == e.dispose || e.dispose(), this._surveyManager = null, this.Ru = [], this.Pu = null, this.Fu.forEach((t)=>clearTimeout(t)), this.Fu.clear());
    }
    get mn() {
        return this.Ls.get();
    }
    initialize() {
        this.loadIfEnabled();
    }
    reset() {
        try {
            var t;
            null == (t = this._surveyEventReceiver) || t.reset(), localStorage.removeItem("lastSeenSurveyDate");
            for(var i = [], e = 0; e < localStorage.length; e++){
                var r = localStorage.key(e);
                (null != r && r.startsWith(yl) || null != r && r.startsWith("inProgressSurvey_")) && i.push(r);
            }
            i.forEach((t)=>localStorage.removeItem(t));
        } catch (t) {}
    }
    loadIfEnabled() {
        if (!this.Os && this.Ns) {
            var t = this.mn;
            if (!this._surveyManager) if (this.Eu) bl.info("Already initializing surveys, skipping...");
            else if (t.disableSurveys) bl.info(Ph);
            else if (t.cookielessMode && this.Ls.isOptedOut()) bl.info("Not loading surveys in cookieless mode without consent.");
            else {
                var i = this.Ls.getExtensions();
                if (i) {
                    if (!D(this.Ou) || t.advancedEnableSurveys) {
                        var e = this.Ou || t.advancedEnableSurveys;
                        this.Eu = !0;
                        try {
                            var r = i.generateSurveys;
                            if (r) return this.$u(r, e), void (this.Eu = !1);
                            var s = i.loadExternalDependency;
                            if (!s) return this.Nu(Zr), void (this.Eu = !1);
                            s((t)=>{
                                try {
                                    if (this.Os) return;
                                    var i = this.Ls.getExtensions();
                                    t || null == i || !i.generateSurveys ? this.Nu("Could not load surveys script", t) : this.$u(i.generateSurveys, e);
                                } finally{
                                    this.Eu = !1;
                                }
                            });
                        } catch (t) {
                            throw this.Eu = !1, this.Nu("Error initializing surveys", t), t;
                        }
                    }
                } else bl.error("PostHog Extensions not found.");
            }
        }
    }
    $u(t, i) {
        this.Os || (this._surveyManager = t(i), this._surveyEventReceiver = this.Ls.createEventReceiver(), bl.info("Surveys loaded successfully"), this.qu({
            isLoaded: !0
        }));
    }
    Nu(t, i) {
        bl.error(t, i), this.qu({
            isLoaded: !1,
            error: t
        });
    }
    onSurveysLoaded(t) {
        return this.Ru.push(t), this._surveyManager && this.qu({
            isLoaded: !0
        }), ()=>{
            this.Ru = this.Ru.filter((i)=>i !== t);
        };
    }
    getSurveys(t, i) {
        var e;
        void 0 === i && (i = !1);
        var r = null !== (e = this.Ns) && void 0 !== e ? e : this.Lu;
        if (r && !this.Os) {
            if (this.mn.disableSurveys) return bl.info(Ph), t([]);
            var s = r.kv.get(Or);
            if (s && !i) return t(s, {
                isLoaded: !0
            }), void (this.ju() && this.getSurveys(()=>{}, !0));
            if (this.Pu) this.Pu.then((i)=>{
                this.Os || t(i.surveys, i.context);
            }).catch((t)=>bl.error("Error in survey callback", t));
            else {
                var n = this.Bu("/api/surveys/", {
                    method: "GET",
                    query: {
                        token: r.projectToken
                    },
                    sentAt: "query",
                    timeoutMs: this.mn.requestTimeoutMs
                }).then((t)=>{
                    try {
                        return this.Hu(r, t);
                    } catch (t) {
                        return bl.error("Error processing surveys response", t), this.Hu(r, {
                            statusCode: 0,
                            error: t
                        });
                    }
                }, (t)=>this.Hu(r, {
                        statusCode: 0,
                        error: t
                    }));
                this.Pu = n;
                var o = ()=>{
                    this.Pu === n && (this.Pu = null);
                };
                n.then((i)=>{
                    o(), this.Os || t(i.surveys, i.context);
                }, o).catch((t)=>bl.error("Error in survey callback", t));
            }
        }
    }
    Bu(t, i) {
        var e = this.Ns;
        return e ? e.sendRequest(t, i) : new Promise((t)=>t({
                statusCode: 0,
                error: new Error($h)
            }));
    }
    Hu(t, i) {
        if (this.Os) return {
            surveys: [],
            context: {
                isLoaded: !1,
                error: $h
            }
        };
        var e = i.statusCode;
        if (200 !== e || !i.json) {
            var r = "Surveys API could not be loaded, status: " + e;
            return 0 !== e ? bl.error(r) : i.error || bl.warn(r), this.Au = Date.now(), {
                surveys: [],
                context: {
                    isLoaded: !1,
                    error: r
                }
            };
        }
        this.Au = null;
        var s, n = i.json.surveys || [], o = n.filter((t)=>(function(t) {
                return !(!t.start_date || t.end_date);
            })(t) && (ll(t) || function(t) {
                var i;
                return !(null == (i = t.conditions) || null == (i = i.actions) || null == (i = i.values) || !i.length);
            }(t)));
        return o.length > 0 && (null == (s = this._surveyEventReceiver) || s.register(o)), t.kv.set({
            [Or]: n,
            [Ir]: Date.now()
        }), {
            surveys: n,
            context: {
                isLoaded: !0
            }
        };
    }
    ju() {
        return this.zu() && !this.Pu && !this.Uu();
    }
    zu() {
        var t, i, e = null == (t = null !== (i = this.Ns) && void 0 !== i ? i : this.Lu) ? void 0 : t.kv.get(Ir);
        return B(e) && Date.now() - e > 3e5;
    }
    Uu() {
        return B(this.Au) && 3e5 > Date.now() - this.Au;
    }
    markSurveyAsSeen(t, i) {
        var e, r = {
            id: t,
            current_iteration: null !== (e = null == i ? void 0 : i.iteration) && void 0 !== e ? e : null
        };
        wl(r);
        try {
            localStorage.setItem("lastSeenSurveyDate", (new Date).toISOString());
        } catch (t) {}
    }
    qu(t) {
        for (var i of this.Ru)try {
            if (!t.isLoaded) return i([], t);
            this.getSurveys(i);
        } catch (t) {
            bl.error("Error in survey callback", t);
        }
    }
    getActiveMatchingSurveys(t, i) {
        if (void 0 === i && (i = !1), !U(this._surveyManager)) return this._surveyManager.getActiveMatchingSurveys(t, i);
        bl.warn("init was not called");
    }
    Wu(t) {
        var i = null;
        return this.getSurveys((e)=>{
            var r;
            i = null !== (r = e.find((i)=>i.id === t)) && void 0 !== r ? r : null;
        }), i;
    }
    Vu(t) {
        if (U(this._surveyManager)) return {
            eligible: !1,
            reason: $h
        };
        var i = "string" == typeof t ? this.Wu(t) : t;
        return i ? this._surveyManager.checkSurveyEligibility(i) : {
            eligible: !1,
            reason: "Survey not found"
        };
    }
    Gu(t) {
        if (U(this._surveyManager)) return {
            eligible: !1,
            reason: $h
        };
        var i = "string" == typeof t ? this.Wu(t) : t;
        return i ? this._surveyManager.checkSurveyRenderability(i) : {
            eligible: !1,
            reason: "Survey not found"
        };
    }
    canRenderSurvey(t) {
        if (U(this._surveyManager)) return bl.warn("init was not called"), {
            visible: !1,
            disabledReason: $h
        };
        var i = this.Gu(t);
        return {
            visible: i.eligible,
            disabledReason: i.reason
        };
    }
    canRenderSurveyAsync(t, i) {
        return U(this._surveyManager) ? (bl.warn("init was not called"), Promise.resolve({
            visible: !1,
            disabledReason: $h
        })) : new Promise((e)=>{
            this.getSurveys((i)=>{
                var r, s = null !== (r = i.find((i)=>i.id === t)) && void 0 !== r ? r : null;
                if (s) {
                    var n = this.Gu(s);
                    e({
                        visible: n.eligible,
                        disabledReason: n.reason
                    });
                } else e({
                    visible: !1,
                    disabledReason: "Survey not found"
                });
            }, i);
        });
    }
    renderSurvey(t, i, e) {
        var s;
        if (U(this._surveyManager)) bl.warn("init was not called");
        else {
            var n = "string" == typeof t ? this.Wu(t) : t;
            if (null != n && n.id) if (Sl.includes(n.type)) {
                var o = null == r ? void 0 : r.querySelector(i);
                if (o) if (null != (s = n.appearance) && s.surveyPopupDelaySeconds) {
                    bl.info("Rendering survey " + n.id + " with delay of " + n.appearance.surveyPopupDelaySeconds + " seconds");
                    var a = setTimeout(()=>{
                        var t, i;
                        this.Fu.delete(a), this.Os || (bl.info("Rendering survey " + n.id + " with delay of " + (null == (t = n.appearance) ? void 0 : t.surveyPopupDelaySeconds) + " seconds"), null == (i = this._surveyManager) || i.renderSurvey(n, o, e), bl.info("Survey " + n.id + " rendered"));
                    }, 1e3 * n.appearance.surveyPopupDelaySeconds);
                    this.Fu.add(a);
                } else this._surveyManager.renderSurvey(n, o, e);
                else bl.warn("Survey element not found");
            } else bl.warn("Surveys of type " + n.type + " cannot be rendered in the app");
            else bl.warn("Survey not found");
        }
    }
    displaySurvey(t, i) {
        var e;
        if (U(this._surveyManager)) bl.warn("init was not called");
        else {
            var r = this.Wu(t);
            if (r) {
                var s = r;
                if (null != (e = r.appearance) && e.surveyPopupDelaySeconds && i.ignoreDelay && (s = _({}, r, {
                    appearance: _({}, r.appearance, {
                        surveyPopupDelaySeconds: 0
                    })
                })), i.displayType !== Wo.Popover && i.initialResponses && bl.warn("initialResponses is only supported for popover surveys. prefill will not be applied."), !1 === i.ignoreConditions) {
                    var n = this.Vu(r);
                    if (!n.eligible) return void bl.warn("Survey is not eligible to be displayed: ", n.reason);
                }
                i.displayType !== Wo.Inline ? this._surveyManager.handlePopoverSurvey(s, i) : this.renderSurvey(s, i.selector, i.properties);
            } else bl.warn("Survey not found");
        }
    }
    cancelPendingSurvey(t) {
        U(this._surveyManager) ? bl.warn("init was not called") : this._surveyManager.cancelSurvey(t);
    }
    handlePageUnload() {
        var t;
        null == (t = this._surveyManager) || null == t.handlePageUnload || t.handlePageUnload();
    }
}
function Ch(t, i, e) {
    if (U(t)) return !1;
    switch(e){
        case "exact":
            return t === i;
        case "contains":
            var r = i.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/_/g, ".").replace(/%/g, ".*");
            return new RegExp(r, "i").test(t);
        case "regex":
            try {
                return new RegExp(i).test(t);
            } catch (t) {
                return !1;
            }
        default:
            return !1;
    }
}
class Oh {
    constructor(t){
        this.Zu = new Set, this.Qu = new Set, this.Ju = new el, this.Ku = (t, i)=>this.Yu(t, i) && this.Xu(t, i) && this.th(t, i) && this.eh(t, i), this.Yu = (t, i)=>null == i || !i.event || (null == t ? void 0 : t.event) === (null == i ? void 0 : i.event), this._instance = t;
    }
    init() {
        var t, i;
        D(null == (t = this._instance) ? void 0 : t._addCaptureHook) || (this.ih = null == (i = this._instance) ? void 0 : i._addCaptureHook((t, i)=>{
            this.on(t, i);
        }));
    }
    dispose() {
        var t;
        null == (t = this.ih) || t.call(this), this.ih = void 0, this.Ju = new el;
    }
    register(t) {
        var i, e;
        if (!D(null == (i = this._instance) ? void 0 : i._addCaptureHook) && (t.forEach((t)=>{
            var i;
            this.Zu.add(t), null == (i = t.steps) || i.forEach((t)=>{
                this.Qu.add((null == t ? void 0 : t.event) || "");
            });
        }), null != (e = this._instance) && e.autocapture)) {
            var r = new Set;
            this.Zu.forEach((t)=>{
                var i;
                null == (i = t.steps) || i.forEach((t)=>{
                    null != t && t.selector && r.add(t.selector);
                });
            }), this._instance.autocapture.setElementSelectors(r);
        }
    }
    replace(t) {
        this.Zu.clear(), this.Qu.clear(), this.register(t);
    }
    on(t, i) {
        null != i && 0 != t.length && (this.Qu.has(t) || this.Qu.has(i.event)) && this.Zu.forEach((t)=>{
            this.rh(i, t) && this.Ju.emit("actionCaptured", t.name);
        });
    }
    nh(t) {
        this.onAction("actionCaptured", (i)=>t(i));
    }
    rh(t, i) {
        if (null == (null == i ? void 0 : i.steps)) return !1;
        for (var e of i.steps)if (this.Ku(t, e)) return !0;
        return !1;
    }
    onAction(t, i) {
        return this.Ju.on(t, i);
    }
    Xu(t, i) {
        if (null != i && i.url) {
            var e, r = null == t || null == (e = t.properties) ? void 0 : e.$current_url;
            if (!r || "string" != typeof r) return !1;
            if (!Ch(r, i.url, i.url_matching || "contains")) return !1;
        }
        return !0;
    }
    th(t, i) {
        return !!this.sh(t, i) && !!this.ah(t, i) && !!this.oh(t, i);
    }
    sh(t, i) {
        var e;
        if (null == i || !i.href) return !0;
        var r = this.lh(t);
        if (r.length > 0) return r.some((t)=>Ch(t.href, i.href, i.href_matching || "exact"));
        var s, n = (null == t || null == (e = t.properties) ? void 0 : e.$elements_chain) || "";
        return !!n && Ch((s = n.match(/(?::|")href="(.*?)"/)) ? s[1] : "", i.href, i.href_matching || "exact");
    }
    ah(t, i) {
        var e;
        if (null == i || !i.text) return !0;
        var r = this.lh(t);
        if (r.length > 0) return r.some((t)=>Ch(t.text, i.text, i.text_matching || "exact") || Ch(t.$el_text, i.text, i.text_matching || "exact"));
        var s, n, o, a = (null == t || null == (e = t.properties) ? void 0 : e.$elements_chain) || "";
        return !!a && (s = function(t) {
            for(var i, e = [], r = /(?::|")text="(.*?)"/g; !U(i = r.exec(t));)e.includes(i[1]) || e.push(i[1]);
            return e;
        }(a), n = i.text, o = i.text_matching || "exact", s.some((t)=>Ch(t, n, o)));
    }
    oh(t, i) {
        var e, r;
        if (null == i || !i.selector) return !0;
        var s = null == t || null == (e = t.properties) ? void 0 : e.$element_selectors;
        if (null != s && s.includes(i.selector)) return !0;
        var n = (null == t || null == (r = t.properties) ? void 0 : r.$elements_chain) || "";
        if (i.selector_regex && n) try {
            return new RegExp(i.selector_regex).test(n);
        } catch (t) {
            return !1;
        }
        return !1;
    }
    lh(t) {
        var i;
        return null == (null == t || null == (i = t.properties) ? void 0 : i.$elements) ? [] : null == t ? void 0 : t.properties.$elements;
    }
    eh(t, i) {
        return null == i || !i.properties || 0 === i.properties.length || vl(i.properties.reduce((t, i)=>{
            var e = I(i.value) ? i.value.map(String) : null != i.value ? [
                String(i.value)
            ] : [];
            return t[i.key] = {
                values: e,
                operator: i.operator || "exact"
            }, t;
        }, {}), null == t ? void 0 : t.properties);
    }
}
class Ih {
    constructor(t){
        var i;
        this.uh = [], this._instance = t, this.hh = new Map, this.dh = new Map, this.fh = new Map, this.ph = null == (i = this._instance) || null == i.onSessionId ? void 0 : i.onSessionId((t)=>this.gh(t));
    }
    mh(t) {
        return !1;
    }
    yh() {
        return null;
    }
    bh(t) {}
    _h() {}
    wh(t, i) {
        return !!t && vl(t.propertyFilters, null == i ? void 0 : i.properties);
    }
    kh(t, i) {
        var e = new Map;
        return t.forEach((t)=>{
            var r;
            null == (r = t.conditions) || null == (r = r[i]) || null == (r = r.values) || r.forEach((i)=>{
                if (null != i && i.name) {
                    var r = e.get(i.name) || [];
                    r.push(t.id), e.set(i.name, r);
                }
            });
        }), e;
    }
    Sh(t, i, e) {
        var r = (e === Do.Activation ? this.hh : this.dh).get(t), s = [];
        return this.xh((t)=>{
            s = t.filter((t)=>null == r ? void 0 : r.includes(t.id));
        }), s.filter((r)=>{
            var s, n = null == (s = r.conditions) || null == (s = s[e]) || null == (s = s.values) ? void 0 : s.find((i)=>i.name === t);
            return this.wh(n, i);
        });
    }
    register(t) {
        this.Ch(t, !1);
    }
    replace(t) {
        this.Ch(t, !0);
    }
    Ch(t, i) {
        var e;
        D(null == (e = this._instance) ? void 0 : e._addCaptureHook) || (this.Th(t, i), this.Mh(t, i));
    }
    Mh(t, i) {
        var e = t.filter((t)=>{
            var i;
            return null == (i = t.conditions) || null == (i = i.actions) || null == (i = i.values) ? void 0 : i.length;
        });
        if (i && this.fh.clear(), 0 !== e.length) {
            this.Ih || (this.Ih = new Oh(this._instance), this.Ih.init(), this.Ih.nh((t)=>this.onAction(t)));
            var r = [];
            e.forEach((t)=>{
                var i;
                null == (i = t.conditions) || null == (i = i.actions) || i.values.forEach((i)=>{
                    if (r.push(i), i.name) {
                        var e, s = null !== (e = this.fh.get(i.name)) && void 0 !== e ? e : [];
                        s.includes(t.id) || s.push(t.id), this.fh.set(i.name, s);
                    }
                });
            }), i ? this.Ih.replace(r) : this.Ih.register(r);
        } else {
            var s;
            i && (null == (s = this.Ih) || s.replace([]));
        }
    }
    Eh(t, i) {
        i.forEach((i, e)=>{
            var r, s = null !== (r = t.get(e)) && void 0 !== r ? r : [];
            i.forEach((t)=>{
                s.includes(t) || s.push(t);
            }), t.set(e, s);
        });
    }
    Th(t, i) {
        var e, r, s = t.filter((t)=>{
            var i, e;
            return (null == (i = t.conditions) ? void 0 : i.events) && (null == (e = t.conditions) || null == (e = e.events) || null == (e = e.values) ? void 0 : e.length) > 0;
        }), n = t.filter((t)=>{
            var i, e;
            return (null == (i = t.conditions) ? void 0 : i.cancelEvents) && (null == (e = t.conditions) || null == (e = e.cancelEvents) || null == (e = e.values) ? void 0 : e.length) > 0;
        }), o = this.kh(t, Do.Activation), a = this.kh(t, Do.Cancellation);
        i ? (this.hh = o, this.dh = a) : (this.Eh(this.hh, o), this.Eh(this.dh, a)), (0 !== s.length || 0 !== n.length) && (null !== (e = this.ih) && void 0 !== e || (this.ih = null == (r = this._instance) ? void 0 : r._addCaptureHook((t, i)=>{
            this.onEvent(t, i);
        })));
    }
    onEvent(t, i) {
        var e, r, s = this.Rh(), n = (null == i || null == (e = i.properties) ? void 0 : e.$survey_id) || (null == i || null == (r = i.properties) ? void 0 : r.$product_tour_id);
        if (n && this.getActivatedIds().includes(n)) {
            var o = this.Ph(t, n);
            if ("consume" === o) return s.info("event consumed activated item, removing it", {
                event: t,
                itemId: n
            }), void this.Ah([
                n
            ]);
            if ("persist" === o) return s.info("shown item promoted to persisted activation", {
                event: t,
                itemId: n
            }), this.Fh(n), void this.Oh([
                n
            ]);
        }
        if (this.dh.has(t)) {
            var a = this.Sh(t, i, Do.Cancellation);
            a.length > 0 && (s.info("cancel event matched, cancelling items", {
                event: t,
                itemsToCancel: a.map((t)=>t.id)
            }), this.Ah(a.map((t)=>t.id)), a.forEach((t)=>this.Lh(t.id)));
        }
        if (this.hh.has(t)) {
            s.info("event name matched", {
                event: t,
                eventPayload: i,
                items: this.hh.get(t)
            });
            var l = this.Sh(t, i, Do.Activation);
            this.Dh(l.map((t)=>t.id));
        }
    }
    onAction(t) {
        this.fh.has(t) && this.Dh(this.fh.get(t) || []);
    }
    Dh(t) {
        var i;
        if (0 !== t.length) {
            var e = !(null == (i = this._instance) || null == i.get_session_id || !i.get_session_id()), r = [];
            for (var s of t)e && this.mh(s) ? this.Fh(s) && this.$h(s) : r.push(s);
            r.length > 0 && (this.uh = [
                ...new Set([
                    ...this.uh,
                    ...r
                ])
            ]), this.Rh().info("updating activated items", {
                activatedItems: this.getActivatedIds()
            });
        }
    }
    Fh(t) {
        this.uh = this.uh.filter((i)=>i !== t);
        var i = this.Nh();
        return !i.includes(t) && (this.qh([
            ...i,
            t
        ]), this.jh(), !0);
    }
    Ah(t) {
        var i = new Set(t);
        this.uh = this.uh.filter((t)=>!i.has(t));
        var e = this.Bh(), r = e.filter((t)=>!i.has(t));
        r.length !== e.length && (this.qh(r), 0 === r.length && this.Hh()), this.Oh(t);
    }
    zh() {
        var t, i = this.yh();
        if (!i) return {};
        var e = null == (t = this._instance) || null == (t = t.persistence) ? void 0 : t.props[i];
        return e && "object" == typeof e ? e : {};
    }
    $h(t) {
        if (this.yh()) {
            var i = this.zh();
            this.bh(_({}, i, {
                [t]: Date.now()
            }));
        }
    }
    Oh(t) {
        if (this.yh()) {
            var i = this.zh(), e = {}, r = !1;
            for (var s of Object.entries(i)){
                var n = s[0], o = s[1];
                t.includes(n) ? r = !0 : e[n] = o;
            }
            r && (M(e) ? this._h() : this.bh(e));
        }
    }
    Uh() {
        this.yh() && this._h();
    }
    getActivationTimestamp(t) {
        if (this.Nh().includes(t)) {
            var i = this.zh()[t];
            return B(i) ? i : void 0;
        }
    }
    Bh() {
        var t, i = this.Wh();
        return (null == (t = this._instance) || null == (t = t.persistence) ? void 0 : t.props[i]) || [];
    }
    Nh() {
        var t, i, e = this.Bh();
        if (0 === e.length) return [];
        var r = null == (t = this._instance) || null == (t = t.persistence) ? void 0 : t.props[this.Vh()], s = null == (i = this._instance) || null == i.get_session_id ? void 0 : i.get_session_id();
        return s && r === s ? e : [];
    }
    jh() {
        var t, i = null == (t = this._instance) || null == t.get_session_id ? void 0 : t.get_session_id();
        i && this.Gh(i);
    }
    Hh() {
        this.Zh();
    }
    gh(t) {
        var i, e = null == (i = this._instance) || null == (i = i.persistence) ? void 0 : i.props[this.Vh()];
        if (e && e !== t) {
            var r = this.Bh(), s = this.zh();
            r.length > 0 && (this.qh([]), r.filter((t)=>B(s[t])).forEach((t)=>this.Lh(t))), this.Hh(), this.Uh();
        }
    }
    getActivatedIds() {
        return [
            ...new Set([
                ...this.Nh(),
                ...this.uh
            ])
        ].filter((t)=>!this.Qh(t));
    }
    dispose() {
        var t, i, e;
        null == (t = this.ph) || t.call(this), this.ph = void 0, null == (i = this.ih) || i.call(this), this.ih = void 0, null == (e = this.Ih) || e.dispose(), this.Ih = void 0;
    }
    reset() {
        this.uh = [], this.Bh().length > 0 && this.qh([]), this.Hh(), this.Uh();
    }
    getEventToItemsMap() {
        return this.hh;
    }
    Jh() {
        return this.Ih;
    }
}
class Fh extends Ih {
    constructor(t){
        super(t);
    }
    Wh() {
        return Fr;
    }
    Vh() {
        return Ar;
    }
    yh() {
        return Mr;
    }
    bh(t) {
        var i;
        null == (i = this._instance) || null == (i = i.persistence) || i.register({
            [Mr]: t
        });
    }
    _h() {
        var t;
        null == (t = this._instance) || null == (t = t.persistence) || t.unregister(Mr);
    }
    mh(t) {
        var i, e;
        this.xh((i)=>{
            e = i.find((i)=>i.id === t);
        });
        var r = null == (i = e) || null == (i = i.appearance) ? void 0 : i.surveyPopupDelaySeconds;
        return B(r) && r > 0;
    }
    Kh() {
        return qo.SHOWN;
    }
    xh(t) {
        var i;
        null == (i = this._instance) || i.getSurveys(t);
    }
    Lh(t) {
        var i;
        null == (i = this._instance) || i.cancelPendingSurvey(t);
    }
    Rh() {
        return bl;
    }
    qh(t) {
        var i;
        null == (i = this._instance) || null == (i = i.persistence) || i.register({
            [Fr]: t
        });
    }
    Gh(t) {
        var i;
        null == (i = this._instance) || null == (i = i.persistence) || i.register({
            [Ar]: t
        });
    }
    Zh() {
        var t;
        null == (t = this._instance) || null == (t = t.persistence) || t.unregister(Ar);
    }
    Qh() {
        return !1;
    }
    Ph(t, i) {
        var e;
        this.xh((t)=>{
            e = t.find((t)=>t.id === i);
        });
        var r = !e || function(t) {
            var i;
            return ll(t) && !(null == (i = t.conditions) || null == (i = i.events) || !i.repeatedActivation) || "always" === t.schedule;
        }(e);
        return r ? t === qo.SHOWN ? "consume" : "ignore" : t === qo.SHOWN ? "persist" : t === qo.DISMISSED || t === qo.SENT ? "consume" : "ignore";
    }
    getSurveys() {
        return this.getActivatedIds();
    }
    getEventToSurveys() {
        return this.getEventToItemsMap();
    }
}
class Ah {
    constructor(t){
        this._instance = t;
    }
    initialize() {}
    get(t) {
        if ("string" == typeof t) return this._instance.get_property(t);
        var i = {};
        for (var e of t){
            var r = this._instance.get_property(e);
            D(r) || (i[e] = r);
        }
        return i;
    }
    set(t, i) {
        this._instance.register("string" == typeof t ? {
            [t]: i
        } : t);
    }
    remove(t) {
        "string" != typeof t ? t.forEach((t)=>this._instance.unregister(t)) : this._instance.unregister(t);
    }
}
class Mh {
    constructor(t){
        this._instance = t;
    }
    get() {
        var t = this._instance.config;
        return {
            disableSurveys: t.disable_surveys,
            cookielessMode: !!t.cookieless_mode,
            advancedEnableSurveys: t.advanced_enable_surveys,
            requestTimeoutMs: t.surveys_request_timeout_ms
        };
    }
    isOptedOut() {
        return this._instance.consent.isOptedOut();
    }
    getExtensions() {
        var t = null == v ? void 0 : v.__PosthogExtensions__;
        if (t) {
            var i = t.generateSurveys, e = t.loadExternalDependency;
            return {
                generateSurveys: i ? (t)=>i(this._instance, t) : void 0,
                loadExternalDependency: e ? (t)=>e(this._instance, "surveys", t) : void 0
            };
        }
    }
    createEventReceiver() {
        return new Fh(this._instance);
    }
}
var Dh = null != t && t.location ? no(t.location.hash, "__posthog") || no(location.hash, "state") : null, Nh = "_postHogToolbarParams", Lh = Be("[Toolbar]"), jh = Be("[FeatureFlags]");
class Uh {
    constructor(t, i){
        void 0 === i && (i = !1), this.Yh = !1, this.update(t, i);
    }
    update(t, i) {
        this.Xh = ((t, i)=>{
            var e, r, s, n, o;
            return {
                bootstrap: {
                    featureFlags: null == (e = t.bootstrap) ? void 0 : e.featureFlags,
                    featureFlagPayloads: null == (r = t.bootstrap) ? void 0 : r.featureFlagPayloads
                },
                remoteRequestsDisabled: i,
                featureFlagsDisabled: !!t.advanced_disable_feature_flags,
                onlyEvaluateSurveyFeatureFlags: !!t.advanced_only_evaluate_survey_feature_flags,
                deduplicateCallsPerSession: !!t.advanced_feature_flags_dedup_per_session,
                cacheTtlMs: t.feature_flag_cache_ttl_ms,
                refreshIntervalMs: null !== (s = t.remote_config_refresh_interval_ms) && void 0 !== s ? s : 3e5,
                requestTimeoutMs: t.feature_flag_request_timeout_ms,
                compression: t.disable_compression ? void 0 : "best-available",
                evaluationContexts: null !== (n = null !== (o = t.evaluation_contexts) && void 0 !== o ? o : t.evaluation_environments) && void 0 !== n ? n : [],
                flagKeys: I(t.flag_keys) ? t.flag_keys : void 0
            };
        })(t, i), !t.evaluation_environments || t.evaluation_contexts || this.Yh || (jh.warn("evaluation_environments is deprecated. Use evaluation_contexts instead. evaluation_environments will be removed in a future version."), this.Yh = !0), D(t.flag_keys) || I(t.flag_keys) || jh.error("Invalid flag_keys found:", t.flag_keys, "Expected array of non-empty strings");
    }
    get() {
        return this.Xh;
    }
}
var Bh = Be("[FeatureFlags]"), zh = Be("[FeatureFlags]", {
    debugEnabled: !0
}), Hh = "\" failed. Feature flags didn't load in time.", qh = "connection_error", Vh = (t)=>{
    for(var i = {}, e = 0; t.length > e; e++)i[t[e]] = !0;
    return i;
}, Wh = (t)=>{
    var i = {};
    for (var e of fs(t || {})){
        var r = e[1];
        r && (i[e[0]] = r);
    }
    return i;
}, Gh = Be("[Error tracking]"), Jh = "webkit-masked-url:", Kh = [
    "chrome-extension://",
    "moz-extension://",
    "safari-extension:",
    "safari-web-extension:",
    Jh
], Yh = [
    "__firefox__",
    "__gCrWeb"
], Qh = "Refusing to render web experiment since the viewer is a likely bot", Xh = {
    icontains: (t, i)=>i.toLowerCase().indexOf(t.toLowerCase()) > -1,
    not_icontains: (t, i)=>-1 === i.toLowerCase().indexOf(t.toLowerCase()),
    regex: (t, i)=>hl(i, t),
    not_regex: (t, i)=>!hl(i, t),
    exact: (t, i)=>i === t,
    is_not: (t, i)=>i !== t
};
class Zh {
    get mn() {
        return this._instance.config;
    }
    constructor(t){
        var i = this;
        this.getWebExperimentsAndEvaluateDisplayLogic = function(t) {
            void 0 === t && (t = !1), i.getWebExperiments((t)=>{
                Zh.td("retrieved web experiments from the server"), i.ed = new Map, t.forEach((t)=>{
                    if (t.feature_flag_key) {
                        var e;
                        i.ed && (Zh.td("setting flag key ", t.feature_flag_key, " to web experiment ", t), null == (e = i.ed) || e.set(t.feature_flag_key, t));
                        var r = i._instance.getFeatureFlag(t.feature_flag_key);
                        N(r) && t.variants[r] && i.rd(t.name, r, t.variants[r].transforms);
                    } else if (t.variants) for(var s in t.variants){
                        var n = t.variants[s];
                        Zh.nd(n, i._instance) && i.rd(t.name, s, n.transforms);
                    }
                });
            }, t);
        }, this._instance = t, this._instance.onFeatureFlags((t)=>{
            this.onFeatureFlags(t);
        });
    }
    initialize() {}
    onFeatureFlags(t) {
        if (this._is_bot()) Zh.td(Qh);
        else if (!this.mn.disable_web_experiments) {
            if (U(this.ed)) return this.ed = new Map, this.loadIfEnabled(), void this.previewWebExperiment();
            Zh.td("applying feature flags", t), t.forEach((t)=>{
                var i;
                if (this.ed && null != (i = this.ed) && i.has(t)) {
                    var e, r = this._instance.getFeatureFlag(t), s = null == (e = this.ed) ? void 0 : e.get(t);
                    r && null != s && s.variants[r] && this.rd(s.name, r, s.variants[r].transforms);
                }
            });
        }
    }
    previewWebExperiment() {
        var t = Zh.getWindowLocation();
        if (null != t && t.search) {
            var i = ro(null == t ? void 0 : t.search, "__experiment_id"), e = ro(null == t ? void 0 : t.search, "__experiment_variant");
            i && e && (Zh.td("previewing web experiments " + i + " && " + e), this.getWebExperiments((t)=>{
                this.sd(parseInt(i), e, t);
            }, !1, !0));
        }
    }
    loadIfEnabled() {
        this.mn.disable_web_experiments || this.getWebExperimentsAndEvaluateDisplayLogic();
    }
    getWebExperiments(t, i, e) {
        if (this.mn.disable_web_experiments && !e) return t([]);
        var r = this._instance.get_property("$web_experiments");
        if (r && !i) return t(r);
        this._instance._send_request({
            url: this._instance.requestRouter.endpointFor("api", "/api/web_experiments/?token=" + this.mn.token),
            method: "GET",
            timestampMode: "query",
            callback: (i)=>t(200 === i.statusCode && i.json && i.json.experiments || [])
        });
    }
    sd(t, i, e) {
        var r = e.filter((i)=>i.id === t);
        r && r.length > 0 && (Zh.td("Previewing web experiment [" + r[0].name + "] with variant [" + i + "]"), this.rd(r[0].name, i, r[0].variants[i].transforms));
    }
    static nd(t, i) {
        return !U(t.conditions) && Zh.ad(t, i) && Zh.od(t);
    }
    static ad(t, i) {
        var e;
        if (U(t.conditions) || U(null == (e = t.conditions) ? void 0 : e.url)) return !0;
        var r = Zh.getWindowLocation();
        if (r) {
            var s, n, o, a = Qs(i, r.href);
            return null == (s = t.conditions) || !s.url || Xh[null !== (n = null == (o = t.conditions) ? void 0 : o.urlMatchType) && void 0 !== n ? n : "icontains"](t.conditions.url, a);
        }
        return !1;
    }
    static getWindowLocation() {
        return null == t ? void 0 : t.location;
    }
    static od(t) {
        var i;
        if (U(t.conditions) || U(null == (i = t.conditions) ? void 0 : i.utm)) return !0;
        var e = fo();
        if (e.utm_source) {
            var r, s, n, o, a, l, h, u, d = null == (r = t.conditions) || null == (r = r.utm) || !r.utm_campaign || (null == (s = t.conditions) || null == (s = s.utm) ? void 0 : s.utm_campaign) == e.utm_campaign, v = null == (n = t.conditions) || null == (n = n.utm) || !n.utm_source || (null == (o = t.conditions) || null == (o = o.utm) ? void 0 : o.utm_source) == e.utm_source, c = null == (a = t.conditions) || null == (a = a.utm) || !a.utm_medium || (null == (l = t.conditions) || null == (l = l.utm) ? void 0 : l.utm_medium) == e.utm_medium, f = null == (h = t.conditions) || null == (h = h.utm) || !h.utm_term || (null == (u = t.conditions) || null == (u = u.utm) ? void 0 : u.utm_term) == e.utm_term;
            return d && c && f && v;
        }
        return !1;
    }
    static td(t) {
        for(var i = arguments.length, e = new Array(i > 1 ? i - 1 : 0), r = 1; i > r; r++)e[r - 1] = arguments[r];
        Ue.info("[WebExperiments] " + t, e);
    }
    rd(t, i, e) {
        this._is_bot() ? Zh.td(Qh) : "control" !== i ? e.forEach((e)=>{
            if (e.selector) {
                var r;
                Zh.td("applying transform of variant " + i + " for experiment " + t + " ", e);
                var s = null == (r = document) ? void 0 : r.querySelectorAll(e.selector);
                null == s || s.forEach((t)=>{
                    var i = t;
                    e.html && (i.innerHTML = e.html), e.css && i.setAttribute("style", e.css);
                });
            }
        }) : Zh.td("Control variants leave the page unmodified.");
    }
    _is_bot() {
        return e && this._instance ? ol(e, this.mn.custom_blocked_useragents) : void 0;
    }
}
var tu = Be("[Conversations]"), iu = "Conversations not available yet.";
function eu(t, i) {
    var r, s, n, o, a, l, h, u = null !== (r = null == t ? void 0 : t.flushIntervalMs) && void 0 !== r ? r : 3e3, d = null !== (s = null == t ? void 0 : t.maxBufferSize) && void 0 !== s ? s : 100, v = null != i && i.consoleCapture ? void 0 : null !== (n = null == t ? void 0 : t.maxLogsPerInterval) && void 0 !== n ? n : 1e3, c = D(v) ? Math.max(d, 2048) : Math.max(d, v), f = _({}, function() {
        var t = "", i = "";
        try {
            var r = null == e ? void 0 : e.userAgent;
            if (r) {
                var s = ui(r);
                t = s[0], i = s[1];
            }
        } catch (t) {}
        return function(t, i) {
            var e = function(t) {
                if (t) return ({}).hasOwnProperty.call($e, t) ? $e[t] : t;
            }(t);
            return _({}, e ? {
                "os.name": e
            } : {}, i ? {
                "os.version": i
            } : {});
        }(t, i);
    }(), null == t ? void 0 : t.resourceAttributes);
    return {
        serviceName: null !== (o = null !== (a = null == f ? void 0 : f["service.name"]) && void 0 !== a ? a : null == t ? void 0 : t.serviceName) && void 0 !== o ? o : null == i ? void 0 : i.serviceNameDefault,
        serviceVersion: null !== (l = null == f ? void 0 : f["service.version"]) && void 0 !== l ? l : null == t ? void 0 : t.serviceVersion,
        environment: null !== (h = null == f ? void 0 : f["deployment.environment"]) && void 0 !== h ? h : null == t ? void 0 : t.environment,
        resourceAttributes: f,
        beforeSend: null == t ? void 0 : t.beforeSend,
        flushIntervalMs: u,
        maxBufferSize: d,
        maxQueueSize: c,
        maxBatchRecordsPerPost: 100,
        rateCapWindowMs: u,
        maxLogsPerInterval: v,
        backgroundFlushBudgetMs: 0,
        terminationFlushBudgetMs: 0
    };
}
var ru = [
    "debug",
    "log",
    "warn",
    "error",
    "info"
], su = "console", nu = "__posthogHandledLogsRequestError", ou = (t, i)=>{
    var e = t instanceof Error ? t : new Error(i);
    return e[nu] = !0, e;
}, au = (t)=>!!t && "object" == typeof t && !0 === t[nu], lu = {
    featureFlags: class {
        constructor(t){
            this.name = "featureFlags", this.ld = !1, this.featureFlagEventHandlers = [], this.A = Bh, this.ud = {}, this.hd = {}, this.dd = [], this.vd = !1, this.fd = !1, this.pd = 0, this.gd = !1, this.md = !1, this.yd = !1, this.bd = !1, this._d = 0, this.Wt = ()=>{
                var t = this.wd();
                this._d = 0, t && this.reloadFeatureFlags();
            }, this.kd = ()=>{
                var t, i = this.Sd;
                D(i) || this.mn.remoteRequestsDisabled || !r || "hidden" === r.visibilityState || Date.now() - (null !== (t = this.xd) && void 0 !== t ? t : 0) < i || (this.reloadFeatureFlags(), this.Cd());
            }, this.Vt = ()=>{
                "visible" === (null == r ? void 0 : r.visibilityState) && this.kd();
            }, "get" in t ? this.Ls = t : (this._instance = t, this.Td = new Uh(t.config, t.fo()), this.Ls = this.Td);
        }
        updateConfig(t, i) {
            var e;
            null == (e = this.Td) || e.update(t, i), this.Ns && this.Md();
        }
        setup(t) {
            return this.Du = t, this.A = t.logger.createLogger("[FeatureFlags]"), Th(t.kv.initialize(), ()=>{
                this.Du === t && (this.Du = void 0, this.Ns = t, this.Id(t));
            });
        }
        Id(i) {
            var e;
            if (this.Ns === i) return t && ys(t, "online", this.Wt), this.Md(), this.Ed = i.registerDynamicEventProperties(()=>this.Rd() ? this.ud : this.hd), this.Pd = null == (e = this._instance) || null == (e = e.persistence) ? void 0 : e.onCrossTabFeatureFlagChange(()=>{
                this.Ad(), this.Fd();
            }), this.Ad(), this.initialize();
        }
        Md() {
            var t = this.mn.refreshIntervalMs, i = !this.mn.remoteRequestsDisabled && r && !D(t) && t > 0 ? t : void 0;
            i !== this.Sd && (this.Od(), D(i) || (this.Sd = i, this.Cd(), null != r && r.addEventListener && ys(r, ns, this.Vt)));
        }
        Cd() {
            D(this.Sd) || (D(this.Ld) || clearInterval(this.Ld), this.xd = Date.now(), this.Ld = setInterval(this.kd, this.Sd));
        }
        Od() {
            D(this.Ld) || (clearInterval(this.Ld), this.Ld = void 0, null == r || null == r.removeEventListener || r.removeEventListener(ns, this.Vt)), this.Sd = void 0, this.xd = void 0;
        }
        destroy() {
            this.Dd();
        }
        dispose() {
            this.Dd();
        }
        Dd() {
            var i, e;
            this.Od(), this.pd++, this.md = !1, this.Du = void 0, this.Ns && (this.$d(), null == (i = this.Ed) || i.dispose(), this.Ed = void 0, null == (e = this.Pd) || e.call(this), this.Pd = void 0, this.dd = [], null == t || t.removeEventListener("online", this.Wt), this.Ns = void 0);
        }
        get mn() {
            return this.Ls.get();
        }
        Nd(t) {
            var i;
            return null == (i = this.Ns) ? void 0 : i.kv.get(t);
        }
        ni(t) {
            this.qd(()=>{
                var i;
                return null == (i = this.Ns) ? void 0 : i.kv.set(t);
            });
        }
        jd(t, i, e) {
            var r;
            if (null != (r = this._instance) && r.persistence && t[br]) {
                var s = this.Nd(br) || {}, n = t[br] || {}, o = i.flags || i.featureFlags, a = i.flags ? Object.entries(i.flags).filter((t)=>{
                    var i = t[1];
                    return !(null != i && i.failed);
                }).map((t)=>t[0]) : [], l = !!i.errorsWhileComputingFlags && !!i.flags, h = l ? a : e && !I(o) ? Object.keys(o || {}) : Array.from(new Set([
                    ...Object.keys(s),
                    ...Object.keys(n)
                ])), u = this.Nd(xr) || {}, d = t[xr] || {}, v = l || e ? h : Array.from(new Set([
                    ...Object.keys(u),
                    ...Object.keys(d)
                ])), c = !l && !e, f = !!c || h, p = {
                    [yr]: f,
                    [br]: f,
                    [xr]: !!c || v
                };
                for (var _ of (t[Sr] && (p[Sr] = f), [
                    Er,
                    Ur,
                    kr
                ]))D(t[_]) || (p[_] = !0);
                this._instance.persistence.markCrossTabFeatureFlagChanges(p);
            }
        }
        oi(t) {
            this.qd(()=>{
                var i;
                return null == (i = this.Ns) ? void 0 : i.kv.remove(t);
            });
        }
        qd(t) {
            try {
                t();
            } catch (t) {
                this.A.error("Failed to update feature flag persistence", t);
            }
        }
        Ad() {
            var t = {};
            for (var i of [
                yr,
                xr,
                Er,
                Tr
            ]){
                var e = this.Nd(i);
                D(e) || (t[i] = e);
            }
            this.ud = t;
            var r = _({}, t), s = this.Nd(br);
            if (s) for (var n of Object.entries(s))r["$feature/" + n[0]] = n[1];
            this.hd = r;
        }
        Rd() {
            var t = this.mn.cacheTtlMs;
            if (!t || 0 >= t) return !1;
            var i = this.Nd(Ur);
            return "number" != typeof i || Date.now() - i > t;
        }
        Bd() {
            return !!this.Rd() && (this.bd || this.fd || (this.bd = !0, this.A.warn("Feature flag cache is stale, triggering refresh..."), this.reloadFeatureFlags()), !0);
        }
        Hd() {
            var t = this.mn.evaluationContexts;
            return null != t && t.length ? t.filter((t)=>{
                var i = t && "string" == typeof t && t.trim().length > 0;
                return i || this.A.error("Invalid evaluation context found:", t, "Expected non-empty string"), i;
            }) : [];
        }
        zd() {
            var t = this.mn.flagKeys;
            if (!D(t)) return t.filter((t)=>{
                var i = t && "string" == typeof t && t.trim().length > 0;
                return i || this.A.error("Invalid flag key found:", t, "Expected non-empty string"), i;
            });
        }
        initialize() {
            var t, i, e = this.mn, r = null !== (t = null == (i = e.bootstrap) ? void 0 : i.featureFlags) && void 0 !== t ? t : {};
            if (Object.keys(r).length) {
                var s, n, o = null !== (s = null == (n = e.bootstrap) ? void 0 : n.featureFlagPayloads) && void 0 !== s ? s : {}, a = Object.keys(r).filter((t)=>!D(r[t])).reduce((t, i)=>(t[i] = r[i], t), {}), l = Object.keys(o).filter((t)=>a[t]).reduce((t, i)=>(t[i] = o[i], t), {});
                return this.Ud({
                    featureFlags: a,
                    featureFlagPayloads: l
                });
            }
        }
        updateFlags(t, i, e) {
            var r, s, n = null != e && e.merge && null !== (r = this.Nd(br)) && void 0 !== r ? r : {}, o = null != e && e.merge && null !== (s = this.Nd(xr)) && void 0 !== s ? s : {}, a = _({}, n, t), l = _({}, o, i), h = {};
            for (var u of Object.entries(a)){
                var d = u[0], v = u[1];
                h[d] = {
                    key: d,
                    enabled: le(v),
                    variant: he(v),
                    reason: void 0,
                    metadata: D(null == l ? void 0 : l[d]) ? void 0 : {
                        id: 0,
                        version: void 0,
                        description: void 0,
                        payload: l[d]
                    }
                };
            }
            this.Ud({
                flags: h
            });
        }
        get hasLoadedFlags() {
            return this.vd;
        }
        getFlags() {
            return Object.keys(this.getFlagVariants());
        }
        getFlagsWithDetails() {
            var t = this.Nd(Sr), i = this.Nd(Tr), e = this.Nd($r);
            if (!e && !i) return t || {};
            var r = cs({}, t || {}), s = [
                ...new Set([
                    ...Object.keys(e || {}),
                    ...Object.keys(i || {})
                ])
            ];
            for (var n of s){
                var o, a, l = r[n], h = null == i ? void 0 : i[n], u = D(h) ? null !== (o = null == l ? void 0 : l.enabled) && void 0 !== o && o : !!h, d = D(h) ? null == l ? void 0 : l.variant : "string" == typeof h ? h : void 0, v = null == e ? void 0 : e[n], c = _({}, l, {
                    enabled: u,
                    variant: u ? null != d ? d : null == l ? void 0 : l.variant : void 0
                });
                u !== (null == l ? void 0 : l.enabled) && (c.original_enabled = null == l ? void 0 : l.enabled), d !== (null == l ? void 0 : l.variant) && (c.original_variant = null == l ? void 0 : l.variant), v && (c.metadata = _({}, null == l ? void 0 : l.metadata, {
                    payload: v,
                    original_payload: null == l || null == (a = l.metadata) ? void 0 : a.payload
                })), r[n] = c;
            }
            return this.ld || (this.A.warn(" Overriding feature flag details!", {
                flagDetails: t,
                overriddenPayloads: e,
                finalDetails: r
            }), this.ld = !0), r;
        }
        getAllFeatureFlags() {
            var t = this.getFlagVariants(), i = this.getFlagPayloads();
            return Object.keys(t).map((e)=>{
                var r = t[e];
                return {
                    key: e,
                    enabled: le(r),
                    variant: he(r),
                    payload: ae(i[e])
                };
            });
        }
        getFlagVariants() {
            var t = this.Nd(br), i = this.Nd(Tr);
            if (!i) return t || {};
            for(var e = cs({}, t || {}), r = Object.keys(i), s = 0; r.length > s; s++)e[r[s]] = i[r[s]];
            return this.ld || (this.A.warn(" Overriding feature flags!", {
                enabledFlags: t,
                overriddenFlags: i,
                finalFlags: e
            }), this.ld = !0), e;
        }
        getFlagPayloads() {
            var t = this.Nd(xr), i = this.Nd($r);
            if (!i) return t || {};
            for(var e = cs({}, t || {}), r = Object.keys(i), s = 0; r.length > s; s++)e[r[s]] = i[r[s]];
            return this.ld || (this.A.warn(" Overriding feature flag payloads!", {
                flagPayloads: t,
                overriddenPayloads: i,
                finalPayloads: e
            }), this.ld = !0), e;
        }
        reloadFeatureFlags() {
            this.gd || this.mn.featureFlagsDisabled || this.wd() || (this.fd && (this.md = !0), this.Wd || (this.dd.slice().forEach((t)=>{
                try {
                    t();
                } catch (t) {
                    this.A.error("Error while running feature flags reloading callback", t);
                }
            }), this.Wd = setTimeout(()=>{
                this.Vd();
            }, 5)));
        }
        $d() {
            clearTimeout(this.Wd), this.Wd = void 0;
        }
        onReloading(t) {
            return this.dd.push(t), ()=>{
                this.dd = this.dd.filter((i)=>i !== t);
            };
        }
        ensureFlagsLoaded() {
            this.vd || this.fd || this.Wd || this.reloadFeatureFlags();
        }
        setAnonymousDistinctId(t) {
            this.$anon_distinct_id = t;
        }
        setReloadingPaused(t) {
            this.gd = t;
        }
        resetFlagCallReported() {
            this.oi(Nr);
        }
        Vd(t) {
            this.$d();
            var i = this.Ns;
            if (i && !this.mn.remoteRequestsDisabled && !this.wd()) if (this.fd) this.md = !0;
            else {
                var e = {
                    token: i.projectToken,
                    distinct_id: i.distinctId,
                    groups: i.groups,
                    $anon_distinct_id: this.$anon_distinct_id,
                    person_properties: _({}, i.initialPersonProperties, this.Nd(Pr) || {}, {
                        $lib: i.library.name,
                        $lib_version: i.library.version
                    }),
                    group_properties: this.Nd(Rr),
                    timezone: So()
                };
                D(i.deviceId) || (e.$device_id = i.deviceId), (null != t && t.disableFlags || this.mn.featureFlagsDisabled) && (e.disable_flags = !0);
                var r = this.Hd();
                r.length && (e.evaluation_contexts = r);
                var s = this.zd();
                D(s) || (e.flag_keys = s);
                var n = this.mn.onlyEvaluateSurveyFeatureFlags, o = "/flags/?v=2" + (n ? "&only_evaluate_survey_feature_flags=true" : ""), a = this.pd;
                this.fd = !0;
                var l = ()=>{
                    this.md && (this.md = !1, this.Vd());
                }, h = (t)=>{
                    this.fd = !1, a === this.pd ? (this.ni({
                        [jr]: [
                            qh
                        ]
                    }), this.A.error("Feature flag request failed", t), l()) : l();
                };
                try {
                    i.sendRequest(o, {
                        target: "flags",
                        method: "POST",
                        body: e,
                        compression: this.mn.compression,
                        sentAt: "body",
                        timeoutMs: this.mn.requestTimeoutMs
                    }).then((t)=>{
                        var i, r, s = null !== (i = t.json) && void 0 !== i ? i : {}, o = 200 !== t.statusCode;
                        if (this.fd = !1, a === this.pd) {
                            if (this.Gd(t.statusCode), o || this.md || (this.$anon_distinct_id = void 0), !e.disable_flags || this.md) {
                                this.yd = !o;
                                var h = [];
                                t.error ? h.push(t.error instanceof Error && "AbortError" === t.error.name ? "timeout" : t.error instanceof Error ? qh : "unknown_error") : 200 !== t.statusCode && h.push("api_error_" + t.statusCode), s.errorsWhileComputingFlags && h.push("errors_while_computing_flags");
                                var u = !(null == (r = s.quotaLimited) || !r.includes("feature_flags"));
                                u && h.push("quota_limited"), this.ni({
                                    [jr]: h
                                }), u ? this.A.warn("You have hit your feature flags quota limit, and will not be able to load feature flags until the quota is reset.  Please visit https://posthog.com/docs/billing/limits-alerts to learn more.") : e.disable_flags || this.Ud(s, o, {
                                    partialResponse: n
                                }), l();
                            }
                        } else l();
                    }).catch(h);
                } catch (t) {
                    h(t);
                }
            }
        }
        wd() {
            return oo(this._d, 3);
        }
        Gd(t) {
            this._d = ao(t, this._d, 3, ()=>this.A.warn("Feature flag requests are failing before receiving an HTTP response; this can happen due to network issues, CORS, browser blocking, or ad blockers. Stopped refreshing feature flags; will try again when connectivity changes."));
        }
        getFeatureFlag(t, i) {
            var e;
            if (void 0 === i && (i = {}), !i.fresh || this.yd) if (this.vd || this.getFlags() && this.getFlags().length > 0) {
                if (!this.Bd()) {
                    var r = this.getFeatureFlagResult(t, i);
                    return null !== (e = null == r ? void 0 : r.variant) && void 0 !== e ? e : null == r ? void 0 : r.enabled;
                }
            } else this.A.warn('getFeatureFlag for key "' + t + Hh);
        }
        getFeatureFlagDetails(t) {
            return this.getFlagsWithDetails()[t];
        }
        getFeatureFlagPayload(t) {
            var i = this.getFeatureFlagResult(t, {
                send_event: !1
            });
            return null == i ? void 0 : i.payload;
        }
        getFeatureFlagResult(t, i) {
            if (void 0 === i && (i = {}), !i.fresh || this.yd) if (this.vd || this.getFlags() && this.getFlags().length > 0) {
                if (!this.Bd()) {
                    var e, r = this.getFlagVariants(), s = t in r, n = r[t], o = this.getFlagPayloads()[t], a = String(n), l = this.Nd(Er) || void 0, h = this.Nd(Ur) || void 0, u = this.Nd(Nr) || {};
                    if (this.mn.deduplicateCallsPerSession) {
                        var d, v = null == (d = this.Ns) ? void 0 : d.session.sessionId, c = this.Nd(Lr);
                        v && v !== c && (u = {}, e = v);
                    }
                    if (i.send_event || !("send_event" in i)) if (t in u && u[t].includes(a)) e && this.ni({
                        [Nr]: u,
                        [Lr]: e
                    });
                    else {
                        var f, p, g, m, b, y, w, S, x, E, k, T;
                        I(u[t]) ? u[t].push(a) : u[t] = [
                            a
                        ], this.ni(_({
                            [Nr]: u
                        }, e ? {
                            [Lr]: e
                        } : {}));
                        var P = this.getFeatureFlagDetails(t), R = [
                            ...null !== (f = this.Nd(jr)) && void 0 !== f ? f : []
                        ];
                        D(n) && R.push("flag_missing");
                        var C = {
                            $feature_flag: t,
                            $feature_flag_response: n,
                            $feature_flag_payload: null != o ? o : null,
                            $feature_flag_request_id: l,
                            $feature_flag_evaluated_at: h,
                            $feature_flag_bootstrapped_response: null !== (p = null == (g = this.mn.bootstrap) || null == (g = g.featureFlags) ? void 0 : g[t]) && void 0 !== p ? p : null,
                            $feature_flag_bootstrapped_payload: null !== (m = null == (b = this.mn.bootstrap) || null == (b = b.featureFlagPayloads) ? void 0 : b[t]) && void 0 !== m ? m : null,
                            $used_bootstrap_value: !this.yd
                        };
                        D(null == P || null == (y = P.metadata) ? void 0 : y.has_experiment) || (C.$feature_flag_has_experiment = P.metadata.has_experiment), D(null == P || null == (w = P.metadata) ? void 0 : w.version) || (C.$feature_flag_version = P.metadata.version);
                        var O, F = null !== (S = null == P || null == (x = P.reason) ? void 0 : x.description) && void 0 !== S ? S : null == P || null == (E = P.reason) ? void 0 : E.code;
                        F && (C.$feature_flag_reason = F), null != P && null != (k = P.metadata) && k.id && (C.$feature_flag_id = P.metadata.id), D(null == P ? void 0 : P.original_variant) && D(null == P ? void 0 : P.original_enabled) || (C.$feature_flag_original_response = D(P.original_variant) ? P.original_enabled : P.original_variant), null != P && null != (T = P.metadata) && T.original_payload && (C.$feature_flag_original_payload = null == P || null == (O = P.metadata) ? void 0 : O.original_payload), R.length && (C.$feature_flag_error = R.join(",")), this.Zd(C);
                    }
                    else e && this.ni({
                        [Nr]: u,
                        [Lr]: e
                    });
                    if (s) return {
                        key: t,
                        enabled: !!n,
                        variant: "string" == typeof n ? n : void 0,
                        payload: ae(o)
                    };
                }
            } else this.A.warn('getFeatureFlagResult for key "' + t + Hh);
        }
        Zd(t) {
            try {
                var i;
                null == (i = this.Ns) || i.capture("$feature_flag_called", t).catch((t)=>{
                    this.A.error("Failed to capture feature flag call", t);
                });
            } catch (t) {
                this.A.error("Failed to capture feature flag call", t);
            }
        }
        getRemoteConfigPayload(t, i) {
            this.Qd(t, i);
        }
        Qd(t, i) {
            var e = this;
            return p(function*() {
                var r = e.Ns;
                if (r) {
                    var s = {
                        distinct_id: r.distinctId,
                        token: r.projectToken,
                        person_properties: {
                            $lib: r.library.name,
                            $lib_version: r.library.version
                        }
                    }, n = e.Hd();
                    n.length && (s.evaluation_contexts = n);
                    var o, a = e.zd();
                    D(a) || (s.flag_keys = a);
                    try {
                        var l, h = null == (l = (yield r.sendRequest("/flags/?v=2", {
                            target: "flags",
                            method: "POST",
                            body: s,
                            compression: e.mn.compression,
                            sentAt: "body",
                            timeoutMs: e.mn.requestTimeoutMs
                        })).json) ? void 0 : l.featureFlagPayloads;
                        o = (null == h ? void 0 : h[t]) || void 0;
                    } catch (t) {
                        return void e.A.error("Remote config feature flag request failed", t);
                    }
                    try {
                        i(o);
                    } catch (t) {
                        e.A.error("Remote config feature flag callback failed", t);
                    }
                }
            })();
        }
        isFeatureEnabled(t, i) {
            if (void 0 === i && (i = {}), i.fresh && !this.yd) return i.defaultValue;
            if (!(this.vd || this.getFlags() && this.getFlags().length > 0)) return this.A.warn('isFeatureEnabled for key "' + t + Hh), i.defaultValue;
            var e = this.getFeatureFlag(t, i);
            return D(e) ? i.defaultValue : !!e;
        }
        addFeatureFlagsHandler(t) {
            this.featureFlagEventHandlers.push(t);
        }
        removeFeatureFlagsHandler(t) {
            this.featureFlagEventHandlers = this.featureFlagEventHandlers.filter((i)=>i !== t);
        }
        receivedFeatureFlags(t, i, e) {
            this.Ud(t, i, e);
        }
        Ud(t, i, e) {
            if (this.Ns) {
                this.vd = !0;
                var r = function(t, i, e, r, s, n) {
                    void 0 === i && (i = {}), void 0 === e && (e = {}), void 0 === r && (r = {}), void 0 === n && (n = Bh);
                    var o = ((t, i)=>{
                        var e = t.flags;
                        return e ? _({}, t, {
                            featureFlags: Object.fromEntries(Object.keys(e).map((t)=>{
                                var i;
                                return [
                                    t,
                                    null !== (i = e[t].variant) && void 0 !== i ? i : e[t].enabled
                                ];
                            })),
                            featureFlagPayloads: Object.fromEntries(Object.keys(e).filter((t)=>e[t].enabled).filter((t)=>{
                                var i;
                                return !D(null == (i = e[t].metadata) ? void 0 : i.payload);
                            }).map((t)=>{
                                var i;
                                return [
                                    t,
                                    null == (i = e[t].metadata) ? void 0 : i.payload
                                ];
                            }))
                        }) : (t.featureFlags && i.warn("Using an older version of the feature flags endpoint. Please upgrade your PostHog server to the latest version"), t);
                    })(t, n), a = o.flags, l = o.featureFlags, h = o.featureFlagPayloads;
                    if (l) {
                        var u = t.requestId, d = t.evaluatedAt;
                        if (I(l)) {
                            n.warn("v1 of the feature flags endpoint is deprecated. Please use the latest version.");
                            var v = {};
                            if (l) for(var c = 0; l.length > c; c++)v[l[c]] = !0;
                            return {
                                [yr]: l,
                                [br]: v,
                                [kr]: !1
                            };
                        }
                        var f = l, p = h, g = a;
                        if (null != s && s.partialResponse) {
                            var m = Object.keys(f), b = p || {};
                            f = _({}, i, f), p = _({}, e, b), m.forEach((t)=>{
                                var i;
                                t in b || null == (i = p) || delete i[t];
                            }), g = _({}, r, g);
                        } else if (t.errorsWhileComputingFlags) if (a) {
                            var y = new Set(Object.keys(a).filter((t)=>{
                                var i;
                                return !(null != (i = a[t]) && i.failed);
                            }));
                            f = _({}, i, Object.fromEntries(Object.entries(f).filter((t)=>y.has(t[0]))));
                            var w = Object.fromEntries(Object.entries(p || {}).filter((t)=>y.has(t[0])));
                            p = _({}, e, w), y.forEach((t)=>{
                                var i;
                                t in w || null == (i = p) || delete i[t];
                            }), g = _({}, r, Object.fromEntries(Object.entries(g || {}).filter((t)=>y.has(t[0]))));
                        } else f = _({}, i, f), p = _({}, e, p), g = _({}, r, g);
                        return _({
                            [yr]: Object.keys(Wh(f)),
                            [br]: f || {},
                            [xr]: p || {},
                            [Sr]: g || {},
                            [kr]: !0 === t.minimalFlagCalledEvents
                        }, u ? {
                            [Er]: u
                        } : {}, d ? {
                            [Ur]: d
                        } : {});
                    }
                }(t, this.getFlagVariants(), this.getFlagPayloads(), this.getFlagsWithDetails(), e, this.A);
                r && (this.jd(r, t, !(null == e || !e.partialResponse)), this.ni(r)), i || (this.bd = !1), this.Fd(i);
            }
        }
        override(t, i) {
            void 0 === i && (i = !1), this.A.warn("override is deprecated. Please use overrideFeatureFlags instead."), this.overrideFeatureFlags({
                flags: t,
                suppressWarning: i
            });
        }
        overrideFeatureFlags(t) {
            this.Jd(t);
        }
        Jd(t) {
            if (this.Ns) {
                if (!1 === t) return this.oi([
                    Tr,
                    $r
                ]), this.Fd(), void zh.info("All overrides cleared");
                if (I(t)) return this.ni({
                    [Tr]: Vh(t)
                }), this.Fd(), void zh.info("Flag overrides set", {
                    flags: t
                });
                if (t && "object" == typeof t && ("flags" in t || "payloads" in t)) {
                    var i, e = t;
                    this.ld = Boolean(null !== (i = e.suppressWarning) && void 0 !== i && i);
                    var r = {}, s = e.flags, n = e.payloads;
                    return s && (r[Tr] = I(s) ? Vh(s) : s), n && (r[$r] = n), Object.keys(r).length && this.ni(r), !1 === s && !1 === n ? this.oi([
                        Tr,
                        $r
                    ]) : !1 === s ? this.oi(Tr) : !1 === n && this.oi($r), this.Fd(), !1 === s ? zh.info("Flag overrides cleared") : s && zh.info("Flag overrides set", {
                        flags: s
                    }), void (!1 === n ? zh.info("Payload overrides cleared") : n && zh.info("Payload overrides set", {
                        payloads: n
                    }));
                }
                if (t && "object" == typeof t) return this.ni({
                    [Tr]: t
                }), this.Fd(), void zh.info("Flag overrides set", {
                    flags: t
                });
                this.A.warn("Invalid overrideOptions provided to overrideFeatureFlags", {
                    overrideOptions: t
                });
            } else this.A.warn("posthog.featureFlags.overrideFeatureFlags called before feature flags were ready");
        }
        onFeatureFlags(t) {
            if (this.addFeatureFlagsHandler(t), this.vd) {
                var i = this.Kd(), e = i.flags, r = i.flagVariants;
                try {
                    t(e, r);
                } catch (t) {
                    this.A.error("Error while running feature flags callback", t);
                }
            }
            return ()=>this.removeFeatureFlagsHandler(t);
        }
        updateEarlyAccessFeatureEnrollment(t, i, e) {
            var r, s = (this.Nd(wr) || []).find((i)=>i.flagKey === t), n = {
                ["$feature_enrollment/" + t]: i
            }, o = {
                $feature_flag: t,
                $feature_enrollment: i,
                $set: n
            };
            s && (o.$early_access_feature_name = s.name), e && (o.$feature_enrollment_stage = e);
            var a = _({}, this.getFlagVariants(), {
                [t]: i
            });
            null == (r = this._instance) || null == (r = r.persistence) || r.markCrossTabFeatureFlagChanges({
                [yr]: [
                    t
                ],
                [br]: [
                    t
                ],
                [Pr]: Object.keys(n)
            }), this.ni({
                [yr]: Object.keys(Wh(a)),
                [br]: a,
                [Pr]: _({}, this.Nd(Pr) || {}, n)
            }), this.Fd();
            try {
                var l;
                null == (l = this.Ns) || l.capture("$feature_enrollment_update", o).catch((t)=>{
                    this.A.error("Failed to capture early access feature enrollment", t);
                });
            } catch (t) {
                this.A.error("Failed to capture early access feature enrollment", t);
            }
        }
        getEarlyAccessFeatures(t, i, e) {
            void 0 === i && (i = !1);
            var r = this.Nd(wr);
            !r || i ? this.Yd(t, e) : t(r);
        }
        Yd(t, i) {
            var e = this;
            return p(function*() {
                var r = e.Ns;
                if (r) {
                    var s, n = i ? "&" + i.map((t)=>"stage=" + t).join("&") : "";
                    try {
                        var o = yield r.sendRequest("/api/early_access_features/?token=" + r.projectToken + n, {
                            target: "api",
                            method: "GET",
                            sentAt: "query"
                        });
                        if (!o.json) return;
                        e.ni({
                            [wr]: s = o.json.earlyAccessFeatures
                        });
                    } catch (t) {
                        return void e.A.error("Early access feature request failed", t);
                    }
                    try {
                        t(s);
                    } catch (t) {
                        e.A.error("Early access feature callback failed", t);
                    }
                }
            })();
        }
        Kd() {
            var t = this.getFlags(), i = this.getFlagVariants();
            return {
                flags: t.filter((t)=>i[t]),
                flagVariants: Object.keys(i).filter((t)=>i[t]).reduce((t, e)=>(t[e] = i[e], t), {})
            };
        }
        Fd(t) {
            this.Ad();
            var i = this.Kd(), e = i.flags, r = i.flagVariants;
            this.featureFlagEventHandlers.forEach((i)=>{
                try {
                    i(e, r, {
                        errorsLoading: t
                    });
                } catch (t) {
                    this.A.error("Error while running feature flags callback", t);
                }
            });
        }
        setPersonPropertiesForFlags(t, i) {
            void 0 === i && (i = !0), this.Xd(t, i);
        }
        Xd(t, i) {
            void 0 === i && (i = !0);
            var e = this.Nd(Pr) || {}, r = (null == t ? void 0 : t.$set) || (null != t && t.$set_once ? {} : t), s = null == t ? void 0 : t.$set_once, n = {};
            if (s) for(var o in s)({}).hasOwnProperty.call(s, o) && (o in e || (n[o] = s[o]));
            this.ni({
                [Pr]: _({}, e, n, r)
            }), i && this.reloadFeatureFlags();
        }
        unsetPersonPropertiesForFlags(t, i) {
            void 0 === i && (i = !0);
            var e = _({}, this.Nd(Pr) || {});
            t.forEach((t)=>{
                delete e[t];
            }), this.ni({
                [Pr]: e
            }), i && this.reloadFeatureFlags();
        }
        resetPersonPropertiesForFlags(t) {
            void 0 === t && (t = !0), this.oi(Pr), t && this.reloadFeatureFlags();
        }
        setGroupPropertiesForFlags(t, i) {
            void 0 === i && (i = !0);
            var e = this.Nd(Rr) || {}, r = _({}, e);
            for (var s of Object.keys(t))r[s] = _({}, e[s], t[s]);
            this.ni({
                [Rr]: r
            }), i && this.reloadFeatureFlags();
        }
        resetGroupPropertiesForFlags(t) {
            if (t) {
                var i = this.Nd(Rr) || {};
                this.ni({
                    [Rr]: _({}, i, {
                        [t]: {}
                    })
                });
            } else this.oi(Rr);
        }
        reset() {
            this.pd++, this.md = !1, this.ud = {}, this.hd = {}, this.vd = !1, this.gd = !1, this.yd = !1, this.$anon_distinct_id = void 0, this.$d(), this.ld = !1, this._d = 0;
        }
    }
}, hu = {
    sessionRecording: class {
        get mn() {
            return this._instance.config;
        }
        get Bo() {
            return this._instance.persistence;
        }
        get started() {
            var t;
            return !(null == (t = this.tv) || !t.isStarted);
        }
        get status() {
            var t, i;
            return this.ev === ph || this.ev === _h ? this.ev : null !== (t = null == (i = this.tv) ? void 0 : i.status) && void 0 !== t ? t : this.ev;
        }
        constructor(i){
            if (this._forceAllowLocalhostNetworkCapture = !1, this.ev = ch, this.iv = void 0, this.rv = !1, this.jt = (()=>{
                var i;
                if (null == r || !r.visibilityState || "visible" === r.visibilityState) return !0;
                var e = null == t || null == (i = t.performance) || null == i.getEntriesByType ? void 0 : i.getEntriesByType("visibility-state");
                return !(null != e && e.length) || e.some((t)=>"visible" === t.name);
            })(), this.Vt = ()=>{
                var t;
                "visible" === (null == r ? void 0 : r.visibilityState) && (this.jt = !0, null == (t = this.tv) || null == t.setDocumentWasEverVisible || t.setDocumentWasEverVisible(!0));
            }, this._instance = i, !this._instance.sessionManager) throw mh.error("started without valid sessionManager"), new Error(gh + " started without valid sessionManager. This is a bug.");
            if (this.mn.cookieless_mode === is) throw new Error(gh + ' cannot be used with cookieless_mode="always"');
            null != r && r.addEventListener && ys(r, "visibilitychange", this.Vt);
        }
        initialize() {
            this.startIfEnabledOrStop();
        }
        dispose(t) {
            var i = (void 0 === t ? {} : t).discardBufferedEvents, e = void 0 !== i && i;
            this.rv = !0, null == r || null == r.removeEventListener || r.removeEventListener("visibilitychange", this.Vt), e ? this.nv(!0) : this.stopRecording();
        }
        get sv() {
            var i, e = !(null == (i = this._instance.get_property(dr)) || !i.enabled), r = !this.mn.disable_session_recording, s = this.mn.disable_session_recording || this._instance.consent.isOptedOut();
            return t && e && r && !s;
        }
        startIfEnabledOrStop(t) {
            var i;
            if (!(this.rv || this.sv && null != (i = this.tv) && i.isStarted)) {
                var e = !D(Object.assign) && !D(Array.from);
                this.sv && e ? (this.av(t), mh.info("starting")) : (this.ev = ch, this.stopRecording());
            }
        }
        av(t) {
            var i, e;
            if (this.sv) if (this.ev !== ph && this.ev !== _h && (this.ev = fh), null != v && null != (i = v.__PosthogExtensions__) && null != (i = i.rrweb) && i.record && null != (e = v.__PosthogExtensions__) && e.initSessionRecording) this.ov(t);
            else {
                var r, s = this._instance.sessionManager;
                null == (r = v.__PosthogExtensions__) || null == r.loadExternalDependency || r.loadExternalDependency(this._instance, this.lv, (i)=>{
                    if (!this.rv && this.sv && this._instance.sessionManager === s) return i ? (this._instance.register_for_session({
                        [Xr]: !0
                    }), mh.error("could not load recorder", i)) : void this.ov(t);
                    this.ev = ch;
                });
            }
        }
        stopRecording() {
            var t, i;
            null == (t = this.iv) || t.call(this), this.iv = void 0, null == (i = this.tv) || i.stop();
        }
        nv(t) {
            var i, e;
            void 0 === t && (t = !1), null == (i = this.iv) || i.call(this), this.iv = void 0, null == (e = this.tv) || e.discard({
                discardProducerEvents: t
            });
        }
        uv() {
            var t, i;
            null == (t = this.Bo) || t.unregister(mr), null == (i = this.Bo) || i.unregister(vr);
        }
        hv(t, i) {
            if (U(t)) return null;
            var e, r = B(t) ? t : parseFloat(t);
            return "number" != typeof (e = r) || !Number.isFinite(e) || 0 > e || e > 1 ? (mh.warn(i + " must be between 0 and 1. Ignoring invalid value:", t), null) : r;
        }
        dv(t) {
            if (this.Bo) {
                var i, e, r = this.Bo, s = ()=>{
                    var i, e = !1 === t.sessionRecording ? void 0 : t.sessionRecording, s = this.hv(null == (i = this.mn.session_recording) ? void 0 : i.sampleRate, "session_recording.sampleRate"), n = this.hv(null == e ? void 0 : e.sampleRate, "remote config sampleRate"), o = null != s ? s : n;
                    U(o) && this.uv();
                    var a = null == e ? void 0 : e.minimumDurationMilliseconds;
                    r.register({
                        [dr]: _({
                            cache_timestamp: Date.now(),
                            enabled: !!e
                        }, e, {
                            networkPayloadCapture: _({
                                capturePerformance: t.capturePerformance
                            }, null == e ? void 0 : e.networkPayloadCapture),
                            canvasRecording: {
                                enabled: null == e ? void 0 : e.recordCanvas,
                                fps: null == e ? void 0 : e.canvasFps,
                                quality: null == e ? void 0 : e.canvasQuality
                            },
                            sampleRate: o,
                            minimumDurationMilliseconds: D(a) ? null : a,
                            endpoint: null == e ? void 0 : e.endpoint,
                            triggerMatchType: null == e ? void 0 : e.triggerMatchType,
                            masking: null == e ? void 0 : e.masking,
                            urlTriggers: null == e ? void 0 : e.urlTriggers,
                            version: null == e ? void 0 : e.version,
                            triggerGroups: null == e ? void 0 : e.triggerGroups
                        })
                    });
                };
                s(), null == (i = this.iv) || i.call(this), this.iv = null == (e = this._instance.sessionManager) ? void 0 : e.onSessionId(s);
            }
        }
        onRemoteConfig(t) {
            var i = t.ok ? t.config : void 0;
            return i && "sessionRecording" in i ? !1 === i.sessionRecording ? (this.dv(i), void this.nv()) : (this.dv(i), void this.startIfEnabledOrStop()) : (this.ev === ph && (this.ev = _h, mh.warn("config refresh failed, recording will not start until page reload")), void this.startIfEnabledOrStop());
        }
        log(t, i) {
            var e;
            void 0 === i && (i = "log"), null != (e = this.tv) && e.log ? this.tv.log(t, i) : mh.warn("log called before recorder was ready");
        }
        get lv() {
            var t, i, e = null == (t = this._instance) || null == (t = t.persistence) ? void 0 : t.get_property(dr);
            return (null == e || null == (i = e.scriptConfig) ? void 0 : i.script) || "lazy-recorder";
        }
        vv() {
            var t, i = this._instance.get_property(dr);
            if (!i) return !1;
            try {
                t = "object" == typeof i ? i : JSON.parse(i);
            } catch (t) {
                return mh.warn("persisted remote config for session recording is invalid and will be ignored", t), !1;
            }
            return !U(t.cache_timestamp) && 36e5 >= Date.now() - t.cache_timestamp;
        }
        ov(t) {
            var i, e, r;
            if (!this.rv && this.sv && this._instance.sessionManager) {
                if (null == (i = v.__PosthogExtensions__) || !i.initSessionRecording) return mh.warn("Called on script loaded before session recording is available. This can be caused by adblockers."), void this._instance.register_for_session({
                    [Xr]: !0
                });
                var s;
                if (this.tv || (this.tv = null == (s = v.__PosthogExtensions__) ? void 0 : s.initSessionRecording(this._instance, this.jt), this.tv._forceAllowLocalhostNetworkCapture = this._forceAllowLocalhostNetworkCapture), !this.vv()) {
                    if (this.ev === _h || this.ev === ph) return;
                    return this.ev = ph, mh.info("persisted remote config is stale, requesting fresh config before starting"), void new ta(this._instance).load();
                }
                this.ev = fh, null == (e = (r = this.tv).setDocumentWasEverVisible) || e.call(r, this.jt), this.tv.start(t);
            } else this.ev = ch;
        }
        onRRwebEmit(t) {
            var i;
            null == (i = this.tv) || null == i.onRRwebEmit || i.onRRwebEmit(t);
        }
        overrideLinkedFlag() {
            var t, i;
            this.tv || null == (i = this.Bo) || i.register({
                [fr]: !0
            }), null == (t = this.tv) || t.overrideLinkedFlag();
        }
        overrideSampling() {
            var t, i;
            this.tv || null == (i = this.Bo) || i.register({
                [cr]: !0
            }), null == (t = this.tv) || t.overrideSampling();
        }
        overrideTrigger(t) {
            var i, e;
            this.tv || null == (e = this.Bo) || e.register({
                ["url" === t ? pr : _r]: !0
            }), null == (i = this.tv) || i.overrideTrigger(t);
        }
        get sdkDebugProperties() {
            var t;
            return (null == (t = this.tv) ? void 0 : t.sdkDebugProperties) || {
                $recording_status: this.status
            };
        }
        tryAddCustomEvent(t, i) {
            var e;
            return !(null == (e = this.tv) || !e.tryAddCustomEvent(t, i));
        }
    }
}, uu = {
    autocapture: class extends ih {
        constructor(t){
            super(new eh(t)), this.instance = t;
        }
    },
    historyAutocapture: class {
        constructor(t){
            this._instance = t, this.fv = this.pv();
        }
        initialize() {
            this.startIfEnabled();
        }
        get isEnabled() {
            var t = this.gv();
            return !!(t.path || t.search || this.mv(t));
        }
        startIfEnabled() {
            this.isEnabled && (Ue.info("History API monitoring enabled, starting..."), this.monitorHistoryChanges());
        }
        startIfEnabledOrStop() {
            this.stop(), this.fv = this.pv(), this.startIfEnabled();
        }
        stop() {
            this.yv && this.yv(), this.yv = void 0, this.bv && this.bv(), this.bv = void 0, Ue.info("History API monitoring stopped");
        }
        monitorHistoryChanges() {
            t && t.history && (this._v("pushState"), this._v("replaceState"), this.wv(), this.mv() && this.Sv());
        }
        _v(i) {
            var e;
            if (t && (null == (e = t.history[i]) || !e.__posthog_wrapped__)) {
                var r = this;
                oh(t.history, i, (t)=>function(e, s, n) {
                        t.call(this, e, s, n), r.xv(i);
                    });
            }
        }
        pv() {
            var i = null == t ? void 0 : t.location;
            if (null != i && i.pathname) return {
                pathname: i.pathname,
                search: i.search,
                hash: i.hash
            };
        }
        gv() {
            var t = this._instance.config.capture_pageview;
            return "history_change" === t ? {
                path: !0
            } : A(t) ? t : {};
        }
        mv(t) {
            return void 0 === t && (t = this.gv()), !!t.hash && !this._instance.config.disable_capture_url_hashes;
        }
        Cv(t) {
            var i = this.gv(), e = this.fv;
            return !(!e || !(i.path && t.pathname !== e.pathname || i.search && t.search !== e.search || this.mv(i) && t.hash !== e.hash));
        }
        xv(t) {
            try {
                var i = this.pv();
                if (!i) return;
                this.Cv(i) && this._instance.capture(as, {
                    navigation_type: t
                }), this.fv = i;
            } catch (i) {
                Ue.error("Error capturing " + t + " pageview", i);
            }
        }
        wv() {
            if (!this.yv) {
                var i = ()=>{
                    this.xv("popstate");
                };
                ys(t, "popstate", i), this.yv = ()=>{
                    t && t.removeEventListener("popstate", i);
                };
            }
        }
        Sv() {
            if (!this.bv) {
                var i = ()=>{
                    this.xv("hashchange");
                };
                ys(t, "hashchange", i), this.bv = ()=>{
                    t && t.removeEventListener("hashchange", i);
                };
            }
        }
    },
    heatmaps: class {
        get mn() {
            return this.instance.config;
        }
        constructor(t){
            var i;
            this.Tv = !1, this.Rs = !1, this.Mv = null, this.instance = t, this.Tv = !(null == (i = this.instance.persistence) || !i.props[er]), this.rageclicks = new Kl(t.config.rageclick);
        }
        initialize() {
            this.startIfEnabled();
        }
        get flushIntervalMilliseconds() {
            var t = 5e3;
            return A(this.mn.capture_heatmaps) && this.mn.capture_heatmaps.flush_interval_milliseconds && (t = this.mn.capture_heatmaps.flush_interval_milliseconds), t;
        }
        get isEnabled() {
            return U(this.mn.capture_heatmaps) ? U(this.mn.enable_heatmaps) ? this.Tv : this.mn.enable_heatmaps : !1 !== this.mn.capture_heatmaps;
        }
        startIfEnabled() {
            if (this.isEnabled) {
                if (this.Rs) return;
                bh.info("starting..."), this.Iv(), this.Vt();
            } else {
                var t;
                clearInterval(null !== (t = this.Mv) && void 0 !== t ? t : void 0), this.Ev(), this.getAndClearBuffer();
            }
        }
        onRemoteConfig(t) {
            if (t.ok) {
                var i = t.config;
                if ("heatmaps" in i) {
                    var e = !!i.heatmaps;
                    this.instance.persistence && this.instance.persistence.register({
                        [er]: e
                    }), this.Tv = e, this.startIfEnabled();
                }
            }
        }
        getAndClearBuffer() {
            var t = this.Pt;
            return this.Pt = void 0, t;
        }
        Rv(t) {
            yh(t.originalEvent) && this.Xi(t.originalEvent, "deadclick");
        }
        Vt() {
            this.Mv && clearInterval(this.Mv), this.Mv = "visible" === (null == r ? void 0 : r.visibilityState) ? setInterval(this.Po.bind(this), this.flushIntervalMilliseconds) : null;
        }
        Iv() {
            t && r && (this.Pv = this.Po.bind(this), ys(t, os, this.Pv), this.Av = (i)=>this.Xi(i || (null == t ? void 0 : t.event)), ys(r, "click", this.Av, {
                capture: !0
            }), this.Fv = (i)=>this.Ov(i || (null == t ? void 0 : t.event)), ys(r, "mousemove", this.Fv, {
                capture: !0
            }), this.Lv = new qn(this.instance, zn, this.Rv.bind(this)), this.Lv.startIfEnabledOrStop(), this.Dv = this.Vt.bind(this), ys(r, ns, this.Dv), this.Rs = !0);
        }
        Ev() {
            var i;
            t && r && (this.Pv && t.removeEventListener(os, this.Pv), this.Av && r.removeEventListener("click", this.Av, {
                capture: !0
            }), this.Fv && r.removeEventListener("mousemove", this.Fv, {
                capture: !0
            }), this.Dv && r.removeEventListener(ns, this.Dv), clearTimeout(this.$v), null == (i = this.Lv) || i.stop(), this.Rs = !1);
        }
        Nv(i, e) {
            var r = this.instance.scrollManager.scrollY(), s = this.instance.scrollManager.scrollX(), n = this.instance.scrollManager.scrollElement(), o = function(i, e, r) {
                for(var s = i; s && sn(s) && !nn(s, "body");){
                    if (s === r) return !1;
                    var n = void 0;
                    try {
                        var o, a, l;
                        n = null == (o = null !== (a = null == (l = s.ownerDocument) ? void 0 : l.defaultView) && void 0 !== a ? a : t) ? void 0 : o.getComputedStyle(s).position;
                    } catch (t) {
                        return !1;
                    }
                    if (y(e, n)) return !0;
                    s = gn(s);
                }
                return !1;
            }(fn(i), [
                "fixed",
                "sticky"
            ], n);
            return {
                x: i.clientX + (o ? 0 : s),
                y: i.clientY + (o ? 0 : r),
                target_fixed: o,
                type: e
            };
        }
        Xi(t, i) {
            var e;
            if (void 0 === i && (i = "click"), !rn(t.target) && yh(t)) {
                var r = this.Nv(t, i);
                null != (e = this.rageclicks) && e.isRageClick(t.clientX, t.clientY, (new Date).getTime()) && En(fn(t), this.instance.config.rageclick) && this.ks(_({}, r, {
                    type: "rageclick"
                })), this.ks(r);
            }
        }
        Ov(t) {
            !rn(t.target) && yh(t) && (clearTimeout(this.$v), this.$v = setTimeout(()=>{
                this.ks(this.Nv(t, "mousemove"));
            }, 500));
        }
        ks(i) {
            if (t) {
                var e = this.mn.disable_capture_url_hashes ? Ti(t.location.href) : t.location.href, r = this.mn.custom_personal_data_properties, s = this.mn.mask_personal_data_properties ? [
                    ...ho,
                    ...r || []
                ] : [], n = so(e, s, vo);
                this.Pt = this.Pt || {}, this.Pt[n] || (this.Pt[n] = []), this.Pt[n].push(i);
            }
        }
        Po() {
            this.Pt && !M(this.Pt) && this.instance.capture("$$heatmap", {
                $heatmap_data: this.getAndClearBuffer()
            });
        }
    },
    deadClicksAutocapture: qn,
    webVitalsAutocapture: class {
        constructor(t){
            var i;
            this.Tv = !1, this.Rs = !1, this.Pt = {
                navigationKey: void 0,
                url: void 0,
                metrics: [],
                firstMetricTimestamp: void 0
            }, this.qv = ()=>{
                clearTimeout(this.jv), this.jv = void 0, 0 !== this.Pt.metrics.length && (this._instance.capture("$web_vitals", _({
                    $current_url: this.Pt.url
                }, this.Pt.metrics.reduce((t, i)=>_({}, t, {
                        ["$web_vitals_" + i.name + "_event"]: _({}, i),
                        ["$web_vitals_" + i.name + "_value"]: i.value
                    }), {}))), this.Pt = {
                    navigationKey: void 0,
                    url: void 0,
                    metrics: [],
                    firstMetricTimestamp: void 0
                });
            }, this.Bv = (t)=>{
                var i;
                if (this.Pt = this.Pt || {
                    navigationKey: void 0,
                    url: void 0,
                    metrics: [],
                    firstMetricTimestamp: void 0
                }, U(null == t ? void 0 : t.name) || U(null == t ? void 0 : t.value)) lh.error("Invalid metric received", t);
                else {
                    var e = "string" == typeof t.navigationURL ? t.navigationURL : void 0, r = this.Hv(e);
                    if (!D(r)) {
                        var s = B(t.navigationId) || "string" == typeof t.navigationId ? "navigation:" + t.navigationId : "url:" + r;
                        if (!this.zv || this.zv > t.value) {
                            this.Pt.navigationKey !== s && (this.qv(), this.jv = setTimeout(this.qv, this.flushToCaptureTimeoutMs)), D(this.Pt.navigationKey) && (this.Pt.navigationKey = s, this.Pt.url = r), this.Pt.firstMetricTimestamp = D(this.Pt.firstMetricTimestamp) ? Date.now() : this.Pt.firstMetricTimestamp;
                            var n = null == (i = this._instance.sessionManager) ? void 0 : i.checkAndGetSessionAndWindowId(!0), o = _({}, t, e ? {
                                navigationURL: r
                            } : {}, {
                                $current_url: r,
                                timestamp: Date.now()
                            });
                            if (delete o.entries, A(t.attribution) && this.attributionMetrics.indexOf(t.name) > -1) {
                                var a = {};
                                for (var l of vh){
                                    var h = "url" === l && "string" == typeof t.attribution[l] ? this.Hv(t.attribution[l]) : t.attribution[l];
                                    D(h) || (a[l] = h);
                                }
                                o.attribution = a;
                            } else delete o.attribution;
                            D(n) || (o.$session_id = n.sessionId, o.$window_id = n.windowId), this.Pt.metrics.push(o), this.Pt.metrics.length === this.allowedMetrics.length && this.qv();
                        } else lh.error("Ignoring metric with value >= " + this.zv, t);
                    }
                }
            }, this.Uv = ()=>{
                if (!this.Rs) {
                    var t, i, e, r, s = !1, n = v.__PosthogExtensions__, o = null == n ? void 0 : n.postHogWebVitalsCallbacksByFlavor, a = (null == o ? void 0 : o[this.Wv]) || ("web-vitals" === this.Wv && D(o) ? null == n ? void 0 : n.postHogWebVitalsCallbacks : void 0);
                    if (!D(a)) {
                        var l = a.withoutAttribution, h = this.attributionMetrics;
                        s = !D(l), t = h.indexOf("LCP") > -1 ? a.onLCP : (null == l ? void 0 : l.onLCP) || a.onLCP, i = h.indexOf("CLS") > -1 ? a.onCLS : (null == l ? void 0 : l.onCLS) || a.onCLS, e = h.indexOf("FCP") > -1 ? a.onFCP : (null == l ? void 0 : l.onFCP) || a.onFCP, r = h.indexOf("INP") > -1 ? a.onINP : (null == l ? void 0 : l.onINP) || a.onINP;
                    }
                    if (t && i && e && r) {
                        var u = {
                            reportSoftNavs: this.useSoftNavs
                        }, d = s && this.attributionMetrics.indexOf("INP") > -1 ? _({}, u, {
                            includeProcessedEventEntries: !1
                        }) : u;
                        this.allowedMetrics.indexOf("LCP") > -1 && t(this.Bv.bind(this), u), this.allowedMetrics.indexOf("CLS") > -1 && i(this.Bv.bind(this), u), this.allowedMetrics.indexOf("FCP") > -1 && e(this.Bv.bind(this), u), this.allowedMetrics.indexOf("INP") > -1 && r(this.Bv.bind(this), d), this.Rs = !0;
                    } else lh.error("web vitals callbacks not loaded - not starting");
                }
            }, this._instance = t, this.Tv = !(null == (i = this._instance.persistence) || !i.props[or]), this.startIfEnabled();
        }
        get Vv() {
            return this._instance.config.capture_performance;
        }
        get allowedMetrics() {
            var t, i, e = A(this.Vv) ? null == (t = this.Vv) ? void 0 : t.web_vitals_allowed_metrics : void 0;
            return U(e) ? (null == (i = this._instance.persistence) ? void 0 : i.props[ur]) || uh : e;
        }
        get flushToCaptureTimeoutMs() {
            return (A(this.Vv) ? this.Vv.web_vitals_delayed_flush_ms : void 0) || 5e3;
        }
        get attributionMetrics() {
            var t = A(this.Vv) ? this.Vv.web_vitals_attribution : void 0;
            return H(t) ? t ? uh : [] : I(t) ? t : dh;
        }
        get useAttribution() {
            return this.attributionMetrics.length > 0;
        }
        get useSoftNavs() {
            var t = A(this.Vv) ? this.Vv.__preview_web_vitals_soft_navs : void 0;
            return null != t && t;
        }
        get zv() {
            var t = A(this.Vv) && B(this.Vv.__web_vitals_max_value) ? this.Vv.__web_vitals_max_value : hh;
            return t > 0 && 6e4 >= t ? hh : t;
        }
        get isEnabled() {
            var t = null == s ? void 0 : s.protocol;
            if ("http:" !== t && "https:" !== t) return lh.info("Web Vitals are disabled on non-http/https protocols"), !1;
            var i = A(this.Vv) ? this.Vv.web_vitals : H(this.Vv) ? this.Vv : void 0;
            return H(i) ? i : this.Tv;
        }
        startIfEnabled() {
            this.isEnabled && !this.Rs && (lh.info("enabled, starting..."), this.Ys(this.Uv));
        }
        onRemoteConfig(t) {
            if (t.ok) {
                var i = t.config;
                if ("capturePerformance" in i) {
                    var e = A(i.capturePerformance) && !!i.capturePerformance.web_vitals, r = A(i.capturePerformance) ? i.capturePerformance.web_vitals_allowed_metrics : void 0;
                    this._instance.persistence && (this._instance.persistence.register({
                        [or]: e
                    }), this._instance.persistence.register({
                        [ur]: r
                    })), this.Tv = e, this.startIfEnabled();
                }
            }
        }
        get Wv() {
            return this.useSoftNavs ? this.useAttribution ? "web-vitals-with-attribution-soft-navs" : "web-vitals-soft-navs" : this.useAttribution ? "web-vitals-with-attribution" : "web-vitals";
        }
        Ys(t) {
            var i = v.__PosthogExtensions__, e = this.Wv, r = null == i ? void 0 : i.postHogWebVitalsCallbacksByFlavor;
            null != r && r[e] || "web-vitals" === e && D(r) && null != i && i.postHogWebVitalsCallbacks ? t() : null == i || null == i.loadExternalDependency || i.loadExternalDependency(this._instance, e, (i)=>{
                i ? lh.error("failed to load script", i) : t();
            });
        }
        Hv(i) {
            var e = i || (null == t ? void 0 : t.location.href);
            if (e) {
                var r = this._instance.config.disable_capture_url_hashes ? Ti(e) : e, s = this._instance.config.custom_personal_data_properties, n = this._instance.config.mask_personal_data_properties ? [
                    ...ho,
                    ...s || []
                ] : [];
                return so(r, n, vo);
            }
            lh.error("Could not determine current URL");
        }
    }
}, du = {
    exceptionObserver: class {
        constructor(i){
            var e;
            this.Uv = ()=>{
                var i;
                if (t && this.isEnabled && null != (i = v.__PosthogExtensions__) && i.errorWrappingFunctions) {
                    var e = v.__PosthogExtensions__.errorWrappingFunctions.wrapOnError, r = v.__PosthogExtensions__.errorWrappingFunctions.wrapUnhandledRejection, s = v.__PosthogExtensions__.errorWrappingFunctions.wrapConsoleError;
                    try {
                        !this.Gv && this.mn.capture_unhandled_errors && (this.Gv = e(this.captureException.bind(this))), !this.Zv && this.mn.capture_unhandled_rejections && (this.Zv = r(this.captureException.bind(this))), !this.Qv && this.mn.capture_console_errors && (this.Qv = s(this.captureException.bind(this)));
                    } catch (t) {
                        rh.error("failed to start", t), this.Jv();
                    }
                }
            }, this._instance = i, this.Kv = !(null == (e = this._instance.persistence) || !e.props[rr]), this.pe = new et(_({}, function(t) {
                var i, e, r, s;
                return void 0 === t && (t = {}), {
                    refillRate: null !== (i = null !== (e = t.exceptionRateLimiterRefillRate) && void 0 !== e ? e : t.__exceptionRateLimiterRefillRate) && void 0 !== i ? i : 1,
                    bucketSize: null !== (r = null !== (s = t.exceptionRateLimiterBucketSize) && void 0 !== s ? s : t.__exceptionRateLimiterBucketSize) && void 0 !== r ? r : 10
                };
            }(this._instance.config.error_tracking), {
                refillInterval: 1e4,
                A: rh
            })), this.mn = this.Yv(), this.startIfEnabledOrStop();
        }
        Yv() {
            var t = this._instance.config.capture_exceptions, i = {
                capture_unhandled_errors: !1,
                capture_unhandled_rejections: !1,
                capture_console_errors: !1
            };
            return A(t) ? i = _({}, i, t) : (D(t) ? this.Kv : t) && (i = _({}, i, {
                capture_unhandled_errors: !0,
                capture_unhandled_rejections: !0
            })), i;
        }
        get isEnabled() {
            return this.mn.capture_console_errors || this.mn.capture_unhandled_errors || this.mn.capture_unhandled_rejections;
        }
        startIfEnabledOrStop() {
            this.isEnabled ? (rh.info("enabled"), this.Jv(), this.Ys(this.Uv)) : this.Jv();
        }
        Ys(t) {
            var i, e;
            null != (i = v.__PosthogExtensions__) && i.errorWrappingFunctions ? t() : null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this._instance, "exception-autocapture", (i)=>{
                if (i) return rh.error("failed to load script", i);
                t();
            });
        }
        Jv() {
            var t, i, e;
            null == (t = this.Gv) || t.call(this), this.Gv = void 0, null == (i = this.Zv) || i.call(this), this.Zv = void 0, null == (e = this.Qv) || e.call(this), this.Qv = void 0;
        }
        onRemoteConfig(t) {
            if (t.ok) {
                var i = t.config;
                "autocaptureExceptions" in i && (this.Kv = !!i.autocaptureExceptions || !1, this._instance.persistence && this._instance.persistence.register({
                    [rr]: this.Kv
                }), this.mn = this.Yv(), this.startIfEnabledOrStop());
            }
        }
        onConfigChange() {
            this.mn = this.Yv();
        }
        captureException(t) {
            var i, e, r, s = null !== (i = null == t || null == (e = t.$exception_list) || null == (e = e[0]) ? void 0 : e.type) && void 0 !== i ? i : "Exception";
            this.pe.consumeRateLimit(s) ? rh.info("Skipping exception capture because of client rate limiting.", {
                exception: s
            }) : null == (r = this._instance.exceptions) || r.sendExceptionEvent(t);
        }
    },
    exceptions: class {
        constructor(t){
            var i, e;
            this.Xv = [], this.tc = new Oi([
                new Hi,
                new Zi,
                new Vi,
                new qi,
                new Qi,
                new Yi,
                new Gi,
                new Xi
            ], function(t) {
                for(var i = arguments.length, e = new Array(i > 1 ? i - 1 : 0), r = 1; i > r; r++)e[r - 1] = arguments[r];
                return function(i, r) {
                    void 0 === r && (r = 0);
                    for(var s = [], n = i.split("\n"), o = r; n.length > o; o++){
                        var a = n[o];
                        if (1024 >= a.length) {
                            var l = zi.test(a) ? a.replace(zi, "$1") : a;
                            if (!l.match(/\S*Error: /)) {
                                for (var h of e){
                                    var u = h(l, t);
                                    if (u) {
                                        s.push(u);
                                        break;
                                    }
                                }
                                if (s.length >= 50) break;
                            }
                        }
                    }
                    return function(t) {
                        if (!t.length) return [];
                        var i = Array.from(t);
                        return i.reverse(), i.slice(0, 50).map((t)=>{
                            return _({}, t, {
                                filename: t.filename || (e = i, e[e.length - 1] || {}).filename,
                                function: t.function || Ii
                            });
                            //TURBOPACK unreachable
                            ;
                            var e;
                        });
                    }(s);
                };
            }("web:javascript", Li, Bi)), this._instance = t, this.Xv = null !== (i = null == (e = this._instance.persistence) ? void 0 : e.get_property(sr)) && void 0 !== i ? i : [], this.ec = se(this.ic()), this.rc = new ne(this.ec);
        }
        onConfigChange() {
            this.ec = se(this.ic()), this.rc.setConfig(this.ec);
        }
        onRemoteConfig(t) {
            var i, e, r;
            if (t.ok) {
                var s = t.config;
                if ("errorTracking" in s) {
                    var n = null !== (i = null == (e = s.errorTracking) ? void 0 : e.suppressionRules) && void 0 !== i ? i : [], o = null == (r = s.errorTracking) ? void 0 : r.captureExtensionExceptions;
                    this.Xv = n, this._instance.persistence && this._instance.persistence.register({
                        [sr]: this.Xv,
                        [nr]: o
                    });
                }
            }
        }
        get nc() {
            var t, i = !!this._instance.get_property(nr), e = this._instance.config.error_tracking.captureExtensionExceptions;
            return null !== (t = null != e ? e : i) && void 0 !== t && t;
        }
        buildProperties(t, i) {
            return this.tc.buildFromUnknown(t, {
                syntheticException: null == i ? void 0 : i.syntheticException,
                mechanism: {
                    handled: null == i ? void 0 : i.handled
                }
            });
        }
        addExceptionStep(t, i) {
            if (this.ec.enabled) try {
                if (!N(t) || 0 === t.trim().length) return void Gh.warn("Ignoring exception step because message must be a non-empty string");
                var e = function(t) {
                    if (!t) return {
                        sanitizedProperties: {},
                        droppedKeys: []
                    };
                    var i = [];
                    return {
                        sanitizedProperties: Object.keys(t).reduce((e, r)=>ee.has(r) ? (i.push(r), e) : (e[r] = t[r], e), {}),
                        droppedKeys: i
                    };
                }(this.sc(i)), r = e.sanitizedProperties, s = e.droppedKeys;
                s.length > 0 && Gh.warn("Ignoring reserved exception step fields", {
                    droppedKeys: s
                }), this.rc.add(_({
                    [te]: t,
                    [ie]: (new Date).toISOString()
                }, r));
            } catch (t) {
                Gh.error("Failed to add exception step. Ignoring breadcrumb.", t);
            }
        }
        sendExceptionEvent(t) {
            try {
                var i = t.$exception_list;
                if (this.ac(i)) {
                    if (this.oc(i)) return this.lc("Exception dropped: matched a suppression rule"), void Gh.info("Skipping exception capture because a suppression rule matched");
                    if (!this.nc && this.uc(i)) return this.lc("Exception dropped: thrown by a browser extension"), void Gh.info("Skipping exception capture because it was thrown by an extension");
                    if (!this.nc && this.hc(i)) return this.lc("Exception dropped: thrown by an injected browser script"), void Gh.info("Skipping exception capture because it was thrown by an injected browser script");
                    if (!this._instance.config.error_tracking.__capturePostHogExceptions && this.dc(i)) return this.lc("Exception dropped: thrown by the PostHog SDK"), void Gh.info("Skipping exception capture because it was thrown by the PostHog SDK");
                }
                var e = this.ec.enabled && U(t.$exception_steps) ? this.vc(t) : t, r = "string" == typeof (n = globalThis._posthogReleaseId) && n.length > 0 ? n : void 0;
                r && (e.$release_id = r);
                try {
                    var s = this._instance.capture("$exception", e, {
                        _noTruncate: !0,
                        _batchKey: "exceptionEvent",
                        gu: !0
                    });
                    return s && this.rc.clear(), s;
                } catch (t) {
                    return Gh.error("Failed to capture exception event. Dropping this exception.", t), void this.rc.clear();
                }
            } catch (t) {
                return void Gh.error("Failed to process exception event. Ignoring this exception.", t);
            }
            var n;
        }
        vc(t) {
            try {
                var i = this.rc.getAttachable();
                return 0 === i.length ? t : _({}, t, {
                    $exception_steps: i
                });
            } catch (i) {
                return Gh.error("Failed to read buffered exception steps. Capturing exception without steps.", i), t;
            }
        }
        lc(t) {
            this.ec.enabled && this.rc.add({
                [te]: t,
                [ie]: (new Date).toISOString()
            });
        }
        sc(t) {
            return A(t) ? _({}, t) : {};
        }
        ic() {
            var t, i;
            return null !== (t = null == (i = this._instance.config.error_tracking) ? void 0 : i.exception_steps) && void 0 !== t ? t : {};
        }
        oc(t) {
            if (0 === t.length) return !1;
            try {
                var i = t.reduce((t, i)=>{
                    var e = i.type, r = i.value;
                    return N(e) && e.length > 0 && t.$exception_types.push(e), N(r) && r.length > 0 && t.$exception_values.push(r), t;
                }, {
                    $exception_types: [],
                    $exception_values: []
                });
                return this.Xv.some((t)=>{
                    var e = t.values.map((t)=>{
                        var e = dl[t.operator], r = i[t.key];
                        if (!e || !r) return !1;
                        var s = I(t.value) ? t.value : [
                            t.value
                        ];
                        return s.length > 0 && e(s, r);
                    });
                    return "OR" === t.type ? e.some(Boolean) : e.every(Boolean);
                });
            } catch (t) {
                return Gh.warn("Failed to evaluate suppression rules. Capturing the exception.", t), !1;
            }
        }
        uc(t) {
            var i = t.flatMap((t)=>{
                var i, e;
                return null !== (i = null == (e = t.stacktrace) ? void 0 : e.frames) && void 0 !== i ? i : [];
            }), e = i.filter((t)=>{
                var i = t.filename;
                return !!i && Kh.some((t)=>i.startsWith(t));
            });
            return 0 !== e.length && (!e.every((t)=>{
                var i = t.filename;
                return !!i && i.startsWith(Jh);
            }) || t.some((t)=>{
                var i = t.value;
                return N(i) && i.includes("isolatedAPI.contexts.topHostname");
            }) && !i.some((t)=>{
                var i = t.filename;
                return t.in_app && !(null != i && i.startsWith(Jh));
            }));
        }
        hc(t) {
            return t.some((t)=>{
                var i = t.value;
                return N(i) && Yh.some((t)=>i.includes(t));
            });
        }
        dc(t) {
            if (t.length > 0) {
                var i, e, r, s, n = null !== (i = null == (e = t[0].stacktrace) ? void 0 : e.frames) && void 0 !== i ? i : [], o = n[n.length - 1];
                return null !== (r = null == o || null == (s = o.filename) ? void 0 : s.includes("posthog.com/static")) && void 0 !== r && r;
            }
            return !1;
        }
        ac(t) {
            return !U(t) && I(t);
        }
    }
}, vu = _({
    productTours: class {
        get Bo() {
            return this._instance.persistence;
        }
        constructor(t){
            this.cc = null, this.fc = null, this._instance = t;
        }
        initialize() {
            this.loadIfEnabled();
        }
        onRemoteConfig(t) {
            if (t.ok) {
                var i = t.config;
                if ("productTours" in i) {
                    var e, r;
                    if (this.Bo && this.Bo.register({
                        [lr]: !!i.productTours
                    }), !Sh(this._instance)) return !this.cc && U(null == (e = this.Bo) ? void 0 : e.props[Dr]) || wh.info("product tours disabled; stopping and clearing cached tours"), null == (r = this.cc) || r.stop(), this.cc = null, void this.clearCache();
                    this.loadIfEnabled();
                }
            }
        }
        loadIfEnabled() {
            !this.cc && Sh(this._instance) && this.Ys(()=>this.gc());
        }
        Ys(t) {
            var i, e;
            null != (i = v.__PosthogExtensions__) && i.generateProductTours ? t() : null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this._instance, "product-tours", (i)=>{
                i ? wh.error("Could not load product tours script", i) : t();
            });
        }
        gc() {
            var t;
            !this.cc && null != (t = v.__PosthogExtensions__) && t.generateProductTours && (this.cc = v.__PosthogExtensions__.generateProductTours(this._instance, !0));
        }
        getProductTours(t, i) {
            if (void 0 === i && (i = !1), !I(this.fc) || i) {
                var e = this.Bo;
                if (e) {
                    var r = e.props[Dr];
                    if (I(r) && !i) return this.fc = r, void t(r, {
                        isLoaded: !0
                    });
                }
                this._instance._send_request({
                    url: this._instance.requestRouter.endpointFor("api", "/api/product_tours/?token=" + this._instance.config.token),
                    method: "GET",
                    timestampMode: "query",
                    callback: (i)=>{
                        if (Sh(this._instance)) {
                            var r = i.statusCode;
                            if (200 !== r || !i.json) {
                                var s = "Product Tours API could not be loaded, status: " + r;
                                return 0 === r ? i.error || wh.warn(s) : wh.error(s), void t([], {
                                    isLoaded: !1,
                                    error: s
                                });
                            }
                            var n = I(i.json.product_tours) ? i.json.product_tours : [];
                            this.fc = n, e && e.register({
                                [Dr]: n
                            }), t(n, {
                                isLoaded: !0
                            });
                        } else t([], {
                            isLoaded: !0
                        });
                    }
                });
            } else t(this.fc, {
                isLoaded: !0
            });
        }
        getActiveProductTours(t) {
            U(this.cc) ? t([], {
                isLoaded: !1,
                error: "Product tours not loaded"
            }) : this.cc.getActiveProductTours(t);
        }
        showProductTour(t) {
            var i;
            null == (i = this.cc) || i.showTourById(t);
        }
        previewTour(t) {
            this.cc ? this.cc.previewTour(t) : this.Ys(()=>{
                var i;
                this.gc(), null == (i = this.cc) || i.previewTour(t);
            });
        }
        dismissProductTour() {
            var t;
            null == (t = this.cc) || t.dismissTour("user_clicked_skip");
        }
        nextStep() {
            var t;
            null == (t = this.cc) || t.nextStep();
        }
        previousStep() {
            var t;
            null == (t = this.cc) || t.previousStep();
        }
        clearCache() {
            var t;
            this.fc = null, null == (t = this.Bo) || t.unregister(Dr);
        }
        resetTour(t) {
            var i;
            null == (i = this.cc) || i.resetTour(t);
        }
        resetAllTours() {
            var t;
            null == (t = this.cc) || t.resetAllTours();
        }
        cancelPendingTour(t) {
            var i;
            null == (i = this.cc) || i.cancelPendingTour(t);
        }
    }
}, lu), cu = {
    siteApps: class {
        constructor(t){
            this.mc = 0, this._instance = t, this.yc = [], this.apps = {};
        }
        get isEnabled() {
            return !!this._instance.config.opt_in_site_apps;
        }
        bc(t, i) {
            if (i) {
                var e = this.globalsForEvent(i);
                this.yc.push(e), this.yc.length > 1e3 && (this.yc = this.yc.slice(10));
            }
        }
        get siteAppLoaders() {
            var t;
            return null == (t = v._POSTHOG_REMOTE_CONFIG) || null == (t = t[this._instance.config.token]) ? void 0 : t.siteApps;
        }
        initialize() {
            if (this.isEnabled) {
                var t = this._instance._addCaptureHook(this.bc.bind(this));
                this._c = ()=>{
                    t(), this.yc = [], this._c = void 0;
                };
            }
        }
        globalsForEvent(t) {
            var i, e, r, s, n, o, a;
            if (!t) throw new Error("Event payload is required");
            var l = {}, h = this._instance.get_property("$groups") || [], u = this._instance.get_property("$stored_group_properties") || {};
            for (var d of Object.entries(u)){
                var v = d[0];
                l[v] = {
                    id: h[v],
                    type: v,
                    properties: d[1]
                };
            }
            var c = t.$set_once, f = t.$set;
            return {
                event: _({}, g(t, xh), {
                    properties: _({}, t.properties, f ? {
                        $set: _({}, null !== (i = null == (e = t.properties) ? void 0 : e.$set) && void 0 !== i ? i : {}, f)
                    } : {}, c ? {
                        $set_once: _({}, null !== (r = null == (s = t.properties) ? void 0 : s.$set_once) && void 0 !== r ? r : {}, c)
                    } : {}),
                    elements_chain: null !== (n = null == (o = t.properties) ? void 0 : o.$elements_chain) && void 0 !== n ? n : "",
                    distinct_id: null == (a = t.properties) ? void 0 : a.distinct_id
                }),
                person: {
                    properties: this._instance.get_property("$stored_person_properties")
                },
                groups: l
            };
        }
        wc(t) {
            var i, e = null == (i = t.tagName) ? void 0 : i.toLowerCase();
            return "style" === e && this._instance.config.prepare_external_dependency_stylesheet ? this._instance.config.prepare_external_dependency_stylesheet(t) || (Eh.error("prepare_external_dependency_stylesheet returned null"), null) : "script" === e && this._instance.config.prepare_external_dependency_script ? this._instance.config.prepare_external_dependency_script(t) || (Eh.error("prepare_external_dependency_script returned null"), null) : t;
        }
        kc() {
            var t, i, e, s, n, o, a, l;
            if (!this._instance.config.prepare_external_dependency_stylesheet && !this._instance.config.prepare_external_dependency_script) return ()=>{};
            var h = null == r ? void 0 : r.defaultView, u = null == h || null == (t = h.Node) ? void 0 : t.prototype;
            if (!h || !u) return ()=>{};
            if (this.mc++, this.Sc) return this.xc();
            var d = [], v = this, c = new WeakSet, f = (t, i, e)=>{
                if (null != t && t[i]) {
                    var r = t[i];
                    t[i] = e(r), d.push(()=>{
                        t[i] = r;
                    });
                }
            }, p = (t)=>{
                if (c.has(t)) return t;
                var i = v.wc(t);
                return i && c.add(i), i;
            }, _ = (t)=>t.map((t)=>"string" == typeof t ? t : p(t)).filter((t)=>!j(t));
            return f(u, "appendChild", (t)=>function(i) {
                    var e = p(i);
                    return e ? t.call(this, e) : i;
                }), f(u, "insertBefore", (t)=>function(i, e) {
                    var r = p(i);
                    return r ? t.call(this, r, e) : i;
                }), f(u, "replaceChild", (t)=>function(i, e) {
                    var r = p(i);
                    return r ? t.call(this, r, e) : e;
                }), [
                null == (i = h.Element) ? void 0 : i.prototype,
                null == (e = h.Document) ? void 0 : e.prototype,
                null == (s = h.DocumentFragment) ? void 0 : s.prototype
            ].forEach((t)=>{
                f(t, "append", (t)=>function() {
                        for(var i = arguments.length, e = new Array(i), r = 0; i > r; r++)e[r] = arguments[r];
                        return t.apply(this, _(e));
                    }), f(t, "prepend", (t)=>function() {
                        for(var i = arguments.length, e = new Array(i), r = 0; i > r; r++)e[r] = arguments[r];
                        return t.apply(this, _(e));
                    });
            }), [
                null == (n = h.Element) ? void 0 : n.prototype,
                null == (o = h.CharacterData) ? void 0 : o.prototype,
                null == (a = h.DocumentType) ? void 0 : a.prototype
            ].forEach((t)=>{
                f(t, "before", (t)=>function() {
                        for(var i = arguments.length, e = new Array(i), r = 0; i > r; r++)e[r] = arguments[r];
                        return t.apply(this, _(e));
                    }), f(t, "after", (t)=>function() {
                        for(var i = arguments.length, e = new Array(i), r = 0; i > r; r++)e[r] = arguments[r];
                        return t.apply(this, _(e));
                    }), f(t, "replaceWith", (t)=>function() {
                        for(var i = arguments.length, e = new Array(i), r = 0; i > r; r++)e[r] = arguments[r];
                        var s = _(e);
                        return e.length && !s.length ? void 0 : t.apply(this, s);
                    });
            }), f(null == (l = h.Element) ? void 0 : l.prototype, "insertAdjacentElement", (t)=>function(i, e) {
                    var r = p(e);
                    return r ? t.call(this, i, r) : null;
                }), this.Sc = ()=>{
                d.forEach((t)=>t()), this.Sc = void 0;
            }, this.xc();
        }
        xc() {
            var t = !1;
            return ()=>{
                var i;
                t || (t = !0, this.mc--, 0 === this.mc && (null == (i = this.Sc) || i.call(this)));
            };
        }
        Cc(t, i) {
            void 0 === i && (i = !0);
            var e = this.kc();
            try {
                var r = t(e);
                return i && e(), r;
            } catch (t) {
                throw e(), t;
            }
        }
        setupSiteApp(t) {
            var i = this.apps[t.id], e = ()=>{
                var e;
                !i.errored && this.yc.length && (Eh.info("Processing " + this.yc.length + " events for site app with id " + t.id), this.yc.forEach((t)=>this.Cc(()=>null == i.processEvent ? void 0 : i.processEvent(t))), i.processedBuffer = !0), Object.values(this.apps).every((t)=>t.processedBuffer || t.errored) && (null == (e = this._c) || e.call(this));
            }, r = !1, s = (s)=>{
                i.errored = !s, i.loaded = !0, Eh.info("Site app with id " + t.id + " " + (s ? "loaded" : "errored")), r && e();
            };
            try {
                var n = this.Cc((i)=>t.init({
                        posthog: this._instance,
                        callback (t) {
                            i(), s(t);
                        }
                    }), !1).processEvent;
                n && (i.processEvent = n), r = !0;
            } catch (i) {
                Eh.error(kh + t.id, i), s(!1);
            }
            if (r && i.loaded) try {
                e();
            } catch (e) {
                Eh.error("Error while processing buffered events PostHog app with config id " + t.id, e), i.errored = !0;
            }
        }
        Tc() {
            var t = this.siteAppLoaders || [];
            for (var i of t)this.apps[i.id] = {
                id: i.id,
                loaded: !1,
                errored: !1,
                processedBuffer: !1
            };
            for (var e of t)this.setupSiteApp(e);
        }
        Mc(t) {
            var i = this;
            if (0 !== Object.keys(this.apps).length) {
                var e = this.globalsForEvent(t), r = function(r) {
                    try {
                        i.Cc(()=>null == r.processEvent ? void 0 : r.processEvent(e));
                    } catch (i) {
                        Eh.error("Error while processing event " + t.event + " for site app " + r.id, i);
                    }
                };
                for (var s of Object.values(this.apps))r(s);
            }
        }
        onRemoteConfig(t) {
            var i, e, r, s = this;
            if (null != (i = this.siteAppLoaders) && i.length) return this.isEnabled ? (this.Tc(), void this._instance.on("eventCaptured", (t)=>this.Mc(t))) : void Eh.error('PostHog site apps are disabled. Enable the "opt_in_site_apps" config to proceed.');
            if (null == (e = this._c) || e.call(this), t.ok) {
                var n = t.config;
                if (null != (r = n.siteApps) && r.length) if (this.isEnabled) {
                    var o = function() {
                        var t, i = a.id, e = a.url;
                        v["__$$ph_site_app_" + i] = s._instance, null == (t = v.__PosthogExtensions__) || null == t.loadSiteApp || t.loadSiteApp(s._instance, e, (t)=>{
                            if (t) return Eh.error(kh + i, t);
                        });
                    };
                    for (var a of n.siteApps)o();
                } else Eh.error('PostHog site apps are disabled. Enable the "opt_in_site_apps" config to proceed.');
            }
        }
    }
}, fu = {
    tracingHeaders: class {
        constructor(t){
            this.Ic = void 0, this.Ec = void 0, this.Rc = void 0, this.Uv = ()=>{
                var t, i, e = this.Pc();
                e ? (D(this.Ic) && (this.Ic = null == (t = v.__PosthogExtensions__) || null == (t = t.tracingHeadersPatchFns) ? void 0 : t._patchXHR(e, ()=>this._instance.get_distinct_id(), this._instance.sessionManager)), D(this.Ec) && (this.Ec = null == (i = v.__PosthogExtensions__) || null == (i = i.tracingHeadersPatchFns) ? void 0 : i._patchFetch(e, ()=>this._instance.get_distinct_id(), this._instance.sessionManager))) : this.Jv();
            }, this._instance = t;
        }
        initialize() {
            this.startIfEnabledOrStop();
        }
        Ys(t) {
            var i, e;
            null != (i = v.__PosthogExtensions__) && i.tracingHeadersPatchFns ? t() : null == (e = v.__PosthogExtensions__) || null == e.loadExternalDependency || e.loadExternalDependency(this._instance, "tracing-headers", (i)=>{
                if (i) return ah.error("failed to load script", i);
                t();
            });
        }
        Ac() {
            var t, i;
            return null !== (t = null !== (i = this._instance.config.tracing_headers) && void 0 !== i ? i : this._instance.config.addTracingHeaders) && void 0 !== t ? t : this._instance.config.__add_tracing_headers;
        }
        Pc() {
            var t = this.Ac();
            return I(t) ? (I(this.Rc) ? this.Rc.splice(0, this.Rc.length, ...t) : this.Rc = [
                ...t
            ], t.length > 0 ? this.Rc : void 0) : (I(this.Rc) && this.Rc.splice(0), this.Rc = t || void 0, this.Rc);
        }
        Jv() {
            var t, i;
            null == (t = this.Ic) || t.call(this), null == (i = this.Ec) || i.call(this), this.Ic = void 0, this.Ec = void 0;
        }
        startIfEnabledOrStop() {
            this.Pc() ? this.Ys(this.Uv) : this.Jv();
        }
    }
}, pu = _({
    surveys: class extends Rh {
        constructor(t){
            var i;
            super(new Mh(t), {
                get projectToken () {
                    return i.config.token;
                },
                kv: new Ah(i = t)
            }), this._instance = t;
        }
        Bu(t, i) {
            var e = i.query ? La(t, i.query) : t;
            return new Promise((t)=>{
                var r;
                this._instance._send_request({
                    method: i.method,
                    url: this._instance.requestRouter.endpointFor(null !== (r = i.target) && void 0 !== r ? r : "api", e),
                    data: i.body,
                    headers: i.headers,
                    timeout: i.timeoutMs,
                    fireCallbackOnDrop: !0,
                    transport: i.transport,
                    compression: i.compression,
                    timestampMode: i.sentAt,
                    callback: t
                });
            });
        }
    }
}, lu), _u = {
    toolbar: class {
        constructor(t){
            this.instance = t;
        }
        Fc(t) {
            v.ph_toolbar_state = t;
        }
        Oc() {
            var t;
            return null !== (t = v.ph_toolbar_state) && void 0 !== t ? t : 0;
        }
        initialize() {
            return this.maybeLoadToolbar();
        }
        maybeLoadToolbar(i, e, s) {
            if (void 0 === i && (i = void 0), void 0 === e && (e = void 0), void 0 === s && (s = void 0), ws(this.instance.config)) return !1;
            if (!t || !r) return !1;
            i = null != i ? i : t.location, s = null != s ? s : t.history;
            try {
                if (!e) {
                    try {
                        t.localStorage.setItem("test", "test"), t.localStorage.removeItem("test");
                    } catch (t) {
                        return !1;
                    }
                    e = null == t ? void 0 : t.localStorage;
                }
                var n, o = Dh || no(i.hash, "__posthog") || no(i.hash, "state"), a = o ? ps(()=>JSON.parse(atob(decodeURIComponent(o)))) || ps(()=>JSON.parse(decodeURIComponent(o))) : null;
                return a && "ph_authorize" === a.action ? ((n = a).source = "url", n && Object.keys(n).length > 0 && (a.desiredHash ? i.hash = a.desiredHash : s ? s.replaceState(s.state, "", i.pathname + i.search) : i.hash = "")) : ((n = JSON.parse(e.getItem(Nh) || "{}")).source = "localstorage", delete n.userIntent), !(!n.token || this.instance.config.token !== n.token || (this.loadToolbar(n), 0));
            } catch (t) {
                return !1;
            }
        }
        Lc(t) {
            var i = v.ph_load_toolbar || v.ph_load_editor;
            !U(i) && F(i) ? i(t, this.instance) : Lh.warn("No toolbar load function found");
        }
        loadToolbar(i) {
            var e = !(null == r || !r.getElementById(Xs));
            if (!t || e) return !1;
            var s = "custom" === this.instance.requestRouter.region && this.instance.config.advanced_disable_toolbar_metrics, n = _({
                token: this.instance.config.token
            }, i, {
                apiURL: this.instance.requestRouter.endpointFor("ui")
            }, s ? {
                instrument: !1
            } : {});
            if (t.localStorage.setItem(Nh, JSON.stringify(_({}, n, {
                source: void 0
            }))), 2 === this.Oc()) this.Lc(n);
            else if (0 === this.Oc()) {
                var o;
                this.Fc(1), null == (o = v.__PosthogExtensions__) || null == o.loadExternalDependency || o.loadExternalDependency(this.instance, "toolbar", (t)=>{
                    if (t) return Lh.error("[Toolbar] Failed to load", t), void this.Fc(0);
                    this.Fc(2), this.Lc(n);
                }), ys(t, "turbolinks:load", ()=>{
                    this.Fc(0), this.loadToolbar(n);
                });
            }
            return !0;
        }
        Dc(t) {
            return this.loadToolbar(t);
        }
        maybeLoadEditor(t, i, e) {
            return void 0 === t && (t = void 0), void 0 === i && (i = void 0), void 0 === e && (e = void 0), this.maybeLoadToolbar(t, i, e);
        }
    }
}, gu = _({
    experiments: Zh
}, lu), mu = {
    conversations: class {
        constructor(t){
            this.$c = void 0, this._conversationsManager = null, this.Nc = !1, this.je = null, this.qc = !1, this._instance = t;
        }
        initialize() {
            this.loadIfEnabled();
        }
        onRemoteConfig(t) {
            if (!this._instance.config.disable_conversations && (this.jc = t.ok, t.ok)) {
                var i = t.config.conversations;
                U(i) || (H(i) ? this.$c = i : (this.$c = i.enabled, this.je = i), this.loadIfEnabled());
            }
        }
        reset() {
            var t;
            null == (t = this._conversationsManager) || t.reset(), this._conversationsManager = null, this.$c = void 0, this.je = null, this.jc = void 0, this.qc = !1;
        }
        loadIfEnabled() {
            if (!(this._conversationsManager || this.Nc || this._instance.config.disable_conversations || ws(this._instance.config) || this._instance.config.cookieless_mode && this._instance.consent.isOptedOut())) {
                var t = null == v ? void 0 : v.__PosthogExtensions__;
                if (t && !D(this.$c) && this.$c) if (this.je && this.je.token) {
                    this.Nc = !0;
                    try {
                        var i = t.initConversations;
                        if (i) return this.Bc(i), void (this.Nc = !1);
                        var e = t.loadExternalDependency;
                        if (!e) return void this.Hc(Zr);
                        e(this._instance, "conversations", (i)=>{
                            i || !t.initConversations ? this.Hc("Could not load conversations script", i) : this.Bc(t.initConversations), this.Nc = !1;
                        });
                    } catch (t) {
                        this.Hc("Error initializing conversations", t), this.Nc = !1;
                    }
                } else tu.error("Conversations enabled but missing token in remote config.");
            }
        }
        Bc(t) {
            if (this.je) try {
                this._conversationsManager = t(this.je, this._instance), this.qc = !1, tu.info("Conversations loaded successfully");
            } catch (t) {
                this.Hc("Error completing conversations initialization", t);
            }
            else tu.error("Cannot complete initialization: remote config is null");
        }
        Hc(t, i) {
            tu.error(t, i), this._conversationsManager = null, this.Nc = !1, this.qc = !0;
        }
        show() {
            this._conversationsManager ? this._conversationsManager.show() : tu.warn("Conversations not loaded yet.");
        }
        hide() {
            this._conversationsManager && this._conversationsManager.hide();
        }
        isAvailable() {
            return !0 === this.$c && !j(this._conversationsManager);
        }
        getUnavailableReason() {
            return this.isAvailable() ? null : this._instance.config.disable_conversations ? "disabled_by_config" : ws(this._instance.config) ? "disabled_for_toolbar" : this._instance.config.cookieless_mode && this._instance.consent.isOptedOut() ? "consent_opted_out" : !1 === this.jc ? "remote_config_failed" : D(this.$c) ? this.jc ? "disabled_in_project" : "remote_config_pending" : this.$c ? U(this.je) || !this.je.token ? "missing_token" : null != v && v.__PosthogExtensions__ ? this.Nc ? "initializing" : this.qc ? "load_failed" : "not_loaded" : "extensions_unavailable" : "disabled_in_project";
        }
        isVisible() {
            var t, i;
            return null !== (t = null == (i = this._conversationsManager) ? void 0 : i.isVisible()) && void 0 !== t && t;
        }
        sendMessage(t, i, e) {
            var r = this;
            return p(function*() {
                return r._conversationsManager ? r._conversationsManager.sendMessage(t, i, e) : (tu.warn(iu), null);
            })();
        }
        getMessages(t, i) {
            var e = this;
            return p(function*() {
                return e._conversationsManager ? e._conversationsManager.getMessages(t, i) : (tu.warn(iu), null);
            })();
        }
        markAsRead(t) {
            var i = this;
            return p(function*() {
                return i._conversationsManager ? i._conversationsManager.markAsRead(t) : (tu.warn(iu), null);
            })();
        }
        getTickets(t) {
            var i = this;
            return p(function*() {
                return i._conversationsManager ? i._conversationsManager.getTickets(t) : (tu.warn(iu), null);
            })();
        }
        requestRestoreLink(t) {
            var i = this;
            return p(function*() {
                return i._conversationsManager ? i._conversationsManager.requestRestoreLink(t) : (tu.warn(iu), null);
            })();
        }
        restoreFromToken(t) {
            var i = this;
            return p(function*() {
                return i._conversationsManager ? i._conversationsManager.restoreFromToken(t) : (tu.warn(iu), null);
            })();
        }
        restoreFromUrlToken() {
            var t = this;
            return p(function*() {
                return t._conversationsManager ? t._conversationsManager.restoreFromUrlToken() : (tu.warn(iu), null);
            })();
        }
        getCurrentTicketId() {
            var t, i;
            return null !== (t = null == (i = this._conversationsManager) ? void 0 : i.getCurrentTicketId()) && void 0 !== t ? t : null;
        }
        getWidgetSessionId() {
            var t, i;
            return null !== (t = null == (i = this._conversationsManager) ? void 0 : i.getWidgetSessionId()) && void 0 !== t ? t : null;
        }
        Cu() {
            var t;
            null == (t = this._conversationsManager) || t.setIdentity();
        }
        Tu() {
            var t;
            null == (t = this._conversationsManager) || t.clearIdentity();
        }
    }
}, bu = {
    logs: class {
        constructor(i){
            var e, r = this;
            this.name = "logs", this.zc = !1, this.Uc = !1, this.Wc = !1, this.A = Be("[logs]"), this.Vc = _({}, this.A, {
                error () {
                    for(var t = arguments.length, i = new Array(t), e = 0; t > e; e++)i[e] = arguments[e];
                    i.some(au) || r.A.error(...i);
                }
            }), this.bo = [], this.Gc = [], this._d = 0, this.Os = !1, this.Zc = [], this.Qc = [], this.Jc = !1, this.Kc = !1, this.Yc = ()=>{
                var t, i;
                this.Os || (this._d = 0, null == (t = this.Xc) || t.onReconnect(), null == (i = this.tf) || i.onReconnect());
            }, this._instance = i, this._instance && null != (e = this._instance.config.logs) && e.captureConsoleLogs && (this.zc = !0), t && ys(t, "online", this.Yc);
        }
        ef(t, i, e, r) {
            var s, n = eu(null == (s = this._instance) || null == (s = s.config) ? void 0 : s.logs, e);
            return [
                new Ae(this.if(t, i), n, this.Vc, ()=>this.rf(), (t)=>t(), void 0, r),
                n
            ];
        }
        nf() {
            var t, i = null == (t = this._instance) || null == (t = t.config) ? void 0 : t.logs;
            if (!this.Xc || this.sf !== i) {
                var e;
                null == (e = this.Xc) || e.reset(), this.sf = i;
                var r = this.ef(()=>this.bo, (t)=>{
                    this.bo = t;
                });
                this.Xc = r[0], this.af = r[1];
            }
            return this.Xc;
        }
        lf() {
            var t, i = null == (t = this._instance) || null == (t = t.config) ? void 0 : t.logs;
            if (!this.tf || this.uf !== i) {
                var e;
                null == (e = this.tf) || e.reset(), this.uf = i;
                var r = this.ef(()=>this.Gc, (t)=>{
                    this.Gc = t;
                }, {
                    serviceNameDefault: "posthog-browser-logs",
                    consoleCapture: !0
                }, su);
                this.tf = r[0], this.hf = r[1];
            }
            return this.tf;
        }
        setup(t) {
            var i;
            if (!this.Os) {
                this.Ns = t, null != (i = this._instance) && null != (i = i.config) && null != (i = i.logs) && i.captureConsoleLogs && (this.zc = !0), (this.zc || this.df() && this.vf()) && this.cf();
                var e = !1, r = t.onRemoteConfig((t)=>{
                    var i;
                    e = t.ok && !0 === (null == (i = t.config.logs) ? void 0 : i.captureConsoleLogs), this.onRemoteConfig(t);
                });
                this.Os ? r.dispose() : (this.qs = r, e || this.loadIfEnabled());
            }
        }
        dispose() {
            var i, e, r, s;
            this.Os || (this.Os = !0, this.ff(), null == (i = this.qs) || i.dispose(), this.qs = void 0, this.Ns = void 0, this.Wc = !1, null == t || t.removeEventListener("online", this.Yc), null == (e = this.pf) || e.call(this), this.pf = void 0, null == (r = this.Xc) || r.reset(), null == (s = this.tf) || s.reset());
        }
        onRemoteConfig(t) {
            var i, e;
            if (!this.Os) {
                var r = t.ok ? null == (i = t.config.logs) ? void 0 : i.captureConsoleLogs : void 0;
                U(r) ? this.gf() : (null == (e = this._instance) || null == (e = e.persistence) || e.register({
                    [hr]: !!r
                }), r ? (this.zc = !0, this.Uc || this.cf(), this.loadIfEnabled()) : this.gf());
            }
        }
        reset() {
            var t, i, e, r;
            this.ff(), null == (t = this.Xc) || t.clearQueue(), this.bo = [], null == (i = this.Xc) || i.reset(), null == (e = this.tf) || e.clearQueue(), this.Gc = [], null == (r = this.tf) || r.reset(), this._d = 0;
        }
        captureLog(t) {
            this.Os || this.nf().captureLog(t);
        }
        captureConsoleLog(t) {
            this.Os || this.lf().captureLog(t);
        }
        captureBufferedConsoleLog(t, i, e) {
            this.Os || this.lf().captureLog(t, {
                context: i,
                occurredAtMs: e
            });
        }
        vf() {
            var t;
            return !(null == (t = this._instance) || null == (t = t.persistence) || null == (t = t.props) || !t[hr]);
        }
        df() {
            var t, i;
            return null == (t = this._instance) || null == t.fo || !t.fo() || !(null == (i = v._POSTHOG_REMOTE_CONFIG) || null == (i = i[this._instance.config.token]) || !i.config);
        }
        Iu() {
            var t;
            this.ff(), null == (t = this.tf) || t.clearQueue(), this.Gc = [];
        }
        gf() {
            this.zc || this.ff();
        }
        cf() {
            var t, i = this;
            if (!this.Jc && null != v && v.console) {
                var e = eu(null == (t = this._instance) || null == (t = t.config) ? void 0 : t.logs).maxBufferSize, r = function(t) {
                    var r;
                    try {
                        r = ((t)=>{
                            for(; null != (i = t) && i.__rrweb_original__;){
                                var i;
                                t = t.__rrweb_original__;
                            }
                            return t;
                        })(v.console[t]);
                    } catch (t) {
                        return 0;
                    }
                    if (!r) return 0;
                    i.Qc.push(oh(v.console, t, (s)=>{
                        var n = function() {
                            for(var r = arguments.length, n = new Array(r), o = 0; r > o; o++)n[o] = arguments[o];
                            try {
                                i.mf(t, n, e);
                            } catch (t) {}
                            return s.apply(v.console, n);
                        };
                        return n.__rrweb_original__ = r, n;
                    }));
                };
                for (var s of ru)r(s);
                this.Jc = !0, this.yf = setTimeout(()=>{
                    this.ff();
                }, 3e4);
            }
        }
        mf(t, i, e) {
            var r;
            if (this.Jc && !this.Kc && 0 !== i.length) if (null != (r = this._instance) && r.is_capturing()) {
                if (e > this.Zc.length) {
                    this.Kc = !0;
                    try {
                        this.Zc.push({
                            level: t,
                            args: i,
                            occurredAtMs: Date.now(),
                            context: this.rf()
                        });
                    } finally{
                        this.Kc = !1;
                    }
                }
            } else this.ff();
        }
        ff() {
            if (this.Zc = [], this.Jc) {
                for (var t of (this.Jc = !1, this.yf && (clearTimeout(this.yf), this.yf = void 0), this.Qc))t();
                this.Qc = [];
            }
        }
        bf() {
            var t = this.Zc;
            return this.ff(), t;
        }
        get logger() {
            return this._f || (this._f = {
                trace: (t, i)=>this.captureLog({
                        body: t,
                        level: "trace",
                        attributes: i
                    }),
                debug: (t, i)=>this.captureLog({
                        body: t,
                        level: "debug",
                        attributes: i
                    }),
                info: (t, i)=>this.captureLog({
                        body: t,
                        level: "info",
                        attributes: i
                    }),
                warn: (t, i)=>this.captureLog({
                        body: t,
                        level: "warn",
                        attributes: i
                    }),
                error: (t, i)=>this.captureLog({
                        body: t,
                        level: "error",
                        attributes: i
                    }),
                fatal: (t, i)=>this.captureLog({
                        body: t,
                        level: "fatal",
                        attributes: i
                    })
            }), this._f;
        }
        flushLogs(t) {
            t ? this.wf(t) : (this.Xc && this.Xc.flush().catch((t)=>this.kf(t)), this.tf && this.tf.flush().catch((t)=>this.kf(t)));
        }
        kf(t) {
            au(t) || this.A.error("PostHog logs flush failed:", t);
        }
        loadIfEnabled() {
            if (!this.Os && this.zc && !this.Uc && !this.Wc) {
                var t = null == v ? void 0 : v.__PosthogExtensions__;
                if (!t) return this.A.error("PostHog Extensions not found."), void this.ff();
                var i = t.loadExternalDependency;
                if (!i) return this.A.error(Zr), void this.ff();
                this.Wc = !0;
                try {
                    i(this._instance, "logs", (i)=>{
                        if (this.Wc = !1, !this.Os && this.zc) {
                            var e = t.logs;
                            if (i || null == e || !e.initializeLogs) this.A.error("Could not load logs script", i), this.ff();
                            else {
                                var r, s, n = this.bf();
                                this.pf = e.initializeLogs(null !== (r = this.Ns) && void 0 !== r ? r : this._instance), this.Uc = !0, n.length > 0 && (null == e.replayConsoleBuffer || e.replayConsoleBuffer(null !== (s = this.Ns) && void 0 !== s ? s : this._instance, n));
                            }
                        }
                    });
                } catch (t) {
                    throw this.Wc = !1, t;
                }
            }
        }
        if(t, i) {
            var e = this._instance;
            return {
                get isDisabled () {
                    return !1;
                },
                get optedOut () {
                    return !e.is_capturing();
                },
                getPersistedProperty: (i)=>i === E.LogsQueue ? t() : void 0,
                setPersistedProperty (t, e) {
                    var r;
                    t === E.LogsQueue && i(null !== (r = e) && void 0 !== r ? r : []);
                },
                hs: (t)=>this.hs(t),
                getLibraryId: ()=>c.LIB_NAME,
                getLibraryVersion: ()=>c.LIB_VERSION
            };
        }
        hs(t) {
            return new Promise((i)=>{
                if (oo(this._d, 3)) i({
                    kind: "fatal",
                    error: ou(void 0, "logs endpoint is unreachable, dropping batch")
                });
                else {
                    var e = !1, r = (t)=>{
                        e || (e = !0, clearTimeout(s), i(t));
                    }, s = setTimeout(()=>{
                        this.A.warn("Logs request timed out before receiving a response"), r({
                            kind: "retry-later",
                            error: ou(void 0, "logs request timed out")
                        });
                    }, 9e4);
                    this._instance._send_request({
                        method: "POST",
                        url: this.Sf(),
                        data: t,
                        compression: "best-available",
                        batchKey: "logs",
                        fireCallbackOnDrop: !0,
                        callback: (t)=>{
                            var i = t.statusCode;
                            if (this.xf(i), i >= 200 && 300 > i) r({
                                kind: "ok"
                            });
                            else if (413 === i) r({
                                kind: "too-large"
                            });
                            else if (0 !== i && 408 !== i && 429 !== i && 500 > i) r({
                                kind: "fatal",
                                error: new Error("logs request failed with status " + i)
                            });
                            else {
                                var e;
                                0 === i ? (t.error || this.A.warn("Logs request failed before receiving an HTTP response"), r({
                                    kind: "retry-later",
                                    error: ou(t.error, "logs request failed before receiving an HTTP response")
                                })) : r({
                                    kind: "retry-later",
                                    error: null !== (e = t.error) && void 0 !== e ? e : new Error("logs request failed with status " + i)
                                });
                            }
                        }
                    });
                }
            });
        }
        xf(t) {
            (0 !== t || this._instance.__loaded) && (this._d = ao(t, this._d, 3, ()=>this.A.warn("Log requests are failing before receiving an HTTP response; this can happen due to network issues, CORS, browser blocking, or ad blockers. Stopped sending logs; will try again when connectivity changes.")));
        }
        wf(t) {
            this.bo.length > 0 && this.Cf(t, this.bo, this.af, c.LIB_NAME, (t)=>{
                this.bo = t;
            }), this.Gc.length > 0 && this.Cf(t, this.Gc, this.hf, su, (t)=>{
                this.Gc = t;
            });
        }
        Cf(t, i, e, r, s) {
            if (0 !== i.length) {
                var n = i.map((t)=>t.record);
                s([]);
                var o = Fe(n, Ie(e, c.LIB_NAME, c.LIB_VERSION), r, c.LIB_VERSION);
                this._instance._send_request({
                    method: "POST",
                    url: this.Sf(),
                    data: o,
                    compression: "best-available",
                    batchKey: "logs",
                    transport: t
                });
            }
        }
        Sf() {
            return this._instance.requestRouter.endpointFor("api", "/i/v1/logs") + "?token=" + encodeURIComponent(this._instance.config.token);
        }
        rf() {
            var t, i = {};
            if (i.distinctId = this._instance.get_distinct_id(), this._instance.sessionManager) {
                var e = this._instance.sessionManager.checkAndGetSessionAndWindowId(!0), r = e.windowId, s = e.sessionStartTimestamp, n = e.lastActivityTimestamp;
                i.sessionId = e.sessionId, i.windowId = r, U(s) || (i.sessionStartTimestamp = s), U(n) || (i.lastActivityTimestamp = n);
            }
            if (null != v && null != (t = v.location) && t.href && (i.currentUrl = this._instance.config.disable_capture_url_hashes ? Ti(v.location.href) : v.location.href), this._instance.featureFlags) {
                var o = this._instance.featureFlags.getFlags();
                o && o.length > 0 && (i.activeFeatureFlags = o);
            }
            return i;
        }
    }
}, yu = {
    metrics: class {
        constructor(t){
            this.A = Be("[metrics]"), this._instance = t;
        }
        initialize() {}
        nf() {
            var t, i, e = null == (t = this._instance) || null == (t = t.config) ? void 0 : t.metrics;
            return this.Xc && this.sf === e || (null == (i = this.Xc) || i.reset(), this.sf = e, this.Xc = new Le(this.if(), function(t) {
                var i, e, r, s, n, o = null == t ? void 0 : t.resourceAttributes;
                return {
                    serviceName: null !== (i = null == o ? void 0 : o["service.name"]) && void 0 !== i ? i : null == t ? void 0 : t.serviceName,
                    serviceVersion: null !== (e = null == o ? void 0 : o["service.version"]) && void 0 !== e ? e : null == t ? void 0 : t.serviceVersion,
                    environment: null !== (r = null == o ? void 0 : o["deployment.environment"]) && void 0 !== r ? r : null == t ? void 0 : t.environment,
                    resourceAttributes: o,
                    beforeSend: null == t ? void 0 : t.beforeSend,
                    flushIntervalMs: null !== (s = null == t ? void 0 : t.flushIntervalMs) && void 0 !== s ? s : 1e4,
                    maxSeriesPerFlush: null !== (n = null == t ? void 0 : t.maxSeriesPerFlush) && void 0 !== n ? n : 1e3
                };
            }(e), this.A)), this.Xc;
        }
        count(t, i, e) {
            void 0 === i && (i = 1), this.nf().count(t, i, e);
        }
        gauge(t, i, e) {
            this.nf().gauge(t, i, e);
        }
        histogram(t, i, e) {
            this.nf().histogram(t, i, e);
        }
        flush(t) {
            if (!this.Xc) return Promise.resolve();
            if (t) {
                var i = this.Xc.drainWindow();
                return i && this.Ms(i, t), Promise.resolve();
            }
            return this.Xc.flush().catch((t)=>this.A.error("PostHog metrics flush failed:", t));
        }
        reset() {
            var t;
            null == (t = this.Xc) || t.reset();
        }
        if() {
            var t = this._instance, i = this;
            return {
                get isDisabled () {
                    return !1;
                },
                get optedOut () {
                    return !t.is_capturing();
                },
                Ms: (t)=>i.Ms(t),
                getLibraryId: ()=>c.LIB_NAME,
                getLibraryVersion: ()=>c.LIB_VERSION
            };
        }
        Ms(t, i) {
            return new Promise((e)=>{
                var r = !1, s = (t)=>{
                    r || (r = !0, clearTimeout(n), e(t));
                }, n = setTimeout(()=>s({
                        kind: "retry-later",
                        error: new Error("metrics request timed out")
                    }), 9e4);
                this._instance._send_request(_({
                    method: "POST",
                    url: this.Tf(),
                    data: t,
                    compression: "best-available",
                    batchKey: "metrics"
                }, i && {
                    transport: i
                }, {
                    fireCallbackOnDrop: !0,
                    callback (t) {
                        var i = t.statusCode;
                        if (i >= 200 && 300 > i) s({
                            kind: "ok"
                        });
                        else if (413 === i) s({
                            kind: "too-large"
                        });
                        else if (0 !== i && 408 !== i && 429 !== i && 500 > i) s({
                            kind: "fatal",
                            error: new Error("metrics request failed with status " + i)
                        });
                        else {
                            var e;
                            s({
                                kind: "retry-later",
                                error: null !== (e = t.error) && void 0 !== e ? e : new Error("metrics request failed with status " + i)
                            });
                        }
                    }
                }));
            });
        }
        Tf() {
            return this._instance.requestRouter.endpointFor("api", "/i/v1/metrics") + "?token=" + encodeURIComponent(this._instance.config.token);
        }
    }
}, wu = _({}, lu, hu, uu, du, vu, cu, pu, fu, _u, gu, mu, bu, yu);
Jl.__defaultExtensionClasses = _({}, wu);
var Su = function() {
    c.SDK_DIST_CHANNEL = "npm";
    var i = Ol[Bl] = new Jl;
    return function() {
        function i() {
            i.done || (i.done = !0, zl = !1, vs(Ol, function(t) {
                t._dom_loaded();
            }));
        }
        null != r && r.addEventListener ? "complete" === r.readyState ? i() : ys(r, "DOMContentLoaded", i, {
            capture: !1
        }) : t && Ue.error("Browser doesn't support `document.addEventListener` so PostHog couldn't be initialized");
    }(), i;
}();
;
}),
]);

//# sourceMappingURL=node_modules_posthog-js_dist_module_mjs_00nwsfs._.js.map