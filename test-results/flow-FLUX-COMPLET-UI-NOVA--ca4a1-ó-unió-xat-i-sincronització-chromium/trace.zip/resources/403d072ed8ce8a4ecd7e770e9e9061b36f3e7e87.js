(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/supabase.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-client] (ecmascript) <locals>");
;
console.log("La URL que llegeix Next.js és:", ("TURBOPACK compile-time value", "https://afmdpbkduvkpkglxvxlo.supabase.co"));
const supabaseUrl = ("TURBOPACK compile-time value", "https://afmdpbkduvkpkglxvxlo.supabase.co");
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFmbWRwYmtkdXZrcGtnbHh2eGxvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM2ODMwOTMsImV4cCI6MjA5OTI1OTA5M30.1T0UaUJC4u91vgskpTUVxY5DHhn-54Bi7Eyr8dLlTOs");
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseAnonKey);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AdminDashboard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function AdminDashboard() {
    _s();
    const [pinSessio, setPinSessio] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [idSessio, setIdSessio] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [equips, setEquips] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [equipSeleccionat, setEquipSeleccionat] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // 🎯 Filtre temporal d'aula
    const [horaNeteja, setHoraNeteja] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // 💳 Control de monetització i client (per defecte o UUID configurat)
    const [idClientActual, setIdClientActual] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // 🎲 1. Generador de PINs nets d'alta llegibilitat
    const generarPinUnic = ()=>{
        const caracters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        let resultat = '';
        for(let i = 0; i < 4; i++){
            resultat += caracters.charAt(Math.floor(Math.random() * caracters.length));
        }
        return resultat;
    };
    // Obtenir o inicialitzar un ID de client actiu per a la sessió
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AdminDashboard.useEffect": ()=>{
            async function obtenirClientDefault() {
                const { data: clients } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('clients').select('id_client').limit(1);
                if (clients && clients.length > 0) {
                    setIdClientActual(clients[0].id_client);
                }
            }
            obtenirClientDefault();
        }
    }["AdminDashboard.useEffect"], []);
    // 🚀 2. Funció de llançament controlat per crèdits
    const arrancarNouTallerMonetitzat = async ()=>{
        let clientId = idClientActual.trim();
        // Si no hi ha cap client a la taula, creem un client demo per permetre provar la plataforma
        if (!clientId) {
            const { data: nouClient, error: errClient } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('clients').insert([
                {
                    nom: 'UNIVERSITAT DEMO',
                    tipus_client: 'ACADEMIC',
                    sector: 'EDUCACIO',
                    credits_disponibles: 10
                }
            ]).select('id_client').single();
            if (errClient || !nouClient) {
                alert("🚨 Error en inicialitzar el client per defecte. Verifiqueu les taules de Supabase.");
                return;
            }
            clientId = nouClient.id_client;
            setIdClientActual(clientId);
        }
        setLoading(true);
        try {
            // PAS A: Comprovar si el client té saldo de veritat 🔍
            const { data: clients, error: errorClient } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('clients').select('credits_disponibles').eq('id_client', clientId);
            if (errorClient || !clients || clients.length === 0) {
                alert(`🚨 CLIENT NO TROBAT: La ID de client [${clientId}] no existeix o està bloquejada.`);
                setLoading(false);
                return;
            }
            const saldoActual = clients[0].credits_disponibles ?? 0;
            if (saldoActual <= 0) {
                alert("🚨 SALDO INSUFICIENT: El teu compte té 0 crèdits disponibles. Sisplau, recarregueu crèdits per llançar nous tallers.");
                setLoading(false);
                return;
            }
            // PAS B: El client té saldo! Procedim a restar-li 1 crèdit de consum 💸
            const { error: errorResta } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('clients').update({
                credits_disponibles: saldoActual - 1
            }).eq('id_client', clientId);
            if (errorResta) {
                alert(`No s'ha pogut processar el cobrament: ${errorResta.message}`);
                setLoading(false);
                return;
            }
            // PAS C: Crèdit cobrat. Generem la sessió de joc real! 🎮
            const nouPin = generarPinUnic();
            const { data: novaSessio, error: errorSessio } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('sessions').insert([
                {
                    pin_acces: nouPin,
                    estat: 'EN_CURS',
                    id_client: clientId,
                    id_template: 'MISION_1'
                }
            ]).select().single();
            if (errorSessio || !novaSessio) {
                alert(`Error al registrar la sessió: ${errorSessio?.message}`);
                setLoading(false);
                return;
            }
            // PAS D: Sincronitzem el front-end a l'acte amb la nova sala verge ⚡
            setPinSessio(nouPin);
            setIdSessio(novaSessio.id_sessio);
            setEquips([]);
            alert(`🎉 Taller llançat amb èxit!\n💸 S'ha consumit 1 crèdit (Saldo restant: ${saldoActual - 1}).\n🎯 Comparteix aquest PIN amb la teva aula: ${nouPin}`);
        } catch (err) {
            console.error(err);
        } finally{
            setLoading(false);
        }
    };
    const mapMissions = {
        'MISION_1': 25,
        'MISION_2': 50,
        'MISION_3': 75,
        'MISION_4': 100
    };
    // 🔄 CARREGAR DATA DE LA SESSIÓ
    const carregarDadesSessio = async (pinTarget, isSilent = false)=>{
        if (!pinTarget.trim()) return;
        if (!isSilent) setLoading(true);
        try {
            const { data: sessio, error: errorSessio } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('sessions').select('id_sessio, id_client').eq('pin_acces', pinTarget.trim().toUpperCase()).eq('estat', 'EN_CURS').single();
            if (errorSessio || !sessio) {
                if (!isSilent) alert("⚠️ No hi ha cap sessió 'EN_CURS' amb aquest PIN.");
                return;
            }
            setIdSessio(sessio.id_sessio);
            const { data: equipsData, error: errorEquips } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('equips').select(`
          id_equip,
          id_sessio,
          nom_equip,
          missio_actual,
          dossier_actiu,
          creat_el,
          sessions (
            id_client,
            clients (
              credits_disponibles
            )
          )
        `).eq('id_sessio', sessio.id_sessio);
            if (!errorEquips && equipsData) {
                const formattedTeams = equipsData.map((e)=>{
                    const sessionNode = Array.isArray(e.sessions) ? e.sessions[0] : e.sessions;
                    const clientNode = sessionNode?.clients ? Array.isArray(sessionNode.clients) ? sessionNode.clients[0] : sessionNode.clients : null;
                    return {
                        id_equip: e.id_equip,
                        id_client: sessionNode?.id_client || '',
                        noms_equip: e.nom_equip || 'Equip Detectat',
                        missio_actual: e.missio_actual || 'MISION_1',
                        credits: clientNode?.credits_disponibles ?? 0,
                        informe_final: e.dossier_actiu?.informe_final || null,
                        reflexio_individual: e.dossier_actiu?.reflexio_individual || '',
                        hora_inici: e.creat_el || new Date().toISOString()
                    };
                });
                setEquips(formattedTeams);
            }
        } catch (err) {
            console.error(err);
        } finally{
            if (!isSilent) setLoading(false);
        }
    };
    // 🔒 TANCAMENT REALS: Movem l'estat a FINALITZADA
    const arxivarSessióMestre = async ()=>{
        if (!idSessio) return;
        const confirmar = confirm("🚨 Vols donar per acabat aquest taller i FINALITZAR la sessió? Els equips quedaran arxivats i la terminal de l'alumne es bloquejarà.");
        if (!confirmar) return;
        setLoading(true);
        try {
            const { error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('sessions').update({
                estat: 'FINALITZADA'
            }).eq('id_sessio', idSessio);
            if (!error) {
                setEquips([]);
                setEquipSeleccionat(null);
                setIdSessio(null);
                alert("🔒 Partida finalitzada i arxivada correctament en l'historial d'operacions.");
            } else {
                alert(`Error al tancar la sessió: ${error.message}`);
            }
        } catch (err) {
            console.error(err);
        } finally{
            setLoading(false);
        }
    };
    // 🔄 LOOP DE REFRESC CONTROLAT AMB REALTIME I CLEANUP
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AdminDashboard.useEffect": ()=>{
            if (!pinSessio || !idSessio) return;
            const canalEquips = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].channel(`equips-sessio-${idSessio}`).on('postgres_changes', {
                event: '*',
                schema: 'public',
                table: 'equips',
                filter: `id_sessio=eq.${idSessio}`
            }, {
                "AdminDashboard.useEffect.canalEquips": ()=>{
                    console.log('🔄 Canvi detectat a equips!');
                    carregarDadesSessio(pinSessio, true);
                }
            }["AdminDashboard.useEffect.canalEquips"]).subscribe();
            const interval = setInterval({
                "AdminDashboard.useEffect.interval": ()=>{
                    carregarDadesSessio(pinSessio, true);
                }
            }["AdminDashboard.useEffect.interval"], 5000);
            return ({
                "AdminDashboard.useEffect": ()=>{
                    clearInterval(interval);
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].removeChannel(canalEquips);
                }
            })["AdminDashboard.useEffect"];
        }
    }["AdminDashboard.useEffect"], [
        idSessio,
        pinSessio
    ]);
    // ⚡ GOD MODE: ACTUALITZACIÓ REAL DE CRÈDITS DE CLIENT
    const modificarCreditsMestre = async (idEquip, idClient, canvi)=>{
        const equip = equips.find((e)=>e.id_equip === idEquip);
        const targetClientId = idClient || idClientActual;
        if (!equip || !targetClientId) return;
        const nouSaldo = Math.max(0, equip.credits + canvi);
        try {
            const { error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('clients').update({
                credits_disponibles: nouSaldo
            }).eq('id_client', targetClientId);
            if (!error) {
                setEquips((prev)=>prev.map((e)=>e.id_equip === idEquip ? {
                            ...e,
                            credits: nouSaldo
                        } : e));
            }
        } catch (err) {
            console.error("Error modificarCreditsMestre:", err);
        }
    };
    // ⚡ GOD MODE: FORÇAR EL SALT DE MISSIÓ
    const forcarSaltMissio = async (idEquip, seguentMissio)=>{
        try {
            const { error } = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from('equips').update({
                missio_actual: seguentMissio
            }).eq('id_equip', idEquip);
            if (!error) {
                setEquips((prev)=>prev.map((e)=>e.id_equip === idEquip ? {
                            ...e,
                            missio_actual: seguentMissio
                        } : e));
                alert(`🚀 S'ha forçat el salt a ${seguentMissio}`);
            }
        } catch (err) {
            console.error("Error forcarSaltMissio:", err);
        }
    };
    // Funció per descarregar fitxers directament des del navegador
    const descarregarTelemetria = (idSessio, format)=>{
        const url = `/api/export?id_sessio=${idSessio}&format=${format}`;
        const link = document.createElement('a');
        link.href = url;
        link.download = `telemetria_${idSessio}.${format}`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-slate-900 text-slate-100 p-6 font-sans",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-6 mb-6 gap-4 no-print",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-2xl font-bold tracking-tight text-white flex items-center gap-2",
                                children: "🏛️ Synusia Facilitator Operations Panel"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/page.tsx",
                                lineNumber: 324,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-slate-400 mt-1",
                                children: "Gestió aïllada multi-tenant per a tallers executius, universitats i entitats públiques."
                            }, void 0, false, {
                                fileName: "[project]/app/admin/page.tsx",
                                lineNumber: 327,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/page.tsx",
                        lineNumber: 323,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2 bg-slate-950 p-2 rounded-lg border border-slate-800",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: arrancarNouTallerMonetitzat,
                                disabled: loading,
                                className: "w-full bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-mono font-bold text-xs py-3 px-4 rounded border border-emerald-400 uppercase tracking-wider transition-all duration-200 shadow-lg shadow-emerald-950/20 disabled:opacity-50",
                                children: loading ? 'Processant...' : '🚀 Llançar Nova Sessió (-1 Crèdit)'
                            }, void 0, false, {
                                fileName: "[project]/app/admin/page.tsx",
                                lineNumber: 330,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                placeholder: "PIN D'ACCÉS",
                                value: pinSessio,
                                onChange: (e)=>setPinSessio(e.target.value),
                                className: "bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-center text-sm font-mono font-bold tracking-widest text-cyan-400 focus:outline-none focus:border-cyan-500 uppercase"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/page.tsx",
                                lineNumber: 338,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>carregarDadesSessio(pinSessio),
                                className: "bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold px-4 py-1.5 rounded text-xs tracking-wider transition-colors uppercase",
                                children: "Sincronitzar Monitor"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/page.tsx",
                                lineNumber: 345,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/page.tsx",
                        lineNumber: 329,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/page.tsx",
                lineNumber: 322,
                columnNumber: 7
            }, this),
            idSessio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-wrap justify-between items-center bg-slate-950 p-3 rounded-lg border border-slate-800 gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mr-1",
                                        children: "📊 Exportar Dades:"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/page.tsx",
                                        lineNumber: 359,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>descarregarTelemetria(idSessio, 'csv'),
                                        className: "bg-emerald-950/80 hover:bg-emerald-900 text-emerald-400 border border-emerald-800/80 text-xs font-mono font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 shadow-sm",
                                        children: "📥 Telemetria (CSV)"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/page.tsx",
                                        lineNumber: 362,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>descarregarTelemetria(idSessio, 'json'),
                                        className: "bg-blue-950/80 hover:bg-blue-900 text-blue-400 border border-blue-800/80 text-xs font-mono font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 shadow-sm",
                                        children: "📄 Raw (JSON)"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/page.tsx",
                                        lineNumber: 368,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>window.print(),
                                        className: "bg-purple-950/80 hover:bg-purple-900 text-purple-300 border border-purple-800/80 text-xs font-mono font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 shadow-sm no-print",
                                        children: "🖨️ Guardar PDF"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/page.tsx",
                                        lineNumber: 374,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/page.tsx",
                                lineNumber: 358,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: arxivarSessióMestre,
                                className: "bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-900/60 text-[10px] font-mono font-bold px-3 py-1.5 rounded transition-all tracking-wider uppercase no-print",
                                children: "🔒 Arxivar Sessió"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/page.tsx",
                                lineNumber: 382,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/page.tsx",
                        lineNumber: 357,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 xl:grid-cols-3 gap-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "xl:col-span-2 space-y-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-sm font-bold tracking-widest uppercase font-mono text-slate-400",
                                        children: [
                                            "// MONITOR DE LA SALA EN ACTIU (",
                                            equips.length,
                                            " Equips)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/admin/page.tsx",
                                        lineNumber: 392,
                                        columnNumber: 15
                                    }, this),
                                    equips.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-slate-500 italic p-4 bg-slate-950/40 border border-dashed border-slate-800 rounded-lg",
                                        children: "Sessió connectada. Esperant que els equips s'inscriguin des de la terminal..."
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/page.tsx",
                                        lineNumber: 397,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                                        children: equips.filter((team)=>!horaNeteja || team.hora_inici > horaNeteja).map((team)=>{
                                            const progres = mapMissions[team.missio_actual] || 25;
                                            const esLimit = team.credits <= 0;
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                onClick: ()=>setEquipSeleccionat(team),
                                                className: `p-4 rounded-lg border transition-all cursor-pointer ${equipSeleccionat?.id_equip === team.id_equip ? 'bg-slate-850 border-cyan-500 shadow-lg' : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex justify-between items-start mb-3",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                        className: "font-bold text-slate-100 text-sm tracking-wide",
                                                                        children: team.noms_equip
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/page.tsx",
                                                                        lineNumber: 416,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-[10px] font-mono font-bold text-slate-500 uppercase bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800 mt-1 inline-block",
                                                                        children: [
                                                                            "🎯 FASE: ",
                                                                            (team.missio_actual || 'MISION_1').replace('_', ' ')
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/app/admin/page.tsx",
                                                                        lineNumber: 417,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/admin/page.tsx",
                                                                lineNumber: 415,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `text-xs font-mono font-bold px-2 py-0.5 rounded ${esLimit ? 'bg-red-950 text-red-400 border border-red-800 animate-pulse' : 'bg-slate-900 text-emerald-400 border border-slate-800'}`,
                                                                children: [
                                                                    "⚡ ",
                                                                    team.credits,
                                                                    " CR"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/admin/page.tsx",
                                                                lineNumber: 421,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/page.tsx",
                                                        lineNumber: 414,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "space-y-1 mb-4",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-full bg-slate-900 h-2 rounded overflow-hidden border border-slate-850",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "bg-gradient-to-r from-cyan-600 to-cyan-400 h-full transition-all duration-1000",
                                                                style: {
                                                                    width: `${progres}%`
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/page.tsx",
                                                                lineNumber: 428,
                                                                columnNumber: 29
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/page.tsx",
                                                            lineNumber: 427,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/page.tsx",
                                                        lineNumber: 426,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex justify-between items-center pt-3 border-t border-slate-900 gap-2 no-print",
                                                        onClick: (e)=>e.stopPropagation(),
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex gap-1",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        onClick: ()=>modificarCreditsMestre(team.id_equip, team.id_client, -1),
                                                                        className: "bg-slate-900 hover:bg-slate-800 text-slate-400 w-6 h-6 border border-slate-800 rounded text-xs",
                                                                        children: "-1"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/page.tsx",
                                                                        lineNumber: 434,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        onClick: ()=>modificarCreditsMestre(team.id_equip, team.id_client, 2),
                                                                        className: "bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-400 px-2 h-6 border border-emerald-800/60 rounded text-[10px] font-bold",
                                                                        children: "+2 CR"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/admin/page.tsx",
                                                                        lineNumber: 435,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/admin/page.tsx",
                                                                lineNumber: 433,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex gap-1 text-[9px] font-mono",
                                                                children: [
                                                                    'MISION_1',
                                                                    'MISION_2',
                                                                    'MISION_3',
                                                                    'MISION_4'
                                                                ].map((m, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        onClick: ()=>forcarSaltMissio(team.id_equip, m),
                                                                        disabled: team.missio_actual === m,
                                                                        className: "bg-slate-900 border border-slate-800 text-slate-400 px-1 rounded hover:bg-slate-800 disabled:opacity-25",
                                                                        children: [
                                                                            "M",
                                                                            idx + 1
                                                                        ]
                                                                    }, m, true, {
                                                                        fileName: "[project]/app/admin/page.tsx",
                                                                        lineNumber: 439,
                                                                        columnNumber: 31
                                                                    }, this))
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/page.tsx",
                                                                lineNumber: 437,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/page.tsx",
                                                        lineNumber: 432,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, team.id_equip, true, {
                                                fileName: "[project]/app/admin/page.tsx",
                                                lineNumber: 408,
                                                columnNumber: 23
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/page.tsx",
                                        lineNumber: 400,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/page.tsx",
                                lineNumber: 391,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-slate-950 border border-slate-800 rounded-lg p-5 h-[76vh] flex flex-col justify-between overflow-y-auto",
                                children: equipSeleccionat ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-6 h-full flex flex-col justify-between",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "border-b border-slate-850 pb-3 mb-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[10px] font-mono text-cyan-400 uppercase tracking-widest",
                                                        children: "// COGNITIVE REPORT AUDIT"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/page.tsx",
                                                        lineNumber: 454,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        className: "text-lg font-bold text-white mt-1",
                                                        children: equipSeleccionat.noms_equip
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/page.tsx",
                                                        lineNumber: 455,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/page.tsx",
                                                lineNumber: 453,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2 mb-6",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider block",
                                                        children: "🧠 Reflexió de Calibratge (Misió 0):"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/page.tsx",
                                                        lineNumber: 458,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "bg-slate-900/80 p-3 rounded border border-slate-800 text-xs text-slate-300 italic font-mono",
                                                        children: [
                                                            '"',
                                                            equipSeleccionat.reflexio_individual || 'Cap resposta.',
                                                            '"'
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/admin/page.tsx",
                                                        lineNumber: 459,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/page.tsx",
                                                lineNumber: 457,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider block",
                                                        children: "⚖️ Dictamen Final per a la Jutgessa:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/page.tsx",
                                                        lineNumber: 462,
                                                        columnNumber: 23
                                                    }, this),
                                                    equipSeleccionat.informe_final ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "bg-slate-900 p-4 rounded border border-cyan-900/30 text-xs text-slate-200 leading-relaxed border-l-2 border-l-cyan-500",
                                                        children: equipSeleccionat.informe_final
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/page.tsx",
                                                        lineNumber: 464,
                                                        columnNumber: 25
                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "bg-slate-900/30 p-4 rounded border border-dashed border-slate-800 text-xs text-slate-500 text-center italic",
                                                        children: "L'equip està redactant l'informe..."
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/page.tsx",
                                                        lineNumber: 466,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/page.tsx",
                                                lineNumber: 461,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/admin/page.tsx",
                                        lineNumber: 452,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/page.tsx",
                                    lineNumber: 451,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-full flex flex-col items-center justify-center text-center p-6 text-slate-600",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-3xl mb-2",
                                            children: "📊"
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/page.tsx",
                                            lineNumber: 473,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs font-mono",
                                            children: "Seleccioneu un equip de la llista per monitoritzar el seu expedient en viu."
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/page.tsx",
                                            lineNumber: 474,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/admin/page.tsx",
                                    lineNumber: 472,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/admin/page.tsx",
                                lineNumber: 449,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/page.tsx",
                        lineNumber: 390,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/page.tsx",
                lineNumber: 355,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/page.tsx",
        lineNumber: 321,
        columnNumber: 5
    }, this);
}
_s(AdminDashboard, "WutUpUcnaz7LfHsUuK/KJrqRO6o=");
_c = AdminDashboard;
var _c;
__turbopack_context__.k.register(_c, "AdminDashboard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_1b1vv9d._.js.map