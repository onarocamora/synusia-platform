(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/instrumentation-client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$posthog$2d$js$2f$dist$2f$module$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/posthog-js/dist/module.mjs [app-client] (ecmascript)");
;
const posthogProjectToken = ("TURBOPACK compile-time value", "phc_yzpggkekuhAvfuf2UEyx9isJn4uBK3VooW62b4vws8ia");
const posthogHost = ("TURBOPACK compile-time value", "https://eu.i.posthog.com");
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$posthog$2d$js$2f$dist$2f$module$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].init(posthogProjectToken, {
        api_host: posthogHost,
        defaults: "2026-01-30",
        capture_exceptions: true,
        debug: ("TURBOPACK compile-time value", "development") === "development"
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=instrumentation-client_ts_06kj-ai._.js.map