(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0cbk-n2._.css","static/chunks/node_modules_10p7dja._.js","static/chunks/components_Footer_tsx_0ti2s81._.js","static/chunks/_1b1vv9d._.js","static/chunks/node_modules_0an263q._.js"],
    source: "entry"
});
